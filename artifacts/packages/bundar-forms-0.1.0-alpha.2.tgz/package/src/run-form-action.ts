/**
 * Progressive validated form-action orchestration (BR-015; GH-060 origin).
 *
 * Composes ONE submission pipeline: bounded form parsing (GH-057), Standard
 * Schema validation (GH-058), field-error data with safe value retention
 * (GH-059), and exactly-once success execution inside transaction hooks.
 * Response DELIVERY is fully delegated to the caller's FormResponseAdapter
 * (ADR-0018 §3) — this module never touches protocol headers, so the same
 * runtime serves htmx and any future presentation layer. Identical business
 * validation runs for ordinary and enhanced flows.
 */
import { parseForm, type Context } from "@bundar/core";

/**
 * BR-058 honesty rule: Promise.race stops OUR continuation promptly but
 * cannot interrupt a native body parser that ignores signals. The losing
 * settlement is consumed defensively so no unhandled rejection escapes;
 * the residual limitation is documented rather than hidden.
 */
function abortError(signal: AbortSignal): unknown {
  return signal.reason ?? new Error("request cancellation (BR-058)");
}

async function raceAbort<T>(
  promise: Promise<T>,
  signal: AbortSignal,
): Promise<T> {
  if (signal.aborted) throw abortError(signal);
  const gate = new Promise<never>((_, reject) => {
    const onAbort = (): void => reject(abortError(signal));
    signal.addEventListener("abort", onAbort, { once: true });
  });
  // Defensive consumption of the loser prevents unhandled rejections.
  promise.catch(() => undefined);
  return Promise.race([promise, gate]);
}
import {
  resolveValidationAdapter,
  type FormValidationAdapter,
} from "./validation";
import type { ValidationResult } from "@bundar/schema";
import {
  INVALID_SUBMISSION_STATUS,
  type FormActionDefinition,
  type FormActionOutcome,
  type FormResponseAdapter,
  type InvalidFormRender,
} from "./contracts";

export { INVALID_SUBMISSION_STATUS };

/** Extracts first/submitted values per field from the bounded parse. */
function submittedValues(
  form: Awaited<ReturnType<typeof parseForm>>,
): Record<string, string | string[]> {
  const submitted: Record<string, string | string[]> = {};
  for (const field of form.fields) {
    if (field.name in submitted) continue;
    const values = form.getAll(field.name);
    submitted[field.name] = values.length > 1 ? [...values] : values[0]!;
  }
  return submitted;
}

/**
 * Runs the validated form action for one request: parse → validate →
 * (invalid) hand the adapter ready-made renderer data, or (valid) run the
 * success handler exactly once inside the transaction hooks — fragment
 * resolved BEFORE commit so business failures roll back — then hand the
 * adapter the resolved fragment + delivery options.
 */
export async function executeFormAction<Output>(
  context: Context,
  definition: FormActionDefinition<Output>,
  adapter: FormResponseAdapter,
): Promise<FormActionOutcome> {
  // Checkpoint 0 — before any work (BR-058).
  context.signal.throwIfAborted();

  // 1. bounded parse, raced against cancellation. The native parser may not
  // be signal-aware (documented residual limitation); our continuation stops
  // immediately and the eventual settlement is consumed safely above.
  const form = await raceAbort(parseForm(context), context.signal);
  context.signal.throwIfAborted();
  const submitted = submittedValues(form);

  // 2. identical business validation for both worlds (via the resolved port)
  context.signal.throwIfAborted(); // checkpoint: before validation
  const validation: FormValidationAdapter<Output> = resolveValidationAdapter(
    definition.schema,
    definition.validation,
  );
  const result = (await raceAbort(
    Promise.resolve(validation.validate(submitted)),
    context.signal,
  )) as ValidationResult<Output>;
  context.signal.throwIfAborted(); // checkpoint: after async validation

  // 3. invalid: adapter renders the form region (or document) with safe data
  if (!result.success) {
    const render: InvalidFormRender = validation.invalidRender(
      result,
      submitted,
    );
    context.signal.throwIfAborted(); // checkpoint: before invalid rendering
    const response = await adapter.invalid(context.request, {
      status: INVALID_SUBMISSION_STATUS,
      message: "Validation failed",
      render,
      formTarget: definition.formTarget,
    });
    return { kind: "invalid", response };
  }

  // 4. valid: exactly-once success path inside the transaction hooks
  // GH-184 conformance alignment: the pre-begin checkpoint keeps an abort
  // from stranding an open transaction, and the checkpoint after fragment
  // resolution (inside the rollback boundary) sends a post-rendering abort
  // through rollback instead of committing a response nobody will observe.
  context.signal.throwIfAborted(); // checkpoint: before transaction begin
  let handle: unknown;
  if (definition.transaction !== undefined) {
    handle = await definition.transaction.begin();
  }
  let fragment: unknown;
  try {
    fragment = await definition.buildFragment(result.value);
    context.signal.throwIfAborted(); // checkpoint: after rendering, before commit
  } catch (error) {
    if (definition.transaction !== undefined) {
      await definition.transaction.rollback(handle);
    }
    throw error;
  }
  if (definition.transaction !== undefined) {
    await definition.transaction.commit(handle);
  }

  const response = await adapter.valid(context.request, {
    fragment,
    delivery: definition.delivery ?? {},
  });
  return { kind: "valid", response };
}
