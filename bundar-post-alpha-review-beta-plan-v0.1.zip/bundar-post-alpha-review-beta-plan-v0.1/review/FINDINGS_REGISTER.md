---
type: Finding Register
title: Bundar Post-Alpha Findings Register
description: Prioritized findings with classification, confidence, impact, and mapped
  remediation issues.
tags:
- bundar
- findings
- audit
- risk
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Findings register

## Classification rule

A P0 in this review means “must be resolved or explicitly disproven before the proposed beta gate,” not “the alpha was dishonest.” Several P0s are new beta-scope or reproduction-first findings.

| ID | Finding | Classification | Priority | Confidence | Impact | Tasks |
| --- | --- | --- | --- | --- | --- | --- |
| F-001 | Root README describes a design archive rather than the implemented alpha | Confirmed documentation defect | P0 | High | A prospective user or agent receives materially false status and onboarding information. | BR-008, BR-009, BR-010 |
| F-002 | Middleware compile-once contract may be implemented per request | Probable contract defect | P0 | Medium-high | Unnecessary hot-path work and contradiction of GH-018; semantics must be reproduced before refactor. | BR-002, BR-003, BR-004 |
| F-003 | Raw HTML trust marker may be forgeable from a globally discoverable brand | Contract/security mismatch | P0 | Medium-high | Potential escaping bypass if an untrusted object reaches JSX children; remote exploitability is not assumed. | BR-005, BR-006, BR-007 |
| F-004 | HTMX package imports conflict with protocol-pure ownership | Confirmed architecture drift | P0 | High | Couples form/schema/core concerns into the migration-critical dialect package before public publication. | BR-011–BR-020 |
| F-005 | Canonical app files mix UI, route, validation, session, repository, and bootstrap concerns | Confirmed maintainability gap | P1 | High | Raises context size, makes parallel agent work unsafe, and teaches patterns Bundar should avoid. | BR-021–BR-045 |
| F-006 | Canonical `.tsx` source uses manual JSX factory calls | Confirmed DX gap | P0 | High | The starter does not demonstrate the framework's advertised TSX ergonomics. | BR-026 |
| F-007 | First-party examples bypass typed routes and high-level response/security helpers | Confirmed dogfooding gap | P1 | High | Users copy hardcoded URLs, HTML concatenation, cookie regex, and Response rebuilding. | BR-050–BR-056 |
| F-008 | Production lifecycle, proxy, durable-session, and cancellation contracts are incomplete for beta | Recommended hardening | P0/P1 | Medium | Real deployments can behave incorrectly around TLS termination, shutdown, session rotation, and aborts. | BR-057–BR-068 |
| F-009 | HTTP edge semantics and cross-engine browser evidence are narrower than a broad beta claim | Accepted alpha risk / beta gap | P1 | High | Chrome-centered evidence and implicit Bun semantics leave portability and correctness uncertainty. | BR-069–BR-075 |
| F-010 | Current performance evidence underrepresents target workloads and lacks Carno reference | Enhancement | P2 | Medium | Hello-world results do not predict admin tables, fragments, forms, and multi-region updates. | BR-076–BR-077 |
| F-011 | Registry publication and clean external consumption remain pending | Confirmed human/distribution gate | P0 | High | A source release is not yet an installable ecosystem release. | BR-078–BR-085 |
| F-012 | htmx 4 GA is unavailable | Upstream blocked | Deferred | High | Bundar must not claim stable v4 support; this does not block an htmx 2-based beta. | Existing M7; BR-073 |
| F-013 | AI-agent-friendly claim lacks first-party bounded-context tooling and independent evidence | Enhancement / product-proof gap | P1 | High | Issue discipline exists, but application structure and context selection remain manual. | BR-021–BR-049, BR-084 |

## Detailed disposition

### F-001 — README status drift

The baseline README still introduces the repository as a design bundle, while the alpha gate records implementation through M6. The fix is already prepared; the important enhancement is to prevent another manual drift.

**Disposition:** fix immediately, then automate status verification.

### F-002 — middleware composition placement

The original contract is precise: compose middleware during application compilation and preserve a synchronous path. Source inspection suggests the composer is called from the request executor. A small test can settle this without debate.

**Disposition:** BR-002 must land before BR-003. When the test proves compile-once already holds, close BR-003 as disproven and retain the regression/benchmark.

### F-003 — raw HTML branding

A public/global marker can make a TypeScript brand look stronger than its runtime identity. This is a trust-contract problem even when applications normally do not pass arbitrary objects into JSX.

**Disposition:** test same-realm forging and realistic reachability; then use an opaque marker or narrow the documented guarantee. Do not call it a remote vulnerability without a path.

### F-004 — package ownership drift

Version migration is safest when HTMX protocol code stays independent from the application kernel and validator. Moving progressive form workflow to `@bundar/forms` is the recommended design, but BR-011 is the binding ADR.

**Disposition:** correct before npm publication, with temporary pre-1.0 re-exports and packed consumers.

### F-005/F-006/F-007 — developer and agent experience

Bundar's internal package design is comparatively disciplined, but its examples are the actual learning API. Mixed files, manual factory calls, hardcoded URLs, manual serialization, and manual cookies make the framework feel lower-level and increase agent context.

**Disposition:** refactor incrementally with behavior-equivalence gates. Do not create separate frontend/backend repos.

### F-008/F-009 — beta versus production expectations

The alpha gate explicitly accepts fixture seams and Chrome-lane evidence. The review raises the bar because a public beta invites broader deployments.

**Disposition:** close fail-closed production contracts and either broaden browser claims or state the supported engine scope exactly.

### F-010 — performance evidence

Bundar should benchmark real HTML-first work and compare fairly, not chase one static-response chart.

**Disposition:** P2; do after correctness and package boundaries.

### F-011 — publication

The human registry gate is expected and honest. It remains a beta blocker because public consumers cannot validate the promised install experience until packages are real.

**Disposition:** maintainers own credentials/approval; agents prepare and verify everything else.

### F-012 — htmx 4

The M7 descope is correct. Do not reopen it based on estimates or secondary reports.

**Disposition:** keep the beta adapter experimental; run BR-073 for upgrade-check parity; reopen the existing chain only on official GA.

### F-013 — AI-agent evidence

Dependency-aware issue specifications are a strong start. The missing pieces are local feature maps, import/write boundaries, deterministic machine output, bounded context packs, and an independent study.

**Disposition:** treat agent-friendliness as a measurable product capability, not merely a documentation adjective.
