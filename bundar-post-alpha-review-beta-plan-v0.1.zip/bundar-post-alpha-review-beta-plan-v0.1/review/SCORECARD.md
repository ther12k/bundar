---
type: Engineering Scorecard
title: Bundar Evidence-Weighted Beta Readiness Scorecard
description: Weighted planning score for beta readiness, with evidence, deductions,
  confidence, and closure tasks.
tags:
- bundar
- scorecard
- beta
- readiness
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Evidence-weighted beta readiness

## Result

**Planning estimate: 71% beta-ready, with moderate confidence (approximately ±6 percentage points).**

This is not a test pass rate, completion percentage, or release authorization. It weighs product, implementation, evidence, operational, and distribution dimensions against the broader meaning of a public beta.

## Method

Each dimension receives:

```text
weight × score from 0 to 10
```

The weighted total is divided by 10. Scores reflect the audited baseline and committed evidence, with deductions for unverified/probable contract mismatches and beta-scope gaps.

| Dimension | Weight | Score | Why it is not lower | Why it is not higher | Main closure tasks |
| --- | ---: | ---: | --- | --- | --- |
| Product identity and scope | 10% | 9.0/10 | Clear Bun-native, HTML-first, no-hydration identity and good non-goals. | Product messaging is undermined by stale README and examples that do not showcase actual TSX. | BR-008–010, BR-026 |
| Bun-native HTTP core | 12% | 7.5/10 | Native route compilation, explicit responses, middleware/context/error work, integration evidence. | Compile-once middleware needs reproduction; method/body/route edge semantics need closure. | BR-002–004, BR-069–071 |
| Server JSX and rendering safety | 12% | 7.4/10 | Escaping, document/fragment, async/streaming, typed attributes, security suites. | Raw trust brand contract needs closure; streaming late errors and broader fuzzing remain. | BR-005–007, BR-068, BR-072 |
| HTMX protocol and progressive enhancement | 12% | 8.2/10 | Version-neutral model, stable htmx 2, experimental v4, dual-lane/no-JS evidence. | Package ownership drift and beta-vs-GA uncertainty; higher-level action response needs dogfooding. | BR-011–020, BR-052–053, BR-073 |
| Forms and security primitives | 12% | 7.0/10 | Validation, CSRF, sessions, uploads, origin/security work and reference flows exist. | Production session/proxy/posture/parser contracts need stronger fail-closed behavior. | BR-055, BR-059–068 |
| Developer experience and application structure | 12% | 6.0/10 | CLI, scaffolder, docs, typed routes, examples already exist. | Canonical apps mix concerns, manual JSX/response/cookie patterns, and underuse typed URLs. | BR-021–045, BR-050–056 |
| AI-agent friendliness | 10% | 5.5/10 | Dependency-aware issues, evidence templates, explicit framework scope. | No first-party feature-slice convention, machine context pack, write-zone check, or independent study yet. | BR-021–025, BR-044–049, BR-084 |
| Testing, evidence, and release discipline | 10% | 8.5/10 | Strong alpha gate, browser/no-JS lanes, package audit, SBOM, provenance, reproducibility. | This review did not freshly rerun the battery; cross-engine/property/external registry evidence remains. | BR-001, BR-068, BR-074–075, BR-080–082 |
| Production operations | 5% | 5.5/10 | Request budgets, error/security foundations, deployment concepts exist. | Lifecycle, draining, cancellation propagation, trusted proxies, durable sessions need explicit contracts. | BR-057–067 |
| Distribution and external adoption | 5% | 4.0/10 | GitHub prerelease, packed cleanroom, release tooling and namespace work exist. | Packages remain unpublished/private; no real registry install or independent greenfield proof. | BR-078–085 |

## Calculation

```text
weighted score = 7.107 / 10
readiness estimate = 71.1%
rounded planning headline = 71%
```

## Confidence

Confidence is **moderate**, not high, because:

- the review is pinned to one commit and the repository may have advanced;
- the full release battery was not rerun in the artifact environment;
- two important findings deliberately require reproduction;
- production readiness depends on deployment assumptions not fully exercised by reference fixtures;
- npm publication and independent consumer evidence do not exist yet;
- htmx 4 remains a moving beta target.

## Interpretation bands

| Range | Meaning |
| --- | --- |
| 0–39% | Concept/prototype; core promises not yet evidenced |
| 40–59% | Alpha foundation; major functional or trust gaps |
| 60–74% | Strong alpha / beta candidate work remains |
| 75–89% | Beta-ready after explicit gate and residual-risk review |
| 90–100% | Mature pre-1.0 evidence; not automatically stable/1.0 |

Bundar sits near the top of **strong alpha**, not yet in the beta-ready band.

## What would move the score most

The largest increases come from:

1. P0 correctness and trust closure;
2. package boundary repair before publication;
3. external registry consumption;
4. feature-sliced examples and agent tooling;
5. production session/proxy/lifecycle contracts;
6. cross-browser and accessibility evidence.

Performance micro-optimizations have much less influence unless a real workload crosses a measured budget.

## Why htmx 4 GA is excluded

A missing upstream GA release is not a Bundar quality failure. Bundar should retain its experimental beta adapter and prepared M7 chain, but beta readiness is judged against the stable htmx 2 promise and honest experimental labeling.
