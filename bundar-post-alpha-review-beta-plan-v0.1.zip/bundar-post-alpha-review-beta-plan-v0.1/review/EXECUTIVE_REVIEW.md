---
type: Engineering Review
title: Bundar Post-Alpha Executive Review
description: Candid assessment of Bundar's implemented strengths, material gaps, and
  recommended beta direction.
tags:
- bundar
- review
- architecture
- beta
- ai-agent
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Executive review

## Bottom line

Bundar has moved beyond a framework idea. At the audited baseline it has an alpha release, a Bun-native HTTP kernel, a server JSX runtime, HTMX dialect work, form/security primitives, tooling, evidence-backed gates, and reference applications.

The direction is still worth pursuing. Its strongest competitive advantage is not “another fast Bun router.” It is the integrated server-driven model:

```text
ordinary browser or HTMX request
→ native Bun route
→ explicit application action
→ server-rendered TSX
→ complete document, primary fragment, or multi-region update
```

The project should **stabilize and sharpen**, not broaden into an enterprise backend framework and not restart in Rust.

## What Bundar got right

### A clear product boundary

Bundar is deliberately Bun-only, HTML-first, server-only JSX, progressively enhanced, and explicit about not providing React hydration, a second router, an ORM, DI container, or multi-runtime abstraction. That focus is more valuable than feature-count parity with Elysia, Hono, or Carno.

### HTMX version isolation

The stable htmx 2 profile and experimental htmx 4-beta profile are separated through dialect contracts. The project explicitly records M7 as externally blocked rather than pretending beta support is GA support. That is unusually honest compatibility governance.

### Evidence discipline

The alpha gate records commands, package artifacts, SBOM, provenance, reproducibility, browser lanes, no-JS lanes, and accepted residual risks. Even where this review recommends new work, that release discipline should be retained.

### Progressive enhancement as an implementation constraint

Reference applications exercise ordinary POST/Redirect/GET and enhanced fragment responses from the same business workflow. This is the right proof for the framework's stated use cases.

### A TypeScript-first implementation

Rust is unnecessary for the framework core. Bun already owns the runtime and native HTTP machinery. Bundar should continue optimizing its TypeScript hot paths and only consider optional native acceleration after a reproducible workload demonstrates that the JSX renderer—not application/database work—is the limiting factor.

## Material findings

### 1. Release claims and root documentation drifted apart

The root README at the baseline still says the repository is a design archive rather than an implementation. This is immediately visible to prospective users and agents. A replacement has already been prepared; it should be merged and guarded by source-of-truth checks.

### 2. Two implementation contracts require urgent reproduction

The review found source-level evidence that:

- middleware advertised as composed once at compile time may be composed inside each request handler; and
- the raw HTML brand may be reconstructible through a globally discoverable symbol despite the original acceptance criterion saying plain object shapes should not forge it.

The plan deliberately does not jump straight to a rewrite. BR-002 and BR-005 first create focused failing probes and threat models. The implementation changes are accepted only if the repository reproduces the mismatch.

### 3. Package boundaries need one pre-publication reset

The HTMX package is supposed to own protocol and dialect behavior, but its manifest/import surface has absorbed core/schema/form concerns. This is the best time to correct that, before public npm consumers exist.

Recommended ownership:

```text
@bundar/core      Request/Response kernel, routes, context, middleware, body/cookies
@bundar/jsx       server HTML renderer
@bundar/htmx      request metadata, directives, dialects, assets, views, updates
@bundar/forms     form workflow, retained values, action orchestration, validation port
@bundar/schema    optional Standard Schema adapter
@bundar/security  sessions, CSRF, origin, CSP, production posture
@bundar/testing   framework-aware test clients
@bundar/cli       deterministic tooling and scaffolding
```

The key rule is that `@bundar/htmx` should be usable over standard `Request`/`Response` plus JSX without importing the application kernel or schema package.

### 4. Application organization is not yet agent-friendly enough

The framework itself is small, but examples teach mixed-concern files. In the minimal starter, route, schema, UI, and mutation behavior share `app.ts`; in Todo, a large `app.ts` coordinates routing, validation, repository calls, sessions, CSRF, rendering, updates, and server concerns.

Bundar should not split frontend/backend into different repositories. It should make feature ownership obvious inside one codebase:

```text
*.routes.ts       transport and representation
*.actions.ts      business/application use cases
*.schema.ts       input contracts
*.repository.ts   data port/adapters
*.types.ts        domain/read models
*.view.tsx        pages and fragments
*.components.tsx  reusable server UI
```

This structure should be documented, scaffolded, checked, and demonstrated in Todo/Admin.

### 5. Canonical examples underuse Bundar's own abstractions

Examples use manual JSX factory calls, hardcoded internal URLs, manual primary/update HTML concatenation, cookie regex parsing, and Response rebuilding. These are exactly the patterns users and agents will copy.

The beta path should make the preferred API clearer than the low-level escape hatch:

- actual TSX syntax;
- typed routes/URLs;
- one typed action response for a primary fragment plus secondary updates;
- safe response cookie/header mutation;
- CSRF hidden-field/session helpers.

### 6. Production contracts need to catch up with functional features

The alpha can reasonably accept fixture stores and Chrome-only browser evidence. A beta that invites real projects should define:

- startup/readiness/drain/stop lifecycle;
- cancellation and abort propagation;
- trusted proxy and canonical origin behavior;
- secure cookies behind TLS termination;
- durable session-store capabilities;
- production fail-closed posture;
- session fixation/rotation/invalidation;
- redirect/HTMX header validation;
- CSP nonce integration;
- multipart/form complexity limits;
- stable error codes/redaction;
- property/fuzz coverage for high-risk parsers/serializers.

### 7. Distribution remains the largest adoption gap

The GitHub alpha release is not the same as installable public packages. Beta should not be declared until packed artifacts are published under a non-default tag, installed in a clean repository, used by both scaffold structures, and migrated from an alpha fixture.

## Recommended product decision

Keep Bundar narrow:

> Bundar is a Bun-native, HTML-first TypeScript framework for server-rendered TSX applications enhanced by official HTMX.

Do not add a DI container, ORM, queue, scheduler, client state runtime, React compatibility layer, multi-runtime adapter, or automatic JSON/RPC architecture to “catch up” with broader frameworks.

Those capabilities can be integrated by applications or optional ecosystem packages. The framework's job is to make pages, fragments, forms, validation, security boundaries, and server-driven interactions exceptionally clear.

## Recommended beta definition

Beta is justified when:

1. correctness/contract mismatches are closed;
2. package ownership is frozen and externally consumable;
3. canonical examples use actual TSX and feature slices;
4. production security/lifecycle contracts fail closed;
5. stable htmx 2 workflows pass claimed browsers and no-JS/accessibility gates;
6. a clean external repository installs and runs published packages;
7. an alpha application migrates through documented steps;
8. an independent user/agent can implement a feature without hidden project history;
9. all claims are regenerated from one candidate commit.

HTMX 4 GA is **not** a beta prerequisite. It remains a separately triggered upstream-gated chain.
