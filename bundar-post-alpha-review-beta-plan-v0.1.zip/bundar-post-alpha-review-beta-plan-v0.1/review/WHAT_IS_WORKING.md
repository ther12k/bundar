---
type: Engineering Review
title: What Bundar Should Preserve
description: Strengths and invariants that should survive all post-alpha refactoring.
tags:
- bundar
- strengths
- invariants
- scope
status: final
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# What is working and must be preserved

## 1. Bun owns the runtime

Keep native `Bun.serve` routing, Request/Response, streaming, static assets, TS/TSX execution, tests, and package management. Bundar should not add a general second router or mandatory Rust layer.

## 2. Explicit HTTP responses

Handlers and helpers produce native `Response` objects. Avoid a broad implicit return-value language that turns every JavaScript value into framework magic.

## 3. Server-only JSX

Preserve automatic escaping, explicit raw trust boundaries, functional/async components, documents/fragments, and streaming without React compatibility, hydration, hooks, virtual DOM, or client lifecycle.

## 4. HTMX stays visible and official

Application markup should keep ordinary `hx-*` attributes. Bundar normalizes request/response protocol differences; it should not hide HTMX behind a proprietary component DSL or fork the browser runtime.

## 5. Progressive enhancement is not optional polish

One business workflow should support:

```text
ordinary POST → validate/mutate → 303 redirect → full page
HTMX POST     → validate/mutate → fragment/update response
```

No-JS tests and semantic HTML remain release evidence.

## 6. Dialect differences stay isolated

The application source should not branch on raw HTMX version headers/events. Stable htmx 2 is the default. Experimental htmx 4 remains opt-in until official GA and the M7 chain.

## 7. Small framework context, explicit application dependencies

Do not add decorator metadata, a service locator, request-scope bubbling, or whole-program treaty inference. Services and repository ports should remain explicit and testable.

## 8. Evidence-backed gates

Keep exact commands, environment versions, browser versions, package artifacts, performance raw data, security reports, SBOM/provenance, residual risks, and immutable commit identity.

## 9. Reference apps as executable contracts

Minimal, Todo, and Admin should remain real journeys, not showcase screenshots. Refactoring them into feature slices must preserve URLs, statuses, headers, cookies, HTML regions, ordinary flows, and dialect lanes.

## 10. Honest scope

Do not expand Bundar core with:

- ORM/database models;
- DI container;
- queue/scheduler;
- authentication product;
- client state runtime;
- React compatibility;
- multi-runtime adapters;
- automatic JSON/RPC client architecture;
- custom HTMX fork;
- mandatory native/Rust dependency.

Optional integrations can live outside core after the HTML-first workflow is exceptional.

## Refactor guardrail

Every post-alpha task should answer:

> Does this make Bundar's pages, fragments, forms, server UI, security boundaries, or agent readability better without turning it into a generic enterprise backend framework?

When the answer is no, the feature probably belongs in an application or ecosystem package.
