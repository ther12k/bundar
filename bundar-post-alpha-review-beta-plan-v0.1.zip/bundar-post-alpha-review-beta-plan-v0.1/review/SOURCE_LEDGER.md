---
type: Source Ledger
title: Bundar Review Source Ledger
description: Source-of-truth ledger for repository, release, design, example, Bun,
  and HTMX observations used by the review.
tags:
- bundar
- sources
- evidence
- provenance
status: final
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Source ledger

## Repository and release

| ID | Source | Use |
| --- | --- | --- |
| SRC-REPO | `https://github.com/ther12k/bundar` | Repository identity and tree |
| SRC-COMMIT | `https://github.com/ther12k/bundar/commit/f8bdd8641865be3563746e892ab86fba702ee3e8` | Immutable audited baseline |
| SRC-RELEASE | `https://github.com/ther12k/bundar/releases/tag/v0.1.0-alpha.1` | GitHub alpha release record |
| SRC-README | `https://raw.githubusercontent.com/ther12k/bundar/f8bdd8641865be3563746e892ab86fba702ee3e8/README.md` | Stale root landing-page finding |
| SRC-ALPHA-GATE | `delivery/gates/alpha.md` at the audited commit | Alpha battery, residual risks, publication state |
| SRC-M7 | `delivery/descopes/m7-htmx4-ga.md` at the audited commit | Upstream-blocked M7 status |

## Canonical application sources

| ID | Source | Use |
| --- | --- | --- |
| SRC-MINIMAL-APP | `templates/minimal/src/app.ts` at the audited commit | Mixed schema/UI/route responsibilities and manual JSX factory usage |
| SRC-MINIMAL-LAYOUT | `templates/minimal/src/layout.tsx` at the audited commit | TSX authoring surface inspection |
| SRC-TODO-APP | `examples/todo/src/app.ts` at the audited commit | Large route/form/session/rendering composition file |
| SRC-TODO-DOC | `docs/examples/todo.md` at the audited commit | Intended Todo architecture and verification lanes |
| SRC-ADMIN | `examples/admin/**` and `docs/examples/admin.md` at the audited commit | Larger reference-application architecture |

## Contract sources

| ID | Source | Use |
| --- | --- | --- |
| SRC-GH018 | Original issue `GH-018 — Implement startup-composed sync and async middleware` | Compile-once middleware contract |
| SRC-GH031 | Original issue `GH-031 — Implement explicit raw HTML and trust-boundary controls` | Non-accidental-forgery raw HTML contract |
| SRC-ADR013 | Original `ADR-0013 — Use Focused Packages and Versioned HTMX Subpaths` | Package separation intent |
| SRC-MASTER | Original `MASTER_AGENT_PROMPT.md` | Runtime, router, JSX, HTMX, dependency, and evidence invariants |

## External primary sources

| ID | Source | Use |
| --- | --- | --- |
| SRC-BUN14 | `https://bun.com/blog/bun-v1.4` | Bun 1.4 baseline and runtime context |
| SRC-BUN-ROUTING | `https://bun.com/docs/runtime/http/routing` | Native route capabilities delegated to Bun |
| SRC-HTMX | `https://htmx.org/docs/` | Stable htmx model |
| SRC-HTMX4 | `https://four.htmx.org/docs/` | Current htmx 4 beta documentation |
| SRC-HTMX4-MIGRATION | `https://htmx.org/migration-guide-htmx-3/` or current official v4 migration guide | Version-difference inventory |
| SRC-HTMX-RELEASES | `https://github.com/bigskysoftware/htmx/releases` | Release maturity; beta6 remains pre-release at the audit date |

## Finding-to-source map

| Finding | Evidence sources |
| --- | --- |
| F-001 stale README | SRC-README, SRC-ALPHA-GATE, SRC-RELEASE |
| F-002 middleware compile placement | Inspected core compiler/middleware source, SRC-GH018; BR-002 must reproduce |
| F-003 raw brand contract | Inspected JSX raw source, SRC-GH031; BR-005 must threat-model |
| F-004 HTMX package boundary drift | Inspected `packages/htmx/package.json` and package README, SRC-ADR013 |
| F-005 mixed application concerns | SRC-MINIMAL-APP, SRC-MINIMAL-LAYOUT, SRC-TODO-APP, SRC-TODO-DOC |
| F-006 manual JSX in canonical starter | SRC-MINIMAL-APP, SRC-MINIMAL-LAYOUT |
| F-007 API dogfooding gaps | SRC-MINIMAL-APP, SRC-TODO-APP |
| F-008 production contracts | Current package/docs inventory plus explicit alpha residual risks |
| F-009 browser/HTTP conformance | SRC-ALPHA-GATE and current test/compatibility inventory |
| F-010 benchmark expansion | Current benchmark inventory and target-use-case analysis |
| F-011 registry publication | SRC-ALPHA-GATE, package manifests, SRC-RELEASE |
| F-012 htmx 4 upstream state | SRC-M7, SRC-HTMX4, SRC-HTMX-RELEASES |
| F-013 independent agent usability proof | Current tooling/docs inventory; enhancement, not defect |

## Local files retained with this bundle

The supporting README candidate was copied from the previously prepared baseline-specific refresh:

- [`../supporting/README_IMPLEMENTATION_CANDIDATE.md`](../supporting/README_IMPLEMENTATION_CANDIDATE.md)
- [`../supporting/README_APPLY_GUIDE.md`](../supporting/README_APPLY_GUIDE.md)

These are convenience artifacts. Rebase and validate them before applying to a newer commit.
