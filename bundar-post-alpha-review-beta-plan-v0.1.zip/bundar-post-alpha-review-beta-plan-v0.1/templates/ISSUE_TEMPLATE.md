---
type: GitHub Issue Template
title: Bundar Agent-Ready Issue Template
description: Reusable template for future bounded, dependency-aware Bundar tasks.
tags:
- bundar
- github
- issue-template
- agents
status: final
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# BR-XXX — <imperative task title>

**Milestone:** `<milestone>`  
**Priority:** `P0 | P1 | P2`  
**Size:** `XS | S | M`  
**Area:** `<area>`  
**Type:** `<bug | security | refactor | feature | test | docs | tooling | release>`

## Outcome

One observable result. Avoid combining implementation, migration, and unrelated cleanup.

## Why this task exists

State the source evidence, current behavior, contract, user impact, and uncertainty. Use “probable” when reproduction is still required.

## Deliverables

- One bounded deliverable.
- One required test/evidence deliverable.
- One documentation/migration deliverable when public behavior changes.

## Out of scope

- Explicitly excluded feature.
- Explicitly excluded package/application area.

## Acceptance criteria

- [ ] Semantic behavior criterion.
- [ ] Failure/security criterion.
- [ ] Architecture/API criterion.
- [ ] Evidence/documentation criterion.

## Agent context contract

### Read set

- `path/or/glob`

### Write set

- `path/or/glob`

### Forbidden changes

- Route/API/dialect/security behavior not authorized here.
- Mandatory gates or thresholds.
- Files owned by parallel issues.
- Generated outputs by hand.

### Focused checks

```bash
bun test <focused>
```

### Full gate

```bash
bun run <milestone-or-release-gate>
```

### Parallel safety

```text
safe with:
unsafe with:
integration owner:
```

### Human gate

```text
none | maintainer credentials/approval/namespace/legal action
```

## Dependencies

- BR-XXX

## Blocks

- BR-YYY

## Evidence required for closure

- Commit/PR and baseline SHA.
- Exact versions and commands with exit status.
- Test/security/browser/benchmark/package artifacts.
- Public API/migration/security/performance notes.
- Residual risks and unblocked IDs.

## Stop conditions

Stop rather than weakening scope when evidence contradicts the issue, a dependency is incomplete, or a forbidden file/package edge is required.
