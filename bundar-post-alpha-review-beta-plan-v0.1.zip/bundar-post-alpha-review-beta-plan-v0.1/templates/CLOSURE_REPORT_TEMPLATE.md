---
type: Closure Report Template
title: Bundar Issue Closure Report Template
description: Standard evidence report for completed, already-satisfied, blocked, or
  split-required tasks.
tags:
- bundar
- closure
- evidence
- github
status: final
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Closure report

```markdown
Stable ID:
Issue URL:
Result: complete | already satisfied | blocked | split required

Baseline commit:
Implementation commit:
Pull request:
Author / agent:
Reviewer:

Outcome evidence:

Files changed:
- ...

Read-set deviations:
- none | ...

Write-set deviations:
- none | ...

Commands executed:
| Command | Environment/version | Exit | Result/artifact |
| --- | --- | ---: | --- |
| `...` | ... | 0 | ... |

Acceptance criteria:
- [x] ...
- [ ] ... — blocker/reason

Public API / type / route / HTML changes:

Compatibility and migration:

Security impact:

Performance impact:

Documentation and agent maps updated:

Generated artifacts:

Residual risks:
- severity:
- affected users:
- workaround:
- owner:
- review trigger:

Newly unblocked stable IDs:

Rollback:

Notes:
```

## Result rules

### `complete`

All mandatory criteria pass.

### `already satisfied`

Current source already satisfies the issue; attach the same evidence that would have closed an implementation.

### `blocked`

Name the external/dependency/contract blocker. Do not report partial work as completion.

### `split required`

Explain why one bounded outcome cannot be delivered safely and propose child IDs/dependency changes.
