---
type: Release Criteria
title: Bundar Beta Exit Criteria
description: Binary evidence requirements for declaring Bundar beta-ready without
  waiting for htmx 4 GA.
tags:
- bundar
- beta
- release-gate
- criteria
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Beta exit criteria

Beta is a public confidence level, not a percentage or a date. The candidate is beta-ready only when every mandatory criterion below is evidenced from one immutable commit.

## G0 — Candidate identity

- [ ] Full commit SHA, tag, package versions, Bun version, OS/tool versions, htmx pins, and approval identity recorded.
- [ ] All generated artifacts bind to the same commit.
- [ ] No uncommitted generated/doc drift.
- [ ] Zero unresolved P0 issues.
- [ ] Every P1 is closed or accepted in the gate with owner, impact, workaround, and review trigger.

## G1 — Correctness and trust contracts

- [ ] Middleware composition-count test proves compile-once behavior.
- [ ] Sync middleware fast path has semantic and performance evidence.
- [ ] Raw HTML trust boundary cannot be forged accidentally under the documented threat model.
- [ ] Unsafe sink audit passes.
- [ ] Stable framework error codes and redaction pass.
- [ ] HTTP method, route edge, body consumption, and stream conformance pass.

## G2 — Package and API integrity

- [ ] Package dependency ADR accepted.
- [ ] Architecture checks enforce manifests and source imports.
- [ ] HTMX protocol ownership matches the ADR.
- [ ] Form workflow ownership is unambiguous.
- [ ] Every export map passes packed external type/runtime consumers.
- [ ] Migration/re-export policy is documented and tested.
- [ ] API docs have no drift.

## G3 — Application and agent experience

- [ ] Minimal starter uses actual TSX.
- [ ] Compact and feature scaffolds pass clean-room journeys.
- [ ] Minimal, Todo, and Admin follow the documented dependency direction.
- [ ] Domain/actions import no Request/Response/JSX/HTMX.
- [ ] Typed URLs are dogfooded.
- [ ] Reference apps use typed action/update and security helpers rather than manual assembly.
- [ ] Local agent maps validate.
- [ ] `inspect --json` and `agent-context` are deterministic and secret-free.
- [ ] Independent greenfield study is recorded.

## G4 — Progressive enhancement and HTMX

- [ ] Stable htmx 2 full-page, fragment, form, validation, navigation, history, OOB/update, error, and local-asset lanes pass.
- [ ] No-JS core journeys pass through PRG.
- [ ] Same application source runs against experimental htmx 4 except the selected dialect/asset.
- [ ] Bundar audit and official upgrade-check findings are reconciled.
- [ ] Cache variation and history safety are proven.
- [ ] No stable htmx 4 GA claim is made unless M7 separately passes.

## G5 — Security and production posture

- [ ] Startup/readiness/drain/stop and abort propagation pass.
- [ ] Trusted proxy/origin contract passes direct and proxy fixtures.
- [ ] Production refuses fixture memory sessions/insecure cookie posture by default.
- [ ] Session fixation/rotation/logout/replay tests pass.
- [ ] Redirect and HTMX header injection tests pass.
- [ ] CSP nonce integration passes browser tests.
- [ ] Multipart/form complexity limits clean up resources and fail closed.
- [ ] Property/fuzz smoke suite passes with replayable seeds.
- [ ] Security docs clearly distinguish primitives from certification.

## G6 — Browser and accessibility claims

- [ ] Chromium stable lane passes.
- [ ] Firefox and WebKit pass or the support claim is explicitly narrowed.
- [ ] No-JS and keyboard journeys pass.
- [ ] Automated critical/serious accessibility violations are zero or explicitly waived.
- [ ] Browser versions and deviations are machine-readable.

## G7 — Performance

- [ ] Middleware regression budget passes.
- [ ] Large table string/stream, fragment, update, and form scenarios pass ratio-based budgets.
- [ ] Environment/raw data retained.
- [ ] Response equivalence verified before comparison.
- [ ] No unsupported “fastest” claim.
- [ ] Rust/native acceleration remains unnecessary unless a separate measured issue is approved.

## G8 — Distribution

- [ ] Human npm/registry gate complete.
- [ ] Audited tarballs published under the intended pre-release tag.
- [ ] Registry integrity/provenance matches candidate artifacts.
- [ ] Clean external repository installs and runs published packages.
- [ ] Alpha-to-beta migration fixture passes.
- [ ] README install commands match actual registry state.
- [ ] Rollback/deprecation plan recorded.

## G9 — Decision

The gate document ends with one of:

```text
GO
NO-GO
```

A GO includes accepted residual risks. A NO-GO lists blocking stable IDs.

“Mostly green,” “95%,” or “code complete” is not a valid release decision.
