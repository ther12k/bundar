---
type: Compatibility Review
title: HTMX 2 to HTMX 4 Migration Strategy Review
description: Assessment and preservation rules for Bundar's stable htmx 2 and experimental
  htmx 4 adapter strategy.
tags:
- bundar
- htmx
- compatibility
- migration
- htmx4
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# HTMX migration strategy review

## Verdict

Bundar's central migration strategy is correct and should be preserved:

> Application code targets a normalized Bundar contract; version-sensitive request/response behavior stays in selected HTMX dialect adapters.

HTMX 4 GA is not required to make Bundar beta-ready. Stable htmx 2 can remain the supported default while htmx 4 beta remains opt-in and experimental.

## Required unchanged application boundary

Switching the selected dialect should not require edits to:

- domain types;
- repository ports/adapters;
- application actions;
- validation schemas;
- page and fragment components;
- route/business workflow logic;
- tests written against normalized Bundar helpers.

Expected change:

```diff
-import { htmx2 } from "@bundar/htmx/2";
-export const dialect = htmx2;
+import { htmx4Experimental } from "@bundar/htmx/4";
+export const dialect = htmx4Experimental;
```

The pinned official browser asset changes with it.

## Why the package-boundary reset matters

The dialect package should not own general form validation or application transactions. The more unrelated behavior lives inside `@bundar/htmx`, the harder it becomes to distinguish:

```text
HTMX wire difference
from
Bundar form/application behavior
```

Moving neutral form orchestration to `@bundar/forms` makes HTMX 4 adaptation smaller and testable over standard web objects.

## Stable application subset

Bundar should continue to normalize:

- request metadata and request type;
- boosted/history/restore semantics;
- complete-page versus fragment selection;
- cache `Vary` policy;
- redirect/location/history directives;
- event serialization;
- target/swap/reselect intent;
- primary plus secondary updates;
- lifecycle event mapping;
- local asset version/integrity.

Applications may use raw HTMX attributes that remain stable, but version-specific escape hatches must be reported by the audit tool.

## Beta-era checks

Before Bundar beta:

- [ ] Same reference-app source runs in htmx 2 and htmx 4-beta lanes.
- [ ] Raw `HX-*` interpretation remains inside the adapter package.
- [ ] No core/action/domain file imports versioned adapter internals.
- [ ] Official upgrade-check findings are mapped to Bundar audit findings.
- [ ] Known beta deviations are listed, tested, and labeled experimental.
- [ ] htmx 2 remains the scaffold/default.
- [ ] No documentation says htmx 4 stable/GA.
- [ ] One-file rollback to htmx 2 remains possible.

## GA trigger

Only an official htmx 4 GA release reopens the recorded M7 chain:

```text
source snapshot
→ beta-versus-GA contract diff
→ adapter update
→ dual-version regression
→ unchanged-app proof
→ migration/deprecation report
→ default-dialect ADR
→ stable support release
```

Do not reopen based on a predicted date, blog estimate, or secondary report.

## Potential future improvement

After the package reset, expose a dialect-agnostic application protocol test kit. A third-party adapter could implement it without changing Bundar core. That is a useful extension boundary, but it should not expand beta scope unless a real adapter exists.
