---
type: Architecture Recommendation
title: Post-Alpha Package Boundary Recommendation
description: Recommended package ownership and dependency graph before Bundar packages
  are published.
tags:
- bundar
- packages
- architecture
- forms
- htmx
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Package boundary recommendation

## Problem

Bundar's migration safety depends on HTMX version details staying isolated. The inspected package surface shows HTMX also carrying core/schema/form workflow coupling, while package documentation describes a narrower protocol layer.

This is the right moment to correct ownership because registry consumers do not yet depend on the current private `0.0.0` workspace layout.

## Recommended graph

```text
@bundar/jsx
    runtime dependencies: none

@bundar/core
    runtime dependencies: none
    owns: App, route compiler, Context, middleware, Request/Response helpers,
          cookies, bounded raw body access, errors, lifecycle

@bundar/htmx
    depends on: @bundar/jsx
    owns: normalized request metadata, dialect interface, /2 and /4 adapters,
          response directives, page/fragment negotiation, assets/scripts,
          normalized update serialization
    MUST NOT depend on: @bundar/core, @bundar/schema, @bundar/security

@bundar/forms
    depends on: the minimum approved web/core contracts
    owns: form action contracts, parse/validate/mutate sequence,
          retained values, field errors, transaction hooks,
          ordinary/enhanced representation port
    does not know raw HTMX headers or dialect versions

@bundar/schema
    depends on: Standard Schema types/protocol only as designed
    owns: validation adapter, structured issues, redaction
    exposes an adapter consumed by forms

@bundar/security
    owns: sessions, CSRF, origin/trusted proxy, cookie posture,
          CSP, upload policy, security middleware
    integrates through explicit core/forms ports

@bundar/testing
    depends on public package surfaces
    owns: in-process client and ordinary/enhanced fixtures

@bundar/cli
    may depend on package metadata and public tooling APIs
    owns: dev, inspect, routes, architecture checks, htmx audit,
          agent context, scaffolding support
```

## Why `@bundar/forms`

Form workflow is not inherently HTMX:

```text
parse → validate → retain safe values → invoke action → commit/rollback
```

Only the final representation differs:

```text
ordinary → 303 redirect / full page
enhanced → fragment / update response
```

The form package should accept a small representation adapter. `@bundar/htmx` can provide the enhanced adapter without owning validation or application transactions.

## Dependency rules

| From | May depend on | Must not depend on |
| --- | --- | --- |
| core | web/Bun types and internal zero-dep code | JSX, HTMX, schema, security, application packages |
| JSX | zero-dep renderer internals | core, HTMX, forms, schema, security |
| HTMX | JSX and web standards | core, schema, security, concrete validators |
| forms | approved neutral HTTP/form contracts; optional adapters | versioned HTMX headers/dialects, concrete app services |
| schema | Standard Schema contract | HTMX, app kernel |
| security | explicit core/forms interfaces | application auth product, hidden global state |
| testing | public APIs | package-private source |
| CLI | public metadata/tooling contracts | application runtime hidden state |

BR-011 is the binding ADR. When source evidence shows a smaller graph is impractical, change the ADR explicitly rather than hiding an exception.

## Compatibility plan

1. Freeze the graph.
2. Add machine enforcement.
3. Create `@bundar/forms`.
4. Move contracts before runtime behavior.
5. Make HTMX protocol-pure.
6. Add temporary re-exports only where they do not recreate forbidden edges.
7. Generate migration docs.
8. Test packed external consumers.
9. Publish only after tarball/export audit.

## Public API principle

A capability has one preferred import path:

```ts
import { App } from "@bundar/core";
import { document } from "@bundar/jsx";
import { view, actionResponse } from "@bundar/htmx";
import { runFormAction } from "@bundar/forms";
import { standardSchema } from "@bundar/schema";
import { csrf, sessions } from "@bundar/security";
```

Subpath exports may express stable dialect choices:

```ts
import { htmx2 } from "@bundar/htmx/2";
import { htmx4Experimental } from "@bundar/htmx/4";
```

Do not create dozens of public packages for tiny internal helpers.

## Alternative considered: accept current coupling

This is viable but weaker. It would require updating the package README/ADR to say HTMX owns progressive forms and schema integration. The downside is that the version-migration-critical package becomes a general web workflow package, harder to reuse/test independently and more likely to accumulate unrelated dependencies.

The review recommends extraction, but BR-011 should compare actual import count, bundle impact, API churn, and test complexity before final acceptance.
