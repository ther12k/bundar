---
type: Architecture Specification
title: Agent-Friendly Bundar Application Structure
description: Canonical feature-sliced structure separating server UI, HTTP orchestration,
  application actions, domain contracts, and persistence for human and AI readability.
tags:
- bundar
- architecture
- application-structure
- ai-agent
- tsx
- htmx
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Agent-friendly application structure

## Decision

Bundar applications remain **one full-stack server-rendered codebase**, but UI, HTTP orchestration, application logic, domain contracts, and persistence live in separate predictable files.

Do not interpret “separate frontend and backend” as two repositories or a JSON API boundary. In Bundar, the server renders the UI; forcing a separate frontend creates duplication the framework exists to remove.

The separation boundary is **source ownership**, not deployment:

```text
one deployable Bun application
├── server-rendered UI files
├── route/HTMX adapter files
├── application-action files
├── domain/read-model files
└── repository ports and adapters
```

## Canonical tree

```text
src/
  main.ts
  app.ts

  platform/
    env.ts
    dialect.ts
    lifecycle.ts
    sessions.ts
    middleware.ts
    errors.ts

  shared/
    ui/
      app-layout.tsx
      flash-region.tsx
    domain/
      pagination.ts
    testing/
      fixture.ts

  features/
    todos/
      index.ts
      AGENTS.md

      todo.types.ts
      todo.schema.ts
      todo.repository.ts
      todo.actions.ts
      todo.routes.ts

      ui/
        todo.view.tsx
        todo.components.tsx
        todo.regions.ts

      data/
        todo.memory-repository.ts
        todo.sqlite-repository.ts

      tests/
        todo.actions.test.ts
        todo.view.test.tsx
        todo.routes.test.ts
        todo.browser.test.ts
```

A smaller application may start compact:

```text
src/
  main.ts
  app.ts
  layout.tsx
  dialect.ts
```

The compact starter must still avoid a mega-file. It should graduate to feature slices when one of these occurs:

- a feature has more than one route or mutation;
- `app.ts` combines UI, validation, and persistence;
- one file crosses the hard responsibility/size budget;
- two people/agents need to work on the feature concurrently;
- a domain rule needs testing without HTTP;
- more than one storage adapter exists;
- region/update contracts become nontrivial.

## File responsibilities

### `main.ts`

Owns:

- environment/bootstrap;
- `Bun.serve()`;
- lifecycle startup/readiness/shutdown;
- signal handling;
- top-level ErrorBoundary wiring;
- listening log.

Must not own:

- JSX page definitions;
- business rules;
- repositories;
- route-specific validation.

### `app.ts`

Owns:

- creating `App`;
- mounting shared middleware;
- composing feature route modules;
- not-found/error policy configuration;
- returning compiled app configuration.

Must not own:

- feature UI;
- feature schemas;
- data implementations;
- large route handlers.

### `*.routes.ts`

Owns:

- route registration;
- path/method/name;
- request metadata and bounded parsing;
- session/CSRF/authorization adapter use;
- invoking application actions;
- mapping action outcomes to full-page, fragment, redirect, or update responses;
- HTTP status, response headers, cache/history behavior.

Must not own:

- database queries/implementation;
- business decisions;
- long JSX trees;
- raw HTMX version conditionals;
- server startup.

### `*.actions.ts`

Owns:

- application use cases;
- business validation and policy after input validation;
- repository-port calls;
- transactions through an injected port;
- typed outcomes/read models.

Must not import:

```text
@bundar/jsx
@bundar/htmx
Request
Response
BunRequest
route Context
concrete database adapters
```

Actions receive plain values and explicit dependencies:

```ts
export interface CreateTodoDeps {
  todos: TodoRepository;
  clock: Clock;
}

export async function createTodo(
  deps: CreateTodoDeps,
  command: CreateTodoCommand,
  signal?: AbortSignal,
): Promise<CreateTodoResult> {
  // domain/application behavior only
}
```

### `*.schema.ts`

Owns:

- input schemas;
- normalized input types;
- field names/paths;
- safe retained-value policy.

Must not render field errors or create Responses.

### `*.types.ts`

Owns:

- domain records;
- commands;
- read models;
- typed action outcomes;
- stable IDs/enums.

Prefer transport-neutral types. Do not add HTTP status or HTMX selector fields to domain records.

### `*.repository.ts`

Owns:

- repository/port interfaces;
- capability contracts;
- transaction boundary abstractions if feature-specific.

Concrete adapters belong under `data/`.

### `*.view.tsx`

Owns:

- full pages;
- fragments;
- form/error/success states;
- mapping typed view models to server JSX.

Must not:

- query repositories;
- mutate state;
- parse requests;
- rotate sessions;
- choose database transactions.

### `*.components.tsx`

Owns reusable feature UI. Keep components boring functions over typed props.

Standard HTMX attributes stay visible:

```tsx
<button
  hx-delete={routes.todos.delete({ id: todo.id })}
  hx-target={`#todo-${todo.id}`}
  hx-swap="outerHTML"
>
  Delete
</button>
```

Do not wrap this in a proprietary `<HxDeleteButton request={...} />` unless the component is genuinely application-specific.

### `*.regions.ts`

Owns stable DOM region IDs and update targets:

```ts
export const TodoRegions = {
  list: "todo-list",
  count: "todo-count",
  flash: "flash-region",
} as const;
```

This prevents string drift between views, routes, update intents, and browser tests.

## Dependency direction

```text
platform ──────────────→ framework packages

routes ────────────────→ actions
routes ────────────────→ views
routes ────────────────→ platform adapters

actions ───────────────→ domain/types
actions ───────────────→ repository ports

views ─────────────────→ domain read models
views ─────────────────→ route URL helpers
views ─────────────────→ region IDs

data adapters ─────────→ repository ports
data adapters ─────────→ database/library

domain/actions ─X──────→ routes, Request, Response, JSX, HTMX
views          ─X──────→ data adapters, session stores, parsers
features       ─X──────→ another feature's private files
```

Cross-feature calls go through a declared public entrypoint or shared application service, not relative imports into private directories.

## Route orchestration example

```tsx
export function registerTodoRoutes(
  app: App,
  deps: TodoRouteDeps,
): void {
  app.post(
    routes.todos.create.pattern,
    async (context) =>
      runFormAction(context.request, {
        schema: CreateTodoSchema,
        csrf: deps.csrf,
        async action(input, signal) {
          return createTodo(deps.actions, input, signal);
        },
        ordinary(result) {
          return redirect(routes.todos.index(), 303);
        },
        enhanced(result) {
          return actionResponse({
            primary: <TodoRow todo={result.todo} />,
            updates: [
              replace(TodoRegions.count, <TodoCount count={result.count} />),
            ],
          });
        },
      }),
    { name: routes.todos.create.name },
  );
}
```

The route knows HTTP and representation. `createTodo()` does not.

## Why this helps AI agents

### Smaller read sets

A UI request usually needs:

```text
todo.view.tsx
todo.components.tsx
todo.types.ts
todo.regions.ts
view tests
AGENTS.md
```

It does not need the SQLite adapter or CSRF implementation.

A business-rule request usually needs:

```text
todo.actions.ts
todo.types.ts
todo.repository.ts
action tests
AGENTS.md
```

It does not need TSX, HTMX, or Bun route internals.

### Safer write sets

Issue metadata can allow only:

```yaml
write_set:
  - src/features/todos/ui/**
  - src/features/todos/tests/todo.view.test.tsx
forbidden_changes:
  - route paths
  - repository contracts
  - session policy
```

This makes parallel worktree conflicts and accidental architectural changes easier to detect.

### Predictable search

Agents do not need to infer whether business logic lives in a controller, service, model hook, JSX component, or middleware. File suffixes declare ownership.

### Local context maps

Each feature `AGENTS.md` should fit within a small budget and include:

- purpose;
- public entrypoint;
- invariants;
- routes and stable region IDs;
- direct dependencies;
- allowed/forbidden imports;
- common change recipes;
- focused commands;
- escalation conditions.

It should link to root policies rather than copying them.

### Deterministic tooling

Recommended machine surfaces:

```bash
bundar inspect --json
bundar agent-context todos --format json --max-bytes 50000
bundar routes check --json
bundar app architecture-check --json
```

Output must be deterministic, offline, secret-free, and versioned.

## File budgets

Suggested starting soft/hard limits:

| File type | Soft | Hard | Notes |
| --- | ---: | ---: | --- |
| route module | 180 lines | 280 lines | Split by route group before hard limit |
| action module | 180 | 300 | Split by use-case cluster |
| view/page module | 220 | 350 | Large static markup may justify exception |
| component module | 220 | 350 | Prefer cohesive component families |
| schema/types | 180 | 300 | Generated types excluded |
| local `AGENTS.md` | 120 | 200 | Link, do not duplicate |
| `app.ts` composition | 120 | 200 | Should stay mostly mounting/wiring |
| `main.ts` bootstrap | 100 | 160 | Lifecycle only |

These are responsibility signals, not style dogma. Exceptions require owner, reason, and review date.

## What not to do

- Do not create a frontend repository plus backend API solely for organization.
- Do not add automatic route/file discovery that hides execution order.
- Do not turn actions into classes only to resemble NestJS.
- Do not pass `Context` into business logic.
- Do not let views call repositories.
- Do not create a generic global `services/` folder containing unrelated features.
- Do not hide HTMX behind a Bundar-specific declarative DSL.
- Do not make an agent load the entire monorepo for a one-component task.
- Do not treat line count alone as architecture.

## Framework responsibility

Bundar should:

- document this structure;
- scaffold compact and feature presets;
- provide app import-boundary checks;
- expose typed route/region/project manifests;
- provide bounded agent-context packs;
- demonstrate the structure in minimal, Todo, and Admin;
- keep runtime APIs usable outside this structure.

Bundar should **not** require a specific directory layout at runtime or scan the filesystem to discover routes automatically.
