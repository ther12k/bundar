---
type: Execution Plan
title: Bundar Topological Execution Waves
description: Dependency-derived waves for the 85 post-alpha microtasks.
tags:
- bundar
- dependencies
- execution-waves
- agents
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Execution waves

A wave lists issues whose declared dependencies are complete at the start of that wave. It does **not** guarantee write-set independence.

## Wave 1

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-001](../issues/m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md) | M8.0 | P0 | XS | Freeze the post-alpha audit baseline and provenance |

## Wave 2

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-002](../issues/m8-0-correctness/br-002-add-a-regression-probe-for-middleware-composition-count.md) | M8.0 | P0 | S | Add a regression probe for middleware composition count |
| [BR-005](../issues/m8-0-correctness/br-005-reproduce-and-threat-model-raw-html-brand-forgery.md) | M8.0 | P0 | S | Reproduce and threat-model raw HTML brand forgery |
| [BR-008](../issues/m8-0-correctness/br-008-replace-the-stale-design-bundle-root-readme.md) | M8.0 | P0 | XS | Replace the stale design-bundle root README |
| [BR-010](../issues/m8-0-correctness/br-010-reconcile-stale-milestone-and-release-claims-across-the-corpus.md) | M8.0 | P1 | S | Reconcile stale milestone and release claims across the corpus |
| [BR-011](../issues/m8-1-package-boundaries/br-011-decide-and-freeze-the-post-alpha-package-dependency-graph.md) | M8.1 | P0 | S | Decide and freeze the post-alpha package dependency graph |
| [BR-021](../issues/m8-2-agent-architecture/br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md) | M8.2 | P0 | S | Adopt a feature-sliced application structure for agent-friendly Bundar apps |
| [BR-046](../issues/m8-3-agent-tooling/br-046-standardize-deterministic-machine-readable-cli-behavior.md) | M8.3 | P1 | M | Standardize deterministic machine-readable CLI behavior |
| [BR-059](../issues/m8-4-production-security/br-059-define-the-trusted-proxy-client-ip-scheme-host-and-origin-model.md) | M8.4 | P1 | S | Define the trusted proxy, client IP, scheme, host, and origin model |
| [BR-061](../issues/m8-4-production-security/br-061-define-durable-session-store-capabilities-and-failure-semantics.md) | M8.4 | P1 | S | Define durable session-store capabilities and failure semantics |

## Wave 3

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-003](../issues/m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md) | M8.0 | P0 | M | Move middleware composition fully into the compile phase |
| [BR-006](../issues/m8-0-correctness/br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md) | M8.0 | P0 | M | Make the raw HTML trust marker non-accidentally forgeable |
| [BR-009](../issues/m8-0-correctness/br-009-generate-readme-status-facts-and-fail-on-drift.md) | M8.0 | P1 | S | Generate README status facts and fail on drift |
| [BR-012](../issues/m8-1-package-boundaries/br-012-enforce-the-package-dependency-graph-in-ci.md) | M8.1 | P0 | S | Enforce the package dependency graph in CI |
| [BR-013](../issues/m8-1-package-boundaries/br-013-create-the-bundar-forms-package-skeleton.md) | M8.1 | P0 | S | Create the `@bundar/forms` package skeleton |
| [BR-022](../issues/m8-2-agent-architecture/br-022-define-application-import-direction-and-agent-read-write-zones.md) | M8.2 | P0 | S | Define application import direction and agent read/write zones |
| [BR-060](../issues/m8-4-production-security/br-060-implement-secure-cookie-behavior-behind-explicit-trusted-proxies.md) | M8.4 | P1 | M | Implement secure-cookie behavior behind explicit trusted proxies |

## Wave 4

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-004](../issues/m8-0-correctness/br-004-guard-middleware-hot-path-allocations-with-a-release-budget.md) | M8.0 | P1 | S | Guard middleware hot-path allocations with a release budget |
| [BR-007](../issues/m8-0-correctness/br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md) | M8.0 | P1 | M | Audit every renderer, header, and HTMX unsafe sink |
| [BR-014](../issues/m8-1-package-boundaries/br-014-extract-framework-neutral-form-action-contracts.md) | M8.1 | P0 | S | Extract framework-neutral form action contracts |
| [BR-023](../issues/m8-2-agent-architecture/br-023-implement-an-application-feature-boundary-checker.md) | M8.2 | P1 | M | Implement an application feature-boundary checker |
| [BR-044](../issues/m8-2-agent-architecture/br-044-add-concise-local-agents-md-and-feature-map-templates.md) | M8.2 | P1 | S | Add concise local `AGENTS.md` and feature-map templates |
| [BR-049](../issues/m8-3-agent-tooling/br-049-adopt-agent-ready-github-issue-read-write-check-contracts.md) | M8.3 | P1 | S | Adopt agent-ready GitHub issue read/write/check contracts |
| [BR-057](../issues/m8-4-production-security/br-057-define-startup-readiness-shutdown-and-graceful-stop-lifecycle.md) | M8.4 | P1 | M | Define startup, readiness, shutdown, and graceful-stop lifecycle |
| [BR-062](../issues/m8-4-production-security/br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md) | M8.4 | P0 | S | Fail closed on memory sessions or insecure cookies in production |

## Wave 5

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-015](../issues/m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md) | M8.1 | P0 | M | Move progressive form orchestration into `@bundar/forms` |
| [BR-045](../issues/m8-2-agent-architecture/br-045-introduce-file-size-and-responsibility-budgets-with-explicit-exceptions.md) | M8.2 | P2 | S | Introduce file-size and responsibility budgets with explicit exceptions |
| [BR-047](../issues/m8-3-agent-tooling/br-047-add-bundar-inspect-json-for-routes-packages-and-feature-boundaries.md) | M8.3 | P2 | M | Add `bundar inspect --json` for routes, packages, and feature boundaries |
| [BR-063](../issues/m8-4-production-security/br-063-close-session-fixation-rotation-logout-and-replay-tests.md) | M8.4 | P1 | M | Close session fixation, rotation, logout, and replay tests |

## Wave 6

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-016](../issues/m8-1-package-boundaries/br-016-isolate-standard-schema-integration-behind-a-forms-adapter.md) | M8.1 | P1 | S | Isolate Standard Schema integration behind a forms adapter |
| [BR-048](../issues/m8-3-agent-tooling/br-048-add-bundar-agent-context-feature-bounded-context-packs.md) | M8.3 | P2 | M | Add `bundar agent-context <feature>` bounded context packs |
| [BR-058](../issues/m8-4-production-security/br-058-propagate-request-cancellation-through-context-forms-and-streams.md) | M8.4 | P1 | M | Propagate request cancellation through context, forms, and streams |
| [BR-066](../issues/m8-4-production-security/br-066-enforce-multipart-and-form-request-complexity-limits.md) | M8.4 | P1 | M | Enforce multipart and form request-complexity limits |

## Wave 7

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-017](../issues/m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md) | M8.1 | P0 | M | Make `@bundar/htmx` protocol-pure |

## Wave 8

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-018](../issues/m8-1-package-boundaries/br-018-provide-compatibility-re-exports-for-moved-form-apis.md) | M8.1 | P1 | S | Provide compatibility re-exports for moved form APIs |
| [BR-024](../issues/m8-2-agent-architecture/br-024-create-the-canonical-feature-slice-scaffold-tree.md) | M8.2 | P1 | S | Create the canonical feature-slice scaffold tree |
| [BR-026](../issues/m8-2-agent-architecture/br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md) | M8.2 | P0 | S | Convert the canonical minimal starter UI to actual TSX |
| [BR-032](../issues/m8-2-agent-architecture/br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md) | M8.2 | P1 | S | Create the Todo feature-slice skeleton and migration map |
| [BR-038](../issues/m8-2-agent-architecture/br-038-inventory-and-scaffold-admin-reference-features.md) | M8.2 | P1 | S | Inventory and scaffold Admin reference features |
| [BR-052](../issues/m8-3-agent-tooling/br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md) | M8.3 | P1 | M | Add a typed primary-fragment and update-intent response API |
| [BR-064](../issues/m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md) | M8.4 | P0 | M | Validate redirect targets and all HTMX response header values |
| [BR-065](../issues/m8-4-production-security/br-065-integrate-csp-nonces-with-documents-and-htmxscript.md) | M8.4 | P1 | M | Integrate CSP nonces with documents and `HtmxScript` |
| [BR-067](../issues/m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md) | M8.4 | P1 | M | Define stable framework error codes and redaction policy |
| [BR-076](../issues/m8-5-conformance-performance/br-076-add-carno-js-as-a-fair-backend-framework-benchmark-reference.md) | M8.5 | P2 | M | Add Carno.js as a fair backend-framework benchmark reference |

## Wave 9

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-019](../issues/m8-1-package-boundaries/br-019-add-packed-external-type-consumers-for-every-public-export-map.md) | M8.1 | P1 | M | Add packed external type consumers for every public export map |
| [BR-025](../issues/m8-2-agent-architecture/br-025-expose-create-bundar-structure-feature.md) | M8.2 | P1 | M | Expose `create-bundar --structure feature` |
| [BR-027](../issues/m8-2-agent-architecture/br-027-extract-the-minimal-starter-validation-schema.md) | M8.2 | P1 | XS | Extract the minimal starter validation schema |
| [BR-028](../issues/m8-2-agent-architecture/br-028-extract-the-minimal-starter-views-and-components.md) | M8.2 | P1 | S | Extract the minimal starter views and components |
| [BR-033](../issues/m8-2-agent-architecture/br-033-move-todo-domain-types-and-repository-ports.md) | M8.2 | P1 | S | Move Todo domain types and repository ports |
| [BR-039](../issues/m8-2-agent-architecture/br-039-split-admin-domain-models-and-repository-ports.md) | M8.2 | P1 | M | Split Admin domain models and repository ports |
| [BR-054](../issues/m8-3-agent-tooling/br-054-add-safe-response-header-and-cookie-mutation-helpers.md) | M8.3 | P1 | M | Add safe response header and cookie mutation helpers |
| [BR-068](../issues/m8-4-production-security/br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md) | M8.4 | P2 | M | Add property and fuzz tests for high-risk parsers and serializers |
| [BR-069](../issues/m8-5-conformance-performance/br-069-close-http-method-conformance-for-head-options-405-and-allow.md) | M8.5 | P1 | M | Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow |
| [BR-070](../issues/m8-5-conformance-performance/br-070-close-route-edge-case-and-collision-conformance.md) | M8.5 | P1 | M | Close route edge-case and collision conformance |
| [BR-071](../issues/m8-5-conformance-performance/br-071-close-body-single-consumption-and-content-type-conformance.md) | M8.5 | P1 | M | Close body single-consumption and content-type conformance |
| [BR-072](../issues/m8-5-conformance-performance/br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md) | M8.5 | P1 | M | Close streaming backpressure, cancellation, and late-error conformance |

## Wave 10

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-020](../issues/m8-1-package-boundaries/br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md) | M8.1 | P1 | S | Regenerate package API docs, diagrams, and migration guidance |
| [BR-029](../issues/m8-2-agent-architecture/br-029-extract-the-minimal-starter-action-and-service-boundary.md) | M8.2 | P1 | S | Extract the minimal starter action and service boundary |
| [BR-034](../issues/m8-2-agent-architecture/br-034-extract-todo-schemas-and-application-actions.md) | M8.2 | P1 | M | Extract Todo schemas and application actions |
| [BR-035](../issues/m8-2-agent-architecture/br-035-extract-todo-pages-fragments-forms-and-components.md) | M8.2 | P1 | M | Extract Todo pages, fragments, forms, and components |
| [BR-040](../issues/m8-2-agent-architecture/br-040-extract-admin-validation-authorization-and-application-actions.md) | M8.2 | P1 | M | Extract Admin validation, authorization, and application actions |
| [BR-041](../issues/m8-2-agent-architecture/br-041-extract-admin-pages-tables-forms-dialogs-and-update-regions.md) | M8.2 | P1 | M | Extract Admin pages, tables, forms, dialogs, and update regions |
| [BR-055](../issues/m8-3-agent-tooling/br-055-add-csrf-form-field-and-session-token-composition-helpers.md) | M8.3 | P1 | M | Add CSRF form-field and session-token composition helpers |
| [BR-077](../issues/m8-5-conformance-performance/br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md) | M8.5 | P2 | M | Profile large-table rendering and form parsing, then set beta budgets |
| [BR-078](../issues/m8-6-beta-release/br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md) | M8.6 | P0 | S | Freeze alpha-to-beta versioning and publication policy |

## Wave 11

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-030](../issues/m8-2-agent-architecture/br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md) | M8.2 | P1 | S | Reduce the minimal route module to HTTP and hypermedia orchestration |
| [BR-036](../issues/m8-2-agent-architecture/br-036-extract-todo-route-registration-and-bootstrap-composition.md) | M8.2 | P1 | M | Extract Todo route registration and bootstrap composition |
| [BR-042](../issues/m8-2-agent-architecture/br-042-extract-admin-route-modules-and-runtime-bootstrap.md) | M8.2 | P1 | M | Extract Admin route modules and runtime bootstrap |
| [BR-073](../issues/m8-5-conformance-performance/br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md) | M8.5 | P1 | M | Revalidate the neutral HTMX contract against the official v4 upgrade checker |
| [BR-079](../issues/m8-6-beta-release/br-079-resolve-npm-namespace-credentials-provenance-and-human-approval-gate.md) | M8.6 | P0 | XS | Resolve npm namespace, credentials, provenance, and human approval gate |
| [BR-080](../issues/m8-6-beta-release/br-080-re-audit-tarballs-exports-licenses-sbom-and-provenance-after-refactors.md) | M8.6 | P0 | M | Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors |

## Wave 12

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-031](../issues/m8-2-agent-architecture/br-031-document-and-gate-the-minimal-starter-architecture.md) | M8.2 | P1 | XS | Document and gate the minimal starter architecture |
| [BR-037](../issues/m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md) | M8.2 | P1 | S | Close Todo feature-slice regression and source-diff evidence |
| [BR-043](../issues/m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md) | M8.2 | P1 | S | Close Admin feature-slice regression and architecture evidence |
| [BR-050](../issues/m8-3-agent-tooling/br-050-dogfood-generated-typed-urls-in-the-minimal-starter.md) | M8.3 | P1 | S | Dogfood generated typed URLs in the minimal starter |
| [BR-081](../issues/m8-6-beta-release/br-081-publish-a-guarded-canary-and-verify-registry-metadata.md) | M8.6 | P0 | S | Publish a guarded canary and verify registry metadata |

## Wave 13

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-051](../issues/m8-3-agent-tooling/br-051-dogfood-generated-typed-urls-in-todo-and-admin.md) | M8.3 | P1 | M | Dogfood generated typed URLs in Todo and Admin |
| [BR-053](../issues/m8-3-agent-tooling/br-053-remove-manual-html-concatenation-from-reference-applications.md) | M8.3 | P1 | S | Remove manual HTML concatenation from reference applications |
| [BR-074](../issues/m8-5-conformance-performance/br-074-add-firefox-and-webkit-browser-conformance-lanes.md) | M8.5 | P1 | M | Add Firefox and WebKit browser conformance lanes |
| [BR-075](../issues/m8-5-conformance-performance/br-075-add-no-javascript-and-accessibility-baseline-gates.md) | M8.5 | P1 | M | Add no-JavaScript and accessibility baseline gates |
| [BR-082](../issues/m8-6-beta-release/br-082-run-an-external-clean-repository-consumer-smoke-test.md) | M8.6 | P0 | M | Run an external clean-repository consumer smoke test |

## Wave 14

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-056](../issues/m8-3-agent-tooling/br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md) | M8.3 | P1 | S | Refactor examples away from manual cookie and Response reconstruction |
| [BR-083](../issues/m8-6-beta-release/br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md) | M8.6 | P1 | M | Build and verify an alpha-to-beta migration fixture |
| [BR-084](../issues/m8-6-beta-release/br-084-run-an-independent-greenfield-human-and-agent-usability-study.md) | M8.6 | P1 | M | Run an independent greenfield human-and-agent usability study |

## Wave 15

| ID | Milestone | Priority | Size | Task |
| --- | --- | --- | --- | --- |
| [BR-085](../issues/m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md) | M8.6 | P0 | M | Run the beta release gate and issue an evidence-backed go/no-go |

## Parallelism rule

Before assigning two issues in the same wave:

1. compare declared write sets;
2. compare generated-file ownership;
3. compare public API and package manifests;
4. compare shared examples and docs;
5. give each agent a separate worktree;
6. define merge order when one changes generated output consumed by another.

Do not parallelize tasks that both edit:

```text
package.json / lockfile
public export maps
route generator output
the same reference app bootstrap
shared security/response helpers
release artifacts
```

unless one issue explicitly owns integration.
