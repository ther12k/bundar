---
type: Risk Register
title: Bundar Post-Alpha Risk Register
description: Material technical, security, delivery, agent, compatibility, and publication
  risks with mitigation owners.
tags:
- bundar
- risk
- beta
- security
- agents
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Risk register

| ID | Risk | Impact | Likelihood | Mitigation | Owner role |
| --- | --- | --- | --- | --- | --- |
| R-01 | Release evidence trusted without fresh reproduction | Medium | High | BR-001 rebases and reruns focused/full gates; artifacts distinguish committed versus fresh evidence. | Engineering/release owner |
| R-02 | Middleware hot path violates compile-once contract | High | Medium-high | BR-002 semantic probe, BR-003 fix, BR-004 budget. | Core owner |
| R-03 | Raw HTML trust marker can be forged in a reachable path | Critical if reachable | Medium | BR-005 threat model, BR-006 opaque marker, BR-007 sink audit. | JSX/security owner |
| R-04 | Package refactor breaks alpha consumers or reintroduces cycles | High | Medium | BR-011 ADR, CI graph, compatibility re-exports, packed consumers, migration fixture. | Package/API owner |
| R-05 | Feature slicing becomes ceremony or runtime magic | Medium | Medium | Recommend/scaffold only; no filesystem route discovery; compact preset retained. | DX owner |
| R-06 | Parallel agents edit shared manifests/generated files | High | High | Read/write sets, parallel checker, worktrees, explicit integration owner. | Delivery owner |
| R-07 | Agent context packs omit a required invariant | High | Medium | Fail closed on declared dependency omission, size budget override, golden fixtures, independent study. | CLI/agent owner |
| R-08 | Reference refactor changes HTML/HTMX/no-JS behavior | High | Medium | Staged moves, byte/semantic snapshots, real-browser/no-JS/source-diff gates. | Examples owner |
| R-09 | Trusted proxy configuration enables spoofed origin/scheme | Critical | Medium | Explicit deny-by-default proxy model and security corpus. | Security owner |
| R-10 | Fixture session store copied into production | High | High | Production posture validation fails closed, durable-store contract, docs. | Security owner |
| R-11 | Header/redirect directive injection | Critical | Medium-low | Centralized typed validation and fuzz/property corpus. | Core/HTMX security owner |
| R-12 | Cross-browser work becomes flaky and gate is weakened | Medium | Medium | Separate consistent defects from flakes; fail-closed quarantine policy with owner/review trigger. | Browser owner |
| R-13 | Performance work distorts architecture or encourages native/Rust complexity | Medium | Medium | Target workload first, correctness equivalence, ratio budgets, separate measured ADR for native code. | Performance owner |
| R-14 | Canary publication exposes incorrect package metadata | High | Medium | Tarball audit, human gate, non-default tag, registry verify, rollback/deprecation plan. | Release maintainer |
| R-15 | htmx 4 beta changes invalidate adapter assumptions | Medium | High | Experimental label, official checker parity, unchanged-app fixture, upstream-triggered M7 GA chain. | HTMX owner |
| R-16 | Beta declared from a percentage rather than evidence | High | Medium | BR-085 binary GO/NO-GO and one-commit evidence manifest. | Maintainer |

## Escalation

Open a blocker/decision issue rather than weakening the selected task when:

- Bun native routing cannot express the required HTTP contract;
- the package graph requires a cycle or hidden runtime dependency;
- feature slicing requires runtime filesystem magic;
- a trust boundary cannot be made explicit;
- htmx beta and Bundar's normalized model materially diverge;
- a production-safe default would make the documented workflow impossible;
- a benchmark target requires unsafe buffering or parsing limits;
- publication identity/namespace cannot be verified;
- an agent needs to write outside its declared scope to satisfy acceptance criteria.

## Residual-risk rule

A residual risk accepted for beta must include:

```text
description
affected users/deployments
severity and likelihood
workaround
owner
review trigger/date
stable issue ID
documentation location
```

“Pre-1.0” is not a blanket waiver for security or misleading compatibility claims.
