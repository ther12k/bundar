---
type: Delivery Plan
title: Bundar Post-Alpha Roadmap
description: Milestone plan from alpha baseline to evidence-backed beta decision.
tags:
- bundar
- roadmap
- beta
- delivery
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Roadmap

## Strategy

The roadmap fixes trust and architecture first, then refactors examples, hardens production behavior, broadens conformance, and only then publishes a beta candidate.

Do not start with broad performance tuning or new features. The highest leverage sequence is:

```text
claims/correctness
→ package ownership
→ application structure
→ agent tooling and API dogfooding
→ production/security
→ conformance/performance
→ external publication and beta gate
```

## Milestones

### M8.0 — Post-alpha correctness and claim closure

**Goal:** Close factual/contract drift before expanding beta scope.

**Issues:** BR-001–BR-010 (10 microtasks)

**Exit conditions:**

- [ ] Audit baseline accepted
- [ ] Middleware and raw trust findings resolved or disproven
- [ ] README/status claims current and guarded

| ID | Priority | Size | Task |
| --- | --- | --- | --- |
| [BR-001](../issues/m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md) | P0 | XS | Freeze the post-alpha audit baseline and provenance |
| [BR-002](../issues/m8-0-correctness/br-002-add-a-regression-probe-for-middleware-composition-count.md) | P0 | S | Add a regression probe for middleware composition count |
| [BR-003](../issues/m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md) | P0 | M | Move middleware composition fully into the compile phase |
| [BR-004](../issues/m8-0-correctness/br-004-guard-middleware-hot-path-allocations-with-a-release-budget.md) | P1 | S | Guard middleware hot-path allocations with a release budget |
| [BR-005](../issues/m8-0-correctness/br-005-reproduce-and-threat-model-raw-html-brand-forgery.md) | P0 | S | Reproduce and threat-model raw HTML brand forgery |
| [BR-006](../issues/m8-0-correctness/br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md) | P0 | M | Make the raw HTML trust marker non-accidentally forgeable |
| [BR-007](../issues/m8-0-correctness/br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md) | P1 | M | Audit every renderer, header, and HTMX unsafe sink |
| [BR-008](../issues/m8-0-correctness/br-008-replace-the-stale-design-bundle-root-readme.md) | P0 | XS | Replace the stale design-bundle root README |
| [BR-009](../issues/m8-0-correctness/br-009-generate-readme-status-facts-and-fail-on-drift.md) | P1 | S | Generate README status facts and fail on drift |
| [BR-010](../issues/m8-0-correctness/br-010-reconcile-stale-milestone-and-release-claims-across-the-corpus.md) | P1 | S | Reconcile stale milestone and release claims across the corpus |

### M8.1 — Package-boundary reset

**Goal:** Reset package ownership before public registry consumers depend on it.

**Issues:** BR-011–BR-020 (10 microtasks)

**Exit conditions:**

- [ ] Dependency ADR enforced
- [ ] Forms ownership clear
- [ ] HTMX protocol-pure
- [ ] Packed consumers and API docs green

| ID | Priority | Size | Task |
| --- | --- | --- | --- |
| [BR-011](../issues/m8-1-package-boundaries/br-011-decide-and-freeze-the-post-alpha-package-dependency-graph.md) | P0 | S | Decide and freeze the post-alpha package dependency graph |
| [BR-012](../issues/m8-1-package-boundaries/br-012-enforce-the-package-dependency-graph-in-ci.md) | P0 | S | Enforce the package dependency graph in CI |
| [BR-013](../issues/m8-1-package-boundaries/br-013-create-the-bundar-forms-package-skeleton.md) | P0 | S | Create the `@bundar/forms` package skeleton |
| [BR-014](../issues/m8-1-package-boundaries/br-014-extract-framework-neutral-form-action-contracts.md) | P0 | S | Extract framework-neutral form action contracts |
| [BR-015](../issues/m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md) | P0 | M | Move progressive form orchestration into `@bundar/forms` |
| [BR-016](../issues/m8-1-package-boundaries/br-016-isolate-standard-schema-integration-behind-a-forms-adapter.md) | P1 | S | Isolate Standard Schema integration behind a forms adapter |
| [BR-017](../issues/m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md) | P0 | M | Make `@bundar/htmx` protocol-pure |
| [BR-018](../issues/m8-1-package-boundaries/br-018-provide-compatibility-re-exports-for-moved-form-apis.md) | P1 | S | Provide compatibility re-exports for moved form APIs |
| [BR-019](../issues/m8-1-package-boundaries/br-019-add-packed-external-type-consumers-for-every-public-export-map.md) | P1 | M | Add packed external type consumers for every public export map |
| [BR-020](../issues/m8-1-package-boundaries/br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md) | P1 | S | Regenerate package API docs, diagrams, and migration guidance |

### M8.2 — Agent-friendly application architecture

**Goal:** Make Bundar applications readable and safely changeable by humans and low-context agents.

**Issues:** BR-021–BR-045 (25 microtasks)

**Exit conditions:**

- [ ] Canonical feature structure documented/checked
- [ ] Minimal uses real TSX
- [ ] Todo/Admin feature-sliced with behavior parity
- [ ] Local agent maps and complexity budgets active

| ID | Priority | Size | Task |
| --- | --- | --- | --- |
| [BR-021](../issues/m8-2-agent-architecture/br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md) | P0 | S | Adopt a feature-sliced application structure for agent-friendly Bundar apps |
| [BR-022](../issues/m8-2-agent-architecture/br-022-define-application-import-direction-and-agent-read-write-zones.md) | P0 | S | Define application import direction and agent read/write zones |
| [BR-023](../issues/m8-2-agent-architecture/br-023-implement-an-application-feature-boundary-checker.md) | P1 | M | Implement an application feature-boundary checker |
| [BR-024](../issues/m8-2-agent-architecture/br-024-create-the-canonical-feature-slice-scaffold-tree.md) | P1 | S | Create the canonical feature-slice scaffold tree |
| [BR-025](../issues/m8-2-agent-architecture/br-025-expose-create-bundar-structure-feature.md) | P1 | M | Expose `create-bundar --structure feature` |
| [BR-026](../issues/m8-2-agent-architecture/br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md) | P0 | S | Convert the canonical minimal starter UI to actual TSX |
| [BR-027](../issues/m8-2-agent-architecture/br-027-extract-the-minimal-starter-validation-schema.md) | P1 | XS | Extract the minimal starter validation schema |
| [BR-028](../issues/m8-2-agent-architecture/br-028-extract-the-minimal-starter-views-and-components.md) | P1 | S | Extract the minimal starter views and components |
| [BR-029](../issues/m8-2-agent-architecture/br-029-extract-the-minimal-starter-action-and-service-boundary.md) | P1 | S | Extract the minimal starter action and service boundary |
| [BR-030](../issues/m8-2-agent-architecture/br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md) | P1 | S | Reduce the minimal route module to HTTP and hypermedia orchestration |
| [BR-031](../issues/m8-2-agent-architecture/br-031-document-and-gate-the-minimal-starter-architecture.md) | P1 | XS | Document and gate the minimal starter architecture |
| [BR-032](../issues/m8-2-agent-architecture/br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md) | P1 | S | Create the Todo feature-slice skeleton and migration map |
| [BR-033](../issues/m8-2-agent-architecture/br-033-move-todo-domain-types-and-repository-ports.md) | P1 | S | Move Todo domain types and repository ports |
| [BR-034](../issues/m8-2-agent-architecture/br-034-extract-todo-schemas-and-application-actions.md) | P1 | M | Extract Todo schemas and application actions |
| [BR-035](../issues/m8-2-agent-architecture/br-035-extract-todo-pages-fragments-forms-and-components.md) | P1 | M | Extract Todo pages, fragments, forms, and components |
| [BR-036](../issues/m8-2-agent-architecture/br-036-extract-todo-route-registration-and-bootstrap-composition.md) | P1 | M | Extract Todo route registration and bootstrap composition |
| [BR-037](../issues/m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md) | P1 | S | Close Todo feature-slice regression and source-diff evidence |
| [BR-038](../issues/m8-2-agent-architecture/br-038-inventory-and-scaffold-admin-reference-features.md) | P1 | S | Inventory and scaffold Admin reference features |
| [BR-039](../issues/m8-2-agent-architecture/br-039-split-admin-domain-models-and-repository-ports.md) | P1 | M | Split Admin domain models and repository ports |
| [BR-040](../issues/m8-2-agent-architecture/br-040-extract-admin-validation-authorization-and-application-actions.md) | P1 | M | Extract Admin validation, authorization, and application actions |
| [BR-041](../issues/m8-2-agent-architecture/br-041-extract-admin-pages-tables-forms-dialogs-and-update-regions.md) | P1 | M | Extract Admin pages, tables, forms, dialogs, and update regions |
| [BR-042](../issues/m8-2-agent-architecture/br-042-extract-admin-route-modules-and-runtime-bootstrap.md) | P1 | M | Extract Admin route modules and runtime bootstrap |
| [BR-043](../issues/m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md) | P1 | S | Close Admin feature-slice regression and architecture evidence |
| [BR-044](../issues/m8-2-agent-architecture/br-044-add-concise-local-agents-md-and-feature-map-templates.md) | P1 | S | Add concise local `AGENTS.md` and feature-map templates |
| [BR-045](../issues/m8-2-agent-architecture/br-045-introduce-file-size-and-responsibility-budgets-with-explicit-exceptions.md) | P2 | S | Introduce file-size and responsibility budgets with explicit exceptions |

### M8.3 — Agent tooling and API dogfooding

**Goal:** Turn agent friendliness and preferred APIs into first-party tooling and dogfooded examples.

**Issues:** BR-046–BR-056 (11 microtasks)

**Exit conditions:**

- [ ] Deterministic CLI machine mode
- [ ] Inspect/context packs available
- [ ] Typed URLs/action/update/security helpers used by examples

| ID | Priority | Size | Task |
| --- | --- | --- | --- |
| [BR-046](../issues/m8-3-agent-tooling/br-046-standardize-deterministic-machine-readable-cli-behavior.md) | P1 | M | Standardize deterministic machine-readable CLI behavior |
| [BR-047](../issues/m8-3-agent-tooling/br-047-add-bundar-inspect-json-for-routes-packages-and-feature-boundaries.md) | P2 | M | Add `bundar inspect --json` for routes, packages, and feature boundaries |
| [BR-048](../issues/m8-3-agent-tooling/br-048-add-bundar-agent-context-feature-bounded-context-packs.md) | P2 | M | Add `bundar agent-context <feature>` bounded context packs |
| [BR-049](../issues/m8-3-agent-tooling/br-049-adopt-agent-ready-github-issue-read-write-check-contracts.md) | P1 | S | Adopt agent-ready GitHub issue read/write/check contracts |
| [BR-050](../issues/m8-3-agent-tooling/br-050-dogfood-generated-typed-urls-in-the-minimal-starter.md) | P1 | S | Dogfood generated typed URLs in the minimal starter |
| [BR-051](../issues/m8-3-agent-tooling/br-051-dogfood-generated-typed-urls-in-todo-and-admin.md) | P1 | M | Dogfood generated typed URLs in Todo and Admin |
| [BR-052](../issues/m8-3-agent-tooling/br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md) | P1 | M | Add a typed primary-fragment and update-intent response API |
| [BR-053](../issues/m8-3-agent-tooling/br-053-remove-manual-html-concatenation-from-reference-applications.md) | P1 | S | Remove manual HTML concatenation from reference applications |
| [BR-054](../issues/m8-3-agent-tooling/br-054-add-safe-response-header-and-cookie-mutation-helpers.md) | P1 | M | Add safe response header and cookie mutation helpers |
| [BR-055](../issues/m8-3-agent-tooling/br-055-add-csrf-form-field-and-session-token-composition-helpers.md) | P1 | M | Add CSRF form-field and session-token composition helpers |
| [BR-056](../issues/m8-3-agent-tooling/br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md) | P1 | S | Refactor examples away from manual cookie and Response reconstruction |

### M8.4 — Production and security hardening

**Goal:** Close fail-closed production and security contracts.

**Issues:** BR-057–BR-068 (12 microtasks)

**Exit conditions:**

- [ ] Lifecycle/abort/proxy/session posture defined
- [ ] Header/CSP/body/error security gates pass
- [ ] Property/fuzz smoke evidence recorded

| ID | Priority | Size | Task |
| --- | --- | --- | --- |
| [BR-057](../issues/m8-4-production-security/br-057-define-startup-readiness-shutdown-and-graceful-stop-lifecycle.md) | P1 | M | Define startup, readiness, shutdown, and graceful-stop lifecycle |
| [BR-058](../issues/m8-4-production-security/br-058-propagate-request-cancellation-through-context-forms-and-streams.md) | P1 | M | Propagate request cancellation through context, forms, and streams |
| [BR-059](../issues/m8-4-production-security/br-059-define-the-trusted-proxy-client-ip-scheme-host-and-origin-model.md) | P1 | S | Define the trusted proxy, client IP, scheme, host, and origin model |
| [BR-060](../issues/m8-4-production-security/br-060-implement-secure-cookie-behavior-behind-explicit-trusted-proxies.md) | P1 | M | Implement secure-cookie behavior behind explicit trusted proxies |
| [BR-061](../issues/m8-4-production-security/br-061-define-durable-session-store-capabilities-and-failure-semantics.md) | P1 | S | Define durable session-store capabilities and failure semantics |
| [BR-062](../issues/m8-4-production-security/br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md) | P0 | S | Fail closed on memory sessions or insecure cookies in production |
| [BR-063](../issues/m8-4-production-security/br-063-close-session-fixation-rotation-logout-and-replay-tests.md) | P1 | M | Close session fixation, rotation, logout, and replay tests |
| [BR-064](../issues/m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md) | P0 | M | Validate redirect targets and all HTMX response header values |
| [BR-065](../issues/m8-4-production-security/br-065-integrate-csp-nonces-with-documents-and-htmxscript.md) | P1 | M | Integrate CSP nonces with documents and `HtmxScript` |
| [BR-066](../issues/m8-4-production-security/br-066-enforce-multipart-and-form-request-complexity-limits.md) | P1 | M | Enforce multipart and form request-complexity limits |
| [BR-067](../issues/m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md) | P1 | M | Define stable framework error codes and redaction policy |
| [BR-068](../issues/m8-4-production-security/br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md) | P2 | M | Add property and fuzz tests for high-risk parsers and serializers |

### M8.5 — Conformance, browsers, and performance

**Goal:** Broaden protocol/browser evidence and measure target workloads fairly.

**Issues:** BR-069–BR-077 (9 microtasks)

**Exit conditions:**

- [ ] HTTP edge and stream conformance pass
- [ ] HTMX upgrade parity recorded
- [ ] Claimed browsers/no-JS/a11y pass
- [ ] Target-workload budgets pass

| ID | Priority | Size | Task |
| --- | --- | --- | --- |
| [BR-069](../issues/m8-5-conformance-performance/br-069-close-http-method-conformance-for-head-options-405-and-allow.md) | P1 | M | Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow |
| [BR-070](../issues/m8-5-conformance-performance/br-070-close-route-edge-case-and-collision-conformance.md) | P1 | M | Close route edge-case and collision conformance |
| [BR-071](../issues/m8-5-conformance-performance/br-071-close-body-single-consumption-and-content-type-conformance.md) | P1 | M | Close body single-consumption and content-type conformance |
| [BR-072](../issues/m8-5-conformance-performance/br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md) | P1 | M | Close streaming backpressure, cancellation, and late-error conformance |
| [BR-073](../issues/m8-5-conformance-performance/br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md) | P1 | M | Revalidate the neutral HTMX contract against the official v4 upgrade checker |
| [BR-074](../issues/m8-5-conformance-performance/br-074-add-firefox-and-webkit-browser-conformance-lanes.md) | P1 | M | Add Firefox and WebKit browser conformance lanes |
| [BR-075](../issues/m8-5-conformance-performance/br-075-add-no-javascript-and-accessibility-baseline-gates.md) | P1 | M | Add no-JavaScript and accessibility baseline gates |
| [BR-076](../issues/m8-5-conformance-performance/br-076-add-carno-js-as-a-fair-backend-framework-benchmark-reference.md) | P2 | M | Add Carno.js as a fair backend-framework benchmark reference |
| [BR-077](../issues/m8-5-conformance-performance/br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md) | P2 | M | Profile large-table rendering and form parsing, then set beta budgets |

### M8.6 — Distribution and beta readiness

**Goal:** Prove real external distribution and issue the beta decision.

**Issues:** BR-078–BR-085 (8 microtasks)

**Exit conditions:**

- [ ] Registry human gate complete
- [ ] Canary packages externally install
- [ ] Migration and independent usability evidence pass
- [ ] One-commit beta GO/NO-GO recorded

| ID | Priority | Size | Task |
| --- | --- | --- | --- |
| [BR-078](../issues/m8-6-beta-release/br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md) | P0 | S | Freeze alpha-to-beta versioning and publication policy |
| [BR-079](../issues/m8-6-beta-release/br-079-resolve-npm-namespace-credentials-provenance-and-human-approval-gate.md) | P0 | XS | Resolve npm namespace, credentials, provenance, and human approval gate |
| [BR-080](../issues/m8-6-beta-release/br-080-re-audit-tarballs-exports-licenses-sbom-and-provenance-after-refactors.md) | P0 | M | Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors |
| [BR-081](../issues/m8-6-beta-release/br-081-publish-a-guarded-canary-and-verify-registry-metadata.md) | P0 | S | Publish a guarded canary and verify registry metadata |
| [BR-082](../issues/m8-6-beta-release/br-082-run-an-external-clean-repository-consumer-smoke-test.md) | P0 | M | Run an external clean-repository consumer smoke test |
| [BR-083](../issues/m8-6-beta-release/br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md) | P1 | M | Build and verify an alpha-to-beta migration fixture |
| [BR-084](../issues/m8-6-beta-release/br-084-run-an-independent-greenfield-human-and-agent-usability-study.md) | P1 | M | Run an independent greenfield human-and-agent usability study |
| [BR-085](../issues/m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md) | P0 | M | Run the beta release gate and issue an evidence-backed go/no-go |

## Scheduling rules

- Execute by dependency, not numeric ID alone.
- One issue normally equals one worktree and pull request.
- P0 reproduction issues precede fixes.
- Package-boundary changes precede broad application refactors.
- Reference-app refactors are staged so the app remains runnable.
- Human-gated registry work cannot be marked complete by an autonomous agent.
- HTMX 4 GA work remains in the existing upstream-triggered M7 chain, outside this beta critical path.
- A task in the same topological wave may still conflict through overlapping write sets; use the parallel-work guide.

## Suggested release checkpoints

| Checkpoint | Meaning |
| --- | --- |
| Post-alpha.2 | P0 correctness/README/package ADR complete |
| Post-alpha.3 | Package reset and minimal feature scaffold complete |
| Post-alpha.4 | Todo/Admin refactors and agent tooling complete |
| Beta RC1 | Production/conformance gates complete; canary packages published |
| Beta | BR-085 GO from one candidate commit |

Version names are placeholders until BR-078 freezes publication policy.
