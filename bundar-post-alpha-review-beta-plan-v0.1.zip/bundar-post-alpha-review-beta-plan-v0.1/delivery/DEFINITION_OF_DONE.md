---
type: Engineering Standard
title: Bundar Post-Alpha Definition of Done
description: Common completion standard for each microtask and each milestone gate.
tags:
- bundar
- definition-of-done
- evidence
- agents
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Definition of done

An issue is not done because code exists or a local test passed.

## Per-issue completion

- [ ] Every direct dependency was complete or explicitly rebased before work began.
- [ ] The issue outcome and acceptance criteria are satisfied without weakening wording.
- [ ] Planned read/write sets were followed, or deviations are explained.
- [ ] No unrelated API, route, HTML, security, dialect, or generated-file change is included.
- [ ] Tests were added or updated in the same change.
- [ ] Focused commands ran with exact versions and exit statuses recorded.
- [ ] Required package/application architecture checks pass.
- [ ] Relevant public type consumers, browser lanes, security audits, benchmarks, or package checks pass.
- [ ] Generated files were regenerated through their owner command.
- [ ] Documentation, API references, compatibility tables, changelog/log, and local agent maps were updated.
- [ ] Security/privacy review confirms no secret or sensitive fixture data in logs/artifacts.
- [ ] Performance claims include raw/environment evidence and response equivalence.
- [ ] Residual risks and follow-up IDs are recorded.
- [ ] Closure report names newly unblocked issues.
- [ ] The pull request is scoped to one stable ID unless a reviewed integration issue authorizes more.

## Agent-specific completion

- [ ] The agent did not silently read or modify excluded areas to “make tests pass.”
- [ ] The agent did not skip, mock away, or convert a mandatory failure into a warning.
- [ ] The agent stopped on contradictory architecture evidence and opened a decision/blocker.
- [ ] The final answer reports facts and commands, not hidden chain-of-thought.
- [ ] No claim relies only on model confidence.

## Milestone completion

- [ ] Every issue is closed with evidence or explicitly descoped through a decision record.
- [ ] The milestone gate runs from one immutable commit.
- [ ] Issue graph, docs, generated APIs, package manifests, and status facts have no drift.
- [ ] Cross-cutting regression suites pass.
- [ ] P0/P1 defects are zero or explicitly adjudicated according to the gate.
- [ ] Accepted residual risks have owners and triggers.
- [ ] The next milestone's dependency entry conditions are satisfied.

## Beta completion

Use [`../architecture/BETA_EXIT_CRITERIA.md`](../architecture/BETA_EXIT_CRITERIA.md) and BR-085. Beta requires an evidence-backed GO; this document alone cannot authorize release.
