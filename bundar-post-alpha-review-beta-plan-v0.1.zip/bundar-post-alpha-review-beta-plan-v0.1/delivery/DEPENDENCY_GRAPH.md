---
type: Dependency Graph
title: Bundar Post-Alpha Dependency Graph
description: Validated acyclic dependency graph, milestone edges, and critical path
  notes.
tags:
- bundar
- dependency-graph
- github
- delivery
status: final
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Dependency graph

- Issues: **85**
- Direct dependency edges: **189**
- Topological waves: **15**
- Cycles detected: **0**

## Milestone flow

```mermaid
flowchart LR
  M80[M8.0 Correctness]
  M81[M8.1 Package boundaries]
  M82[M8.2 Agent architecture]
  M83[M8.3 Agent tooling]
  M84[M8.4 Production/security]
  M85[M8.5 Conformance/performance]
  M86[M8.6 Distribution/beta]

  M80 --> M81
  M80 --> M82
  M81 --> M82
  M81 --> M83
  M82 --> M83
  M80 --> M84
  M81 --> M84
  M83 --> M85
  M84 --> M85
  M81 --> M86
  M82 --> M86
  M83 --> M86
  M84 --> M86
  M85 --> M86
```

## Direct dependencies

- **BR-001** depends on `—`; directly blocks `BR-002, BR-005, BR-008, BR-010, BR-011, BR-021, BR-046, BR-059, BR-061`.
- **BR-002** depends on `BR-001`; directly blocks `BR-003`.
- **BR-003** depends on `BR-002`; directly blocks `BR-004, BR-054, BR-057, BR-067, BR-069, BR-070`.
- **BR-004** depends on `BR-003`; directly blocks `BR-076, BR-085`.
- **BR-005** depends on `BR-001`; directly blocks `BR-006`.
- **BR-006** depends on `BR-005`; directly blocks `BR-007, BR-068, BR-085`.
- **BR-007** depends on `BR-006`; directly blocks `BR-054, BR-064, BR-065`.
- **BR-008** depends on `BR-001`; directly blocks `BR-009`.
- **BR-009** depends on `BR-008`; directly blocks `BR-085`.
- **BR-010** depends on `BR-001`; directly blocks `BR-085`.
- **BR-011** depends on `BR-001`; directly blocks `BR-012, BR-013`.
- **BR-012** depends on `BR-011`; directly blocks `BR-017`.
- **BR-013** depends on `BR-011`; directly blocks `BR-014`.
- **BR-014** depends on `BR-013`; directly blocks `BR-015, BR-016`.
- **BR-015** depends on `BR-014`; directly blocks `BR-016, BR-017, BR-029, BR-034, BR-040, BR-052, BR-055, BR-058, BR-066, BR-067, BR-071`.
- **BR-016** depends on `BR-014, BR-015`; directly blocks `BR-017`.
- **BR-017** depends on `BR-012, BR-015, BR-016`; directly blocks `BR-018, BR-019, BR-024, BR-026, BR-032, BR-038, BR-052, BR-064, BR-065, BR-067, BR-073, BR-076, BR-078, BR-085`.
- **BR-018** depends on `BR-017`; directly blocks `BR-019, BR-020, BR-083`.
- **BR-019** depends on `BR-017, BR-018`; directly blocks `BR-020, BR-078, BR-085`.
- **BR-020** depends on `BR-018, BR-019`; directly blocks `BR-073, BR-080, BR-085`.
- **BR-021** depends on `BR-001`; directly blocks `BR-022, BR-024, BR-027, BR-028, BR-029, BR-032, BR-038`.
- **BR-022** depends on `BR-021`; directly blocks `BR-023, BR-044, BR-049`.
- **BR-023** depends on `BR-022`; directly blocks `BR-031, BR-032, BR-037, BR-038, BR-043, BR-045, BR-047`.
- **BR-024** depends on `BR-021, BR-017`; directly blocks `BR-025`.
- **BR-025** depends on `BR-024`; directly blocks `BR-082, BR-084`.
- **BR-026** depends on `BR-017`; directly blocks `BR-027, BR-028, BR-085`.
- **BR-027** depends on `BR-026, BR-021`; directly blocks `BR-029, BR-030`.
- **BR-028** depends on `BR-026, BR-021`; directly blocks `BR-030`.
- **BR-029** depends on `BR-027, BR-021, BR-015`; directly blocks `BR-030`.
- **BR-030** depends on `BR-027, BR-028, BR-029`; directly blocks `BR-031, BR-050`.
- **BR-031** depends on `BR-030, BR-023`; directly blocks `BR-075, BR-085`.
- **BR-032** depends on `BR-021, BR-023, BR-017`; directly blocks `BR-033`.
- **BR-033** depends on `BR-032`; directly blocks `BR-034, BR-035`.
- **BR-034** depends on `BR-033, BR-015`; directly blocks `BR-036`.
- **BR-035** depends on `BR-033`; directly blocks `BR-036`.
- **BR-036** depends on `BR-034, BR-035`; directly blocks `BR-037`.
- **BR-037** depends on `BR-036, BR-023`; directly blocks `BR-051, BR-053, BR-074, BR-075, BR-085`.
- **BR-038** depends on `BR-021, BR-023, BR-017`; directly blocks `BR-039`.
- **BR-039** depends on `BR-038`; directly blocks `BR-040, BR-041`.
- **BR-040** depends on `BR-039, BR-015`; directly blocks `BR-042`.
- **BR-041** depends on `BR-039`; directly blocks `BR-042`.
- **BR-042** depends on `BR-040, BR-041`; directly blocks `BR-043`.
- **BR-043** depends on `BR-042, BR-023`; directly blocks `BR-051, BR-053, BR-074, BR-075, BR-085`.
- **BR-044** depends on `BR-022`; directly blocks `BR-045, BR-048`.
- **BR-045** depends on `BR-023, BR-044`; directly blocks `BR-085`.
- **BR-046** depends on `BR-001`; directly blocks `BR-047, BR-049`.
- **BR-047** depends on `BR-046, BR-023`; directly blocks `BR-048`.
- **BR-048** depends on `BR-047, BR-044`; directly blocks `BR-084, BR-085`.
- **BR-049** depends on `BR-022, BR-046`; directly blocks `—`.
- **BR-050** depends on `BR-030`; directly blocks `BR-051`.
- **BR-051** depends on `BR-037, BR-043, BR-050`; directly blocks `BR-083, BR-085`.
- **BR-052** depends on `BR-017, BR-015`; directly blocks `BR-053, BR-077`.
- **BR-053** depends on `BR-052, BR-037, BR-043`; directly blocks `BR-056, BR-085`.
- **BR-054** depends on `BR-003, BR-007, BR-064`; directly blocks `BR-055, BR-056`.
- **BR-055** depends on `BR-015, BR-054`; directly blocks `BR-056`.
- **BR-056** depends on `BR-053, BR-054, BR-055`; directly blocks `BR-085`.
- **BR-057** depends on `BR-003`; directly blocks `BR-058`.
- **BR-058** depends on `BR-057, BR-015`; directly blocks `BR-072`.
- **BR-059** depends on `BR-001`; directly blocks `BR-060`.
- **BR-060** depends on `BR-059`; directly blocks `BR-062`.
- **BR-061** depends on `BR-001`; directly blocks `BR-062, BR-063`.
- **BR-062** depends on `BR-060, BR-061`; directly blocks `BR-063, BR-085`.
- **BR-063** depends on `BR-061, BR-062`; directly blocks `BR-085`.
- **BR-064** depends on `BR-007, BR-017`; directly blocks `BR-054, BR-068, BR-073, BR-085`.
- **BR-065** depends on `BR-007, BR-017`; directly blocks `BR-075, BR-085`.
- **BR-066** depends on `BR-015`; directly blocks `BR-068, BR-071, BR-077, BR-085`.
- **BR-067** depends on `BR-003, BR-015, BR-017`; directly blocks `BR-068, BR-069, BR-070, BR-071, BR-072, BR-085`.
- **BR-068** depends on `BR-006, BR-064, BR-066, BR-067`; directly blocks `BR-085`.
- **BR-069** depends on `BR-003, BR-067`; directly blocks `BR-085`.
- **BR-070** depends on `BR-003, BR-067`; directly blocks `BR-085`.
- **BR-071** depends on `BR-015, BR-066, BR-067`; directly blocks `BR-077, BR-085`.
- **BR-072** depends on `BR-058, BR-067`; directly blocks `BR-077, BR-085`.
- **BR-073** depends on `BR-017, BR-020, BR-064`; directly blocks `BR-074, BR-085`.
- **BR-074** depends on `BR-037, BR-043, BR-073`; directly blocks `BR-085`.
- **BR-075** depends on `BR-031, BR-037, BR-043, BR-065`; directly blocks `BR-085`.
- **BR-076** depends on `BR-004, BR-017`; directly blocks `BR-077`.
- **BR-077** depends on `BR-052, BR-066, BR-071, BR-072, BR-076`; directly blocks `BR-085`.
- **BR-078** depends on `BR-017, BR-019`; directly blocks `BR-079, BR-080`.
- **BR-079** depends on `BR-078`; directly blocks `BR-081`.
- **BR-080** depends on `BR-020, BR-078`; directly blocks `BR-081`.
- **BR-081** depends on `BR-079, BR-080`; directly blocks `BR-082`.
- **BR-082** depends on `BR-081, BR-025`; directly blocks `BR-083, BR-084, BR-085`.
- **BR-083** depends on `BR-018, BR-051, BR-082`; directly blocks `BR-085`.
- **BR-084** depends on `BR-025, BR-048, BR-082`; directly blocks `BR-085`.
- **BR-085** depends on `BR-004, BR-006, BR-009, BR-010, BR-017, BR-019, BR-020, BR-026, BR-031, BR-037, BR-043, BR-045, BR-048, BR-051, BR-053, BR-056, BR-062, BR-063, BR-064, BR-065, BR-066, BR-067, BR-068, BR-069, BR-070, BR-071, BR-072, BR-073, BR-074, BR-075, BR-077, BR-082, BR-083, BR-084`; directly blocks `—`.

## Critical convergence

BR-085 intentionally converges the major evidence lines:

```text
correctness/trust
package/API integrity
feature-sliced examples
agent tooling
production/security
HTTP/stream/browser/accessibility
performance
external consumption
migration
independent usability
```

This makes BR-085 large as a **gate**, not as an implementation issue. It should run and aggregate already-completed evidence rather than fix code.

## Validation rule

Any issue added or dependency changed must rerun:

```bash
bun run issues:graph
bun run issues:validate
bun run issues:parallel-check
```

The graph must remain acyclic, all stable IDs must resolve, and reverse `blocks` lists must match.
