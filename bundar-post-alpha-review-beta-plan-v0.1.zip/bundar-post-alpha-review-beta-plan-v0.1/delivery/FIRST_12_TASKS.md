---
type: Execution Guide
title: Bundar Recommended First 12 Tasks
description: Small first batch that closes the highest-confidence post-alpha risks
  before broad refactoring.
tags:
- bundar
- priority
- execution
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Recommended first batch

This is the preferred first batch after BR-001 rebases the review.

| Order | Task | Why first |
| ---: | --- | --- |
| 1 | BR-001 | Establishes current truth and prevents acting on stale premises |
| 2 | BR-002 | Reproduces the compile-once middleware concern |
| 3 | BR-005 | Reproduces and bounds the raw HTML trust concern |
| 4 | BR-008 | Fixes the immediately misleading project landing page |
| 5 | BR-011 | Freezes package ownership before public publication |
| 6 | BR-021 | Freezes the application structure before example refactors |
| 7 | BR-003 | Implements middleware fix only when BR-002 proves it |
| 8 | BR-006 | Aligns raw trust implementation/docs after BR-005 |
| 9 | BR-012 | Makes package graph drift fail in CI |
| 10 | BR-013 | Creates the forms package target |
| 11 | BR-026 | Makes the canonical starter demonstrate real TSX |
| 12 | BR-009 | Prevents README status from drifting again |

## Why not start with Todo/Admin refactors

Those applications depend on:

- the package ownership decision;
- actual TSX starter direction;
- feature-slice ADR;
- architecture checker;
- preferred form/action APIs.

Refactoring them earlier would create churn and merge conflicts.

## Why not start with performance

The middleware reproduction is semantic; raw trust is security; package ownership and publication are architectural. Performance tuning before these decisions risks optimizing code that will move or hiding a contract defect behind benchmark variance.

## First checkpoint

The first checkpoint is complete when:

```text
P0 concerns are reproduced and fixed/disproven
root README is accurate
package graph is accepted and enforced
feature-slice convention is accepted
minimal starter uses actual TSX
```

At that point the project can safely fan out into forms extraction, minimal slicing, and production-contract work.
