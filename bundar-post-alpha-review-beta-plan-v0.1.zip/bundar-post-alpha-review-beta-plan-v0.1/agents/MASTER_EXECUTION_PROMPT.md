---
type: AI Agent Implementation Prompt
title: Bundar Post-Alpha Master Execution Prompt
description: Source-of-truth instructions for coding agents executing BR-001 through
  BR-085 safely in dependency-aware worktrees.
tags:
- bundar
- ai-agent
- implementation
- github
- evidence
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Mission

Advance Bundar from the audited post-alpha baseline toward an evidence-backed beta without broadening its product scope or weakening its existing gates.

Execute **one selected BR issue** at a time.

## Required context

Read only:

1. root `README.md` in this bundle;
2. `delivery/DEFINITION_OF_DONE.md`;
3. `agents/LOW_CONTEXT_TASK_PROTOCOL.md`;
4. the selected BR issue;
5. every direct dependency linked from that issue;
6. the repository-local `AGENTS.md` nearest the affected code;
7. source files in the issue's read set.

Do not preload all 85 issues or the entire design corpus.

## Non-negotiable Bundar invariants

1. Bun is the only initial runtime.
2. Route matching remains native `Bun.serve`; no second general router.
3. Handlers/helpers produce native `Response`.
4. JSX is server-only; no React compatibility, hydration, VDOM, hooks, or browser component lifecycle.
5. Official HTMX remains the browser runtime.
6. HTMX version differences stay in dialect adapters.
7. htmx 2 remains stable/default until an explicit later decision.
8. htmx 4 beta is experimental; no GA claim before official GA and the M7 chain.
9. Domain/application actions do not import JSX, HTMX, Request, Response, route Context, or concrete storage adapters.
10. Standard HTMX attributes remain visible in TSX; do not invent a proprietary replacement DSL.
11. No mandatory Rust/native dependency.
12. No performance, security, compatibility, or release claim without recorded evidence.
13. Do not add DI, ORM, queue, scheduler, auth product, client state runtime, or multi-runtime support to satisfy a scoped task.

## Before editing

```text
1. Confirm selected stable ID.
2. Confirm direct dependencies are complete.
3. Record current full commit SHA and working tree status.
4. Read issue outcome, evidence, scope, acceptance, read/write sets, and checks.
5. Inspect current source to determine whether the premise still holds.
6. Report “already fixed,” “partially fixed,” “still present,” or “contradicted.”
7. Create/use the issue-specific worktree and branch.
```

When the premise is already fixed, verify it with the issue's acceptance evidence and close the issue as already satisfied. Do not recreate the change.

## Implementation rules

- Keep the change scoped to the issue.
- Preserve public behavior unless the issue explicitly changes a contract.
- Add tests before or with the implementation.
- Prefer direct TypeScript and Web APIs over generic abstraction layers.
- Preserve synchronous paths when application code is synchronous.
- Parse request data lazily and at most once.
- Keep application UI in TSX files, actions transport-neutral, and routes thin.
- Use typed routes/region IDs and normalized HTMX intents.
- Keep security helpers fail-closed.
- Treat generated files as outputs, not hand-edited source.
- Update local agent maps when ownership changes.
- Record API/migration notes for any moved public symbol.

## Stop conditions

Stop and report a blocker when:

- source evidence contradicts the task;
- a required dependency is incomplete;
- satisfying the task needs a forbidden package/import edge;
- native Bun behavior cannot represent the contract;
- a security boundary cannot be made explicit;
- the task requires changing dialect defaults or claiming htmx 4 GA;
- the write set overlaps active work without an integration owner;
- a mandatory check is unavailable or consistently fails outside the task;
- registry credentials/human approval are required;
- a performance target encourages unsafe buffering/parsing;
- the issue is too large for one bounded pull request.

Do not weaken acceptance criteria to continue.

## Verification order

```text
1. focused unit/type test
2. affected package/application tests
3. architecture and generated-file checks
4. security/browser/performance checks named by the issue
5. milestone/full gate required by repository policy
6. git diff --check and final status
```

Record exact commands, versions, exit codes, and artifact paths.

## Completion response

Return a concise closure report:

```markdown
Stable ID:
Result: complete | already satisfied | blocked | split required
Baseline commit:
Commit / PR:
Files changed:
Read/write-set deviations:
Commands and exit status:
Evidence:
Public API / migration impact:
Security / performance impact:
Residual risks:
Docs / agent maps updated:
Newly unblocked IDs:
```

Do not provide hidden chain-of-thought. Provide inspectable decisions, evidence, and concise rationale.
