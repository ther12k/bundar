---
type: AI Agent Protocol
title: Bundar Low-Context Task Protocol
description: Minimal context-loading and execution protocol for Codex-style agents
  working one Bundar microtask per worktree.
tags:
- bundar
- ai-agent
- low-context
- worktree
- protocol
status: final
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Low-context task protocol

## Goal

Complete one issue without loading the full repository or relying on prior chat history.

## Context packet

Maximum default packet:

```text
selected issue
direct dependency closure summaries
nearest AGENTS.md
affected public contract/type files
source files in read set
focused tests
generated manifest for the feature/package
relevant diff from base
```

Suggested budget:

```text
files:       ≤ 20 initial files
source text: ≤ 50,000 bytes before expansion
dependencies: direct only
issues:      selected + direct dependencies
```

Expand only when source evidence requires it. Record each expansion.

## Task start

```bash
git status --short --branch
git rev-parse HEAD
bun --version
```

Classify the task premise:

- `still-present`
- `already-fixed`
- `partially-fixed`
- `contradicted`
- `blocked`

## Read-set behavior

Read the declared paths first. Use targeted symbol/search queries rather than recursively opening whole packages.

Good:

```bash
rg -n "composeMiddleware|raw\(|runFormAction" packages/core packages/jsx packages/htmx
```

Avoid:

```bash
cat every file in the monorepo
```

## Write-set behavior

Only change declared paths. When a generator owns a file, change its input and run the generator.

When a necessary file is outside scope:

```text
STOP → report file/reason → request scope extension or blocker
```

## Test behavior

Run the smallest semantic test first. Do not use a full test suite as the only evidence for a narrow invariant.

Examples:

```text
middleware composer invocation count
raw value forgery
forbidden import edge
one full-page/fragment pair
one session rotation race
one packed import
```

Then run affected and full gates.

## Failure behavior

Never:

- skip a test without a recorded reason;
- change a threshold to make a benchmark pass;
- turn a failure into a warning;
- mock away the behavior under review;
- edit snapshots before inspecting semantic differences;
- claim a browser/network/registry result that was not executed;
- use secrets from chat or local files.

## Parallel behavior

One issue per worktree. Before starting, compare write sets with active issues. Generated manifests, package exports, lockfiles, and reference bootstraps have one integration owner.

## Agent-friendly source target

Prefer this separation:

```text
routes.ts       Request/Response/HTMX orchestration
actions.ts      use cases and business outcomes
schema.ts       input contract
repository.ts   port
data/*.ts       adapter
view.tsx        page/fragment
components.tsx  server UI
types.ts        domain/read models
```

A task about UI should rarely require data-adapter source. A task about a business rule should not require JSX or raw HTMX source.

## Closure

Use the selected issue's closure template. Report changed files and commands, not an essay. Mark uncertainty explicitly.
