---
type: GitHub Configuration
title: Bundar Post-Alpha Labels and Milestones
description: Recommended GitHub labels, milestones, and project fields for the beta
  plan.
tags:
- bundar
- github
- labels
- milestones
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Labels and milestones

## Labels

| Label | Color | Description |
| --- | --- | --- |
| `area:agents` | `#5319e7` | AI-agent usability |
| `area:api` | `#a2eeef` | Public API/export maps |
| `area:architecture` | `#7057ff` | Package/application architecture |
| `area:browser` | `#0e8a16` | Browser/no-JS/a11y |
| `area:cli` | `#5319e7` | CLI |
| `area:compatibility` | `#fbca04` | Compatibility/migration |
| `area:core` | `#1d76db` | HTTP kernel |
| `area:docs` | `#0075ca` | Docs/status |
| `area:examples` | `#d4c5f9` | Reference applications |
| `area:forms` | `#c2e0c6` | Forms and validation workflow |
| `area:htmx` | `#ff7b72` | HTMX protocol/dialects |
| `area:jsx` | `#e99695` | Server JSX |
| `area:performance` | `#f9d0c4` | Benchmarks/performance |
| `area:quality` | `#ededed` | Code quality |
| `area:release` | `#000000` | Publishing/release |
| `area:scaffold` | `#bfdadc` | Templates/scaffolder |
| `area:security` | `#b60205` | Security/session/CSP |
| `area:tooling` | `#5319e7` | Developer/repository tooling |
| `priority:p0` | `#d73a4a` | Beta blocker, prerequisite reproduction/decision, or human gate |
| `priority:p1` | `#fbca04` | Required for proposed beta quality unless explicitly accepted |
| `priority:p2` | `#0e8a16` | Important enhancement or evidence; gate may adjudicate |
| `size:m` | `#5319e7` | Medium but single-outcome task |
| `size:s` | `#bfdadc` | Small bounded task |
| `size:xs` | `#c5def5` | Very small bounded task |
| `status:blocked` | `#b60205` | Dependency or external blocker |
| `status:human-gated` | `#8b0000` | Requires maintainer authority/credentials |
| `status:proposed` | `#ededed` | Specified in review bundle; not yet accepted |
| `type:adr` | `#7057ff` | Architecture decision |
| `type:architecture` | `#7057ff` | Architecture contract or structure |
| `type:audit` | `#0052cc` | Evidence audit or baseline capture |
| `type:benchmark` | `#f9d0c4` | Performance evidence |
| `type:bug` | `#d73a4a` | Correctness defect |
| `type:compatibility` | `#fbca04` | Migration or compatibility |
| `type:docs` | `#0075ca` | Documentation |
| `type:feature` | `#a2eeef` | New bounded capability |
| `type:gate` | `#000000` | Integrated go/no-go gate |
| `type:human-gate` | `#8b0000` | Human-owned prerequisite |
| `type:policy` | `#d4c5f9` | Engineering policy |
| `type:process` | `#d4c5f9` | Delivery/process |
| `type:refactor` | `#c2e0c6` | Behavior-preserving structural work |
| `type:release` | `#0e8a16` | Distribution/release |
| `type:security` | `#b60205` | Security hardening/fix |
| `type:test` | `#1d76db` | Test/conformance work |
| `type:tooling` | `#5319e7` | Developer/agent tooling |
| `type:validation` | `#bfd4f2` | Independent validation/study |

## Milestones

| Milestone | Issues | Exit purpose |
| --- | ---: | --- |
| `M8.0 — Post-alpha correctness and claim closure` | 10 | Close factual/contract drift before expanding beta scope. |
| `M8.1 — Package-boundary reset` | 10 | Reset package ownership before public registry consumers depend on it. |
| `M8.2 — Agent-friendly application architecture` | 25 | Make Bundar applications readable and safely changeable by humans and low-context agents. |
| `M8.3 — Agent tooling and API dogfooding` | 11 | Turn agent friendliness and preferred APIs into first-party tooling and dogfooded examples. |
| `M8.4 — Production and security hardening` | 12 | Close fail-closed production and security contracts. |
| `M8.5 — Conformance, browsers, and performance` | 9 | Broaden protocol/browser evidence and measure target workloads fairly. |
| `M8.6 — Distribution and beta readiness` | 8 | Prove real external distribution and issue the beta decision. |

## Suggested project fields

| Field | Values |
| --- | --- |
| Stable ID | `BR-001` … `BR-085` |
| Status | Proposed, Ready, In progress, In review, Blocked, Human gate, Done |
| Priority | P0, P1, P2 |
| Size | XS, S, M |
| Milestone | M8.0 … M8.6 |
| Area | Core, JSX, HTMX, Forms, Security, Architecture, Examples, CLI, Agents, Browser, Performance, Release |
| Agent-ready | Yes / No |
| Human gate | Yes / No |
| Execution wave | 1 … 15 |
| Worktree/PR | URL |
| Evidence | URL/path |

## Status automation

An issue may enter `Ready` only when:

- all `depends_on` stable IDs are closed with evidence;
- no human/upstream gate remains;
- the read/write/check contract validates;
- no in-progress parallel issue has an incompatible write set.

An issue may enter `Done` only when the closure report and required evidence are attached.
