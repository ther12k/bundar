---
type: Delivery Guide
title: Bundar Parallel Work Guide
description: Rules for safe multi-agent worktrees, write-set conflict checks, integration
  ownership, and merge order.
tags:
- bundar
- agents
- parallel
- worktrees
- github
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Parallel work guide

## Principle

Topological readiness is necessary but not sufficient for parallel execution. Two unblocked issues can still conflict in:

- root/package manifests and lockfiles;
- public export maps;
- generated API/route files;
- the same example/bootstrap;
- shared response/security helpers;
- release evidence.

Use one worktree and one stable issue per agent.

## Safe-parallel examples

Usually safe after dependencies close:

```text
BR-027 minimal schema extraction
BR-028 minimal view extraction
```

when each owns disjoint files and both depend on the accepted structure/TSX work.

Potentially safe:

```text
BR-033 Todo domain/repository
BR-035 Todo UI/views
```

only when the migration map defines separate entrypoints and one integration owner resolves `index.ts`/tests.

## Unsafe-parallel examples

Do not run independently without an integration plan:

```text
BR-015 form orchestration move
BR-017 HTMX dependency removal

BR-036 Todo route/bootstrap
BR-053 reference-app response refactor

BR-078 version policy
BR-080 package artifact audit
```

## Assignment checklist

Before assigning an issue:

- [ ] All direct dependencies are evidenced.
- [ ] Agent has the selected issue and direct dependencies only.
- [ ] Read set is sufficient and bounded.
- [ ] Write set does not overlap an in-progress task, or merge order is declared.
- [ ] Generated-file owner is known.
- [ ] Public API owner is known.
- [ ] Focused checks are available.
- [ ] Full integration owner is assigned when multiple slices converge.

## Worktree naming

```text
worktrees/br-026-minimal-real-tsx
branches/br-026-minimal-real-tsx
```

Commit and PR title:

```text
BR-026: convert the canonical minimal starter UI to actual TSX
```

## Integration issues

An implementation issue should not absorb unrelated merge conflicts. When several tasks intentionally converge, use the existing final task in that sequence as integration owner:

- BR-030 integrates minimal slice work.
- BR-036 integrates Todo route/bootstrap.
- BR-042 integrates Admin route/bootstrap.
- BR-056 integrates example API dogfooding.
- BR-080 integrates package artifacts.
- BR-085 integrates release evidence.

## Conflict policy

When an agent discovers it must write outside scope:

1. stop;
2. report the exact required file and reason;
3. check active issues owning that path;
4. extend scope through review or open a blocker;
5. never silently modify shared files and hope merge conflict resolution handles architecture.
