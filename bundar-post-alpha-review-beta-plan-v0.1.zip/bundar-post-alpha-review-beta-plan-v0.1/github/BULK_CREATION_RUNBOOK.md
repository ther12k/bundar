---
type: GitHub Runbook
title: Bundar Bulk Issue Creation Runbook
description: Safe dependency-aware procedure and generated commands for creating the
  post-alpha GitHub issues.
tags:
- bundar
- github
- gh-cli
- issues
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Bulk issue creation runbook

## Preconditions

```bash
gh auth status
gh repo view ther12k/bundar
git rev-parse HEAD
```

Rebase BR-001 before creating the remaining issues. Do not create all issues blindly when the repository has already fixed or invalidated a finding.

## 1. Create labels

Use the labels table in [`LABELS_AND_MILESTONES.md`](LABELS_AND_MILESTONES.md). Example:

```bash
gh label create "priority:p0" --color d73a4a --description "Beta blocker, prerequisite reproduction/decision, or human gate" --force
```

## 2. Create milestones

GitHub CLI does not provide the same milestone command in every installed version. Use the API:

```bash
OWNER=ther12k
REPO=bundar

gh api --method POST "repos/$OWNER/$REPO/milestones"   -f title='M8.0 — Post-alpha correctness and claim closure'   -f description='Close factual and contract drift before expanding beta scope.'
```

Create all seven milestone titles exactly as shown in the manifest.

## 3. Strip OKF frontmatter before posting

The Markdown files intentionally contain OKF YAML. GitHub issue bodies normally should start at the heading.

```bash
strip_frontmatter() {
  python3 - "$1" <<'PY'
from pathlib import Path
import sys
text = Path(sys.argv[1]).read_text()
if text.startswith("---\n"):
    _, _, body = text.split("---\n", 2)
    text = body.lstrip()
print(text, end="")
PY
}
```

## 4. Create one issue

```bash
BODY_FILE="issues/m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"

gh issue create   --repo ther12k/bundar   --title "BR-001 — Freeze the post-alpha audit baseline and provenance"   --body-file "$TMP_BODY"   --milestone "M8.0 — Post-alpha correctness and claim closure"   --label "priority:p0,size:xs,area:docs,type:audit,status:proposed"

rm -f "$TMP_BODY"
```

## 5. Create issues in execution-wave order

The generated command inventory below is ordered by topological wave. Create BR-001 first, review/rebase its results, then continue. After each command, record the resulting URL in a local stable-ID map.

### Wave 1

```bash
# BR-001
BODY_FILE="issues/m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-001 — Freeze the post-alpha audit baseline and provenance" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p0,size:xs,area:docs,type:audit,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 2

```bash
# BR-002
BODY_FILE="issues/m8-0-correctness/br-002-add-a-regression-probe-for-middleware-composition-count.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-002 — Add a regression probe for middleware composition count" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p0,size:s,area:core,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-005
BODY_FILE="issues/m8-0-correctness/br-005-reproduce-and-threat-model-raw-html-brand-forgery.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-005 — Reproduce and threat-model raw HTML brand forgery" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p0,size:s,area:jsx,type:security,status:proposed"
rm -f "$TMP_BODY"

# BR-008
BODY_FILE="issues/m8-0-correctness/br-008-replace-the-stale-design-bundle-root-readme.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-008 — Replace the stale design-bundle root README" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p0,size:xs,area:docs,type:docs,status:proposed"
rm -f "$TMP_BODY"

# BR-010
BODY_FILE="issues/m8-0-correctness/br-010-reconcile-stale-milestone-and-release-claims-across-the-corpus.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-010 — Reconcile stale milestone and release claims across the corpus" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p1,size:s,area:docs,type:audit,status:proposed"
rm -f "$TMP_BODY"

# BR-011
BODY_FILE="issues/m8-1-package-boundaries/br-011-decide-and-freeze-the-post-alpha-package-dependency-graph.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-011 — Decide and freeze the post-alpha package dependency graph" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p0,size:s,area:architecture,type:adr,status:proposed"
rm -f "$TMP_BODY"

# BR-021
BODY_FILE="issues/m8-2-agent-architecture/br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p0,size:s,area:architecture,type:adr,status:proposed"
rm -f "$TMP_BODY"

# BR-046
BODY_FILE="issues/m8-3-agent-tooling/br-046-standardize-deterministic-machine-readable-cli-behavior.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-046 — Standardize deterministic machine-readable CLI behavior" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:m,area:cli,type:tooling,status:proposed"
rm -f "$TMP_BODY"

# BR-059
BODY_FILE="issues/m8-4-production-security/br-059-define-the-trusted-proxy-client-ip-scheme-host-and-origin-model.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-059 — Define the trusted proxy, client IP, scheme, host, and origin model" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:s,area:security,type:adr,status:proposed"
rm -f "$TMP_BODY"

# BR-061
BODY_FILE="issues/m8-4-production-security/br-061-define-durable-session-store-capabilities-and-failure-semantics.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-061 — Define durable session-store capabilities and failure semantics" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:s,area:security,type:architecture,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 3

```bash
# BR-003
BODY_FILE="issues/m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-003 — Move middleware composition fully into the compile phase" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p0,size:m,area:core,type:bug,status:proposed"
rm -f "$TMP_BODY"

# BR-006
BODY_FILE="issues/m8-0-correctness/br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-006 — Make the raw HTML trust marker non-accidentally forgeable" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p0,size:m,area:jsx,type:security,status:proposed"
rm -f "$TMP_BODY"

# BR-009
BODY_FILE="issues/m8-0-correctness/br-009-generate-readme-status-facts-and-fail-on-drift.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-009 — Generate README status facts and fail on drift" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p1,size:s,area:docs,type:tooling,status:proposed"
rm -f "$TMP_BODY"

# BR-012
BODY_FILE="issues/m8-1-package-boundaries/br-012-enforce-the-package-dependency-graph-in-ci.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-012 — Enforce the package dependency graph in CI" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p0,size:s,area:architecture,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-013
BODY_FILE="issues/m8-1-package-boundaries/br-013-create-the-bundar-forms-package-skeleton.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-013 — Create the `@bundar/forms` package skeleton" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p0,size:s,area:forms,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-022
BODY_FILE="issues/m8-2-agent-architecture/br-022-define-application-import-direction-and-agent-read-write-zones.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-022 — Define application import direction and agent read/write zones" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p0,size:s,area:architecture,type:policy,status:proposed"
rm -f "$TMP_BODY"

# BR-060
BODY_FILE="issues/m8-4-production-security/br-060-implement-secure-cookie-behavior-behind-explicit-trusted-proxies.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-060 — Implement secure-cookie behavior behind explicit trusted proxies" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:m,area:security,type:feature,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 4

```bash
# BR-004
BODY_FILE="issues/m8-0-correctness/br-004-guard-middleware-hot-path-allocations-with-a-release-budget.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-004 — Guard middleware hot-path allocations with a release budget" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p1,size:s,area:performance,type:benchmark,status:proposed"
rm -f "$TMP_BODY"

# BR-007
BODY_FILE="issues/m8-0-correctness/br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-007 — Audit every renderer, header, and HTMX unsafe sink" \
  --body-file "$TMP_BODY" \
  --milestone "M8.0 — Post-alpha correctness and claim closure" \
  --label "priority:p1,size:m,area:security,type:audit,status:proposed"
rm -f "$TMP_BODY"

# BR-014
BODY_FILE="issues/m8-1-package-boundaries/br-014-extract-framework-neutral-form-action-contracts.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-014 — Extract framework-neutral form action contracts" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p0,size:s,area:forms,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-023
BODY_FILE="issues/m8-2-agent-architecture/br-023-implement-an-application-feature-boundary-checker.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-023 — Implement an application feature-boundary checker" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:tooling,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-044
BODY_FILE="issues/m8-2-agent-architecture/br-044-add-concise-local-agents-md-and-feature-map-templates.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-044 — Add concise local `AGENTS.md` and feature-map templates" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:agents,type:docs,status:proposed"
rm -f "$TMP_BODY"

# BR-049
BODY_FILE="issues/m8-3-agent-tooling/br-049-adopt-agent-ready-github-issue-read-write-check-contracts.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-049 — Adopt agent-ready GitHub issue read/write/check contracts" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:s,area:agents,type:process,status:proposed"
rm -f "$TMP_BODY"

# BR-057
BODY_FILE="issues/m8-4-production-security/br-057-define-startup-readiness-shutdown-and-graceful-stop-lifecycle.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-057 — Define startup, readiness, shutdown, and graceful-stop lifecycle" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:m,area:core,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-062
BODY_FILE="issues/m8-4-production-security/br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-062 — Fail closed on memory sessions or insecure cookies in production" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p0,size:s,area:security,type:bug,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 5

```bash
# BR-015
BODY_FILE="issues/m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-015 — Move progressive form orchestration into `@bundar/forms`" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p0,size:m,area:forms,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-045
BODY_FILE="issues/m8-2-agent-architecture/br-045-introduce-file-size-and-responsibility-budgets-with-explicit-exceptions.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-045 — Introduce file-size and responsibility budgets with explicit exceptions" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p2,size:s,area:quality,type:tooling,status:proposed"
rm -f "$TMP_BODY"

# BR-047
BODY_FILE="issues/m8-3-agent-tooling/br-047-add-bundar-inspect-json-for-routes-packages-and-feature-boundaries.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-047 — Add `bundar inspect --json` for routes, packages, and feature boundaries" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p2,size:m,area:cli,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-063
BODY_FILE="issues/m8-4-production-security/br-063-close-session-fixation-rotation-logout-and-replay-tests.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-063 — Close session fixation, rotation, logout, and replay tests" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:m,area:security,type:test,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 6

```bash
# BR-016
BODY_FILE="issues/m8-1-package-boundaries/br-016-isolate-standard-schema-integration-behind-a-forms-adapter.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-016 — Isolate Standard Schema integration behind a forms adapter" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p1,size:s,area:forms,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-048
BODY_FILE="issues/m8-3-agent-tooling/br-048-add-bundar-agent-context-feature-bounded-context-packs.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-048 — Add `bundar agent-context <feature>` bounded context packs" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p2,size:m,area:agents,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-058
BODY_FILE="issues/m8-4-production-security/br-058-propagate-request-cancellation-through-context-forms-and-streams.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-058 — Propagate request cancellation through context, forms, and streams" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:m,area:core,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-066
BODY_FILE="issues/m8-4-production-security/br-066-enforce-multipart-and-form-request-complexity-limits.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-066 — Enforce multipart and form request-complexity limits" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:m,area:core,type:security,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 7

```bash
# BR-017
BODY_FILE="issues/m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-017 — Make `@bundar/htmx` protocol-pure" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p0,size:m,area:htmx,type:refactor,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 8

```bash
# BR-018
BODY_FILE="issues/m8-1-package-boundaries/br-018-provide-compatibility-re-exports-for-moved-form-apis.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-018 — Provide compatibility re-exports for moved form APIs" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p1,size:s,area:api,type:compatibility,status:proposed"
rm -f "$TMP_BODY"

# BR-024
BODY_FILE="issues/m8-2-agent-architecture/br-024-create-the-canonical-feature-slice-scaffold-tree.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-024 — Create the canonical feature-slice scaffold tree" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:scaffold,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-026
BODY_FILE="issues/m8-2-agent-architecture/br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-026 — Convert the canonical minimal starter UI to actual TSX" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p0,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-032
BODY_FILE="issues/m8-2-agent-architecture/br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-032 — Create the Todo feature-slice skeleton and migration map" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-038
BODY_FILE="issues/m8-2-agent-architecture/br-038-inventory-and-scaffold-admin-reference-features.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-038 — Inventory and scaffold Admin reference features" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-052
BODY_FILE="issues/m8-3-agent-tooling/br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-052 — Add a typed primary-fragment and update-intent response API" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:m,area:htmx,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-064
BODY_FILE="issues/m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-064 — Validate redirect targets and all HTMX response header values" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p0,size:m,area:security,type:security,status:proposed"
rm -f "$TMP_BODY"

# BR-065
BODY_FILE="issues/m8-4-production-security/br-065-integrate-csp-nonces-with-documents-and-htmxscript.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-065 — Integrate CSP nonces with documents and `HtmxScript`" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:m,area:security,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-067
BODY_FILE="issues/m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-067 — Define stable framework error codes and redaction policy" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p1,size:m,area:core,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-076
BODY_FILE="issues/m8-5-conformance-performance/br-076-add-carno-js-as-a-fair-backend-framework-benchmark-reference.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-076 — Add Carno.js as a fair backend-framework benchmark reference" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p2,size:m,area:performance,type:benchmark,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 9

```bash
# BR-019
BODY_FILE="issues/m8-1-package-boundaries/br-019-add-packed-external-type-consumers-for-every-public-export-map.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-019 — Add packed external type consumers for every public export map" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p1,size:m,area:api,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-025
BODY_FILE="issues/m8-2-agent-architecture/br-025-expose-create-bundar-structure-feature.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-025 — Expose `create-bundar --structure feature`" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:scaffold,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-027
BODY_FILE="issues/m8-2-agent-architecture/br-027-extract-the-minimal-starter-validation-schema.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-027 — Extract the minimal starter validation schema" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:xs,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-028
BODY_FILE="issues/m8-2-agent-architecture/br-028-extract-the-minimal-starter-views-and-components.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-028 — Extract the minimal starter views and components" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-033
BODY_FILE="issues/m8-2-agent-architecture/br-033-move-todo-domain-types-and-repository-ports.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-033 — Move Todo domain types and repository ports" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-039
BODY_FILE="issues/m8-2-agent-architecture/br-039-split-admin-domain-models-and-repository-ports.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-039 — Split Admin domain models and repository ports" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-054
BODY_FILE="issues/m8-3-agent-tooling/br-054-add-safe-response-header-and-cookie-mutation-helpers.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-054 — Add safe response header and cookie mutation helpers" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:m,area:core,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-068
BODY_FILE="issues/m8-4-production-security/br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-068 — Add property and fuzz tests for high-risk parsers and serializers" \
  --body-file "$TMP_BODY" \
  --milestone "M8.4 — Production and security hardening" \
  --label "priority:p2,size:m,area:security,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-069
BODY_FILE="issues/m8-5-conformance-performance/br-069-close-http-method-conformance-for-head-options-405-and-allow.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-069 — Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p1,size:m,area:core,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-070
BODY_FILE="issues/m8-5-conformance-performance/br-070-close-route-edge-case-and-collision-conformance.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-070 — Close route edge-case and collision conformance" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p1,size:m,area:core,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-071
BODY_FILE="issues/m8-5-conformance-performance/br-071-close-body-single-consumption-and-content-type-conformance.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-071 — Close body single-consumption and content-type conformance" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p1,size:m,area:core,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-072
BODY_FILE="issues/m8-5-conformance-performance/br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-072 — Close streaming backpressure, cancellation, and late-error conformance" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p1,size:m,area:jsx,type:test,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 10

```bash
# BR-020
BODY_FILE="issues/m8-1-package-boundaries/br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-020 — Regenerate package API docs, diagrams, and migration guidance" \
  --body-file "$TMP_BODY" \
  --milestone "M8.1 — Package-boundary reset" \
  --label "priority:p1,size:s,area:docs,type:docs,status:proposed"
rm -f "$TMP_BODY"

# BR-029
BODY_FILE="issues/m8-2-agent-architecture/br-029-extract-the-minimal-starter-action-and-service-boundary.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-029 — Extract the minimal starter action and service boundary" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-034
BODY_FILE="issues/m8-2-agent-architecture/br-034-extract-todo-schemas-and-application-actions.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-034 — Extract Todo schemas and application actions" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-035
BODY_FILE="issues/m8-2-agent-architecture/br-035-extract-todo-pages-fragments-forms-and-components.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-035 — Extract Todo pages, fragments, forms, and components" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-040
BODY_FILE="issues/m8-2-agent-architecture/br-040-extract-admin-validation-authorization-and-application-actions.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-040 — Extract Admin validation, authorization, and application actions" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-041
BODY_FILE="issues/m8-2-agent-architecture/br-041-extract-admin-pages-tables-forms-dialogs-and-update-regions.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-041 — Extract Admin pages, tables, forms, dialogs, and update regions" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-055
BODY_FILE="issues/m8-3-agent-tooling/br-055-add-csrf-form-field-and-session-token-composition-helpers.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-055 — Add CSRF form-field and session-token composition helpers" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:m,area:security,type:feature,status:proposed"
rm -f "$TMP_BODY"

# BR-077
BODY_FILE="issues/m8-5-conformance-performance/br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-077 — Profile large-table rendering and form parsing, then set beta budgets" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p2,size:m,area:performance,type:benchmark,status:proposed"
rm -f "$TMP_BODY"

# BR-078
BODY_FILE="issues/m8-6-beta-release/br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-078 — Freeze alpha-to-beta versioning and publication policy" \
  --body-file "$TMP_BODY" \
  --milestone "M8.6 — Distribution and beta readiness" \
  --label "priority:p0,size:s,area:release,type:adr,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 11

```bash
# BR-030
BODY_FILE="issues/m8-2-agent-architecture/br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-030 — Reduce the minimal route module to HTTP and hypermedia orchestration" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-036
BODY_FILE="issues/m8-2-agent-architecture/br-036-extract-todo-route-registration-and-bootstrap-composition.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-036 — Extract Todo route registration and bootstrap composition" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-042
BODY_FILE="issues/m8-2-agent-architecture/br-042-extract-admin-route-modules-and-runtime-bootstrap.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-042 — Extract Admin route modules and runtime bootstrap" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:m,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-073
BODY_FILE="issues/m8-5-conformance-performance/br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-073 — Revalidate the neutral HTMX contract against the official v4 upgrade checker" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p1,size:m,area:htmx,type:compatibility,status:proposed"
rm -f "$TMP_BODY"

# BR-079
BODY_FILE="issues/m8-6-beta-release/br-079-resolve-npm-namespace-credentials-provenance-and-human-approval-gate.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-079 — Resolve npm namespace, credentials, provenance, and human approval gate" \
  --body-file "$TMP_BODY" \
  --milestone "M8.6 — Distribution and beta readiness" \
  --label "priority:p0,size:xs,area:release,type:human-gate,status:proposed"
rm -f "$TMP_BODY"

# BR-080
BODY_FILE="issues/m8-6-beta-release/br-080-re-audit-tarballs-exports-licenses-sbom-and-provenance-after-refactors.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-080 — Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors" \
  --body-file "$TMP_BODY" \
  --milestone "M8.6 — Distribution and beta readiness" \
  --label "priority:p0,size:m,area:release,type:audit,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 12

```bash
# BR-031
BODY_FILE="issues/m8-2-agent-architecture/br-031-document-and-gate-the-minimal-starter-architecture.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-031 — Document and gate the minimal starter architecture" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:xs,area:examples,type:docs,status:proposed"
rm -f "$TMP_BODY"

# BR-037
BODY_FILE="issues/m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-037 — Close Todo feature-slice regression and source-diff evidence" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:examples,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-043
BODY_FILE="issues/m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-043 — Close Admin feature-slice regression and architecture evidence" \
  --body-file "$TMP_BODY" \
  --milestone "M8.2 — Agent-friendly application architecture" \
  --label "priority:p1,size:s,area:examples,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-050
BODY_FILE="issues/m8-3-agent-tooling/br-050-dogfood-generated-typed-urls-in-the-minimal-starter.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-050 — Dogfood generated typed URLs in the minimal starter" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-081
BODY_FILE="issues/m8-6-beta-release/br-081-publish-a-guarded-canary-and-verify-registry-metadata.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-081 — Publish a guarded canary and verify registry metadata" \
  --body-file "$TMP_BODY" \
  --milestone "M8.6 — Distribution and beta readiness" \
  --label "priority:p0,size:s,area:release,type:release,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 13

```bash
# BR-051
BODY_FILE="issues/m8-3-agent-tooling/br-051-dogfood-generated-typed-urls-in-todo-and-admin.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-051 — Dogfood generated typed URLs in Todo and Admin" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:m,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-053
BODY_FILE="issues/m8-3-agent-tooling/br-053-remove-manual-html-concatenation-from-reference-applications.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-053 — Remove manual HTML concatenation from reference applications" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-074
BODY_FILE="issues/m8-5-conformance-performance/br-074-add-firefox-and-webkit-browser-conformance-lanes.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-074 — Add Firefox and WebKit browser conformance lanes" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p1,size:m,area:browser,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-075
BODY_FILE="issues/m8-5-conformance-performance/br-075-add-no-javascript-and-accessibility-baseline-gates.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-075 — Add no-JavaScript and accessibility baseline gates" \
  --body-file "$TMP_BODY" \
  --milestone "M8.5 — Conformance, browsers, and performance" \
  --label "priority:p1,size:m,area:browser,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-082
BODY_FILE="issues/m8-6-beta-release/br-082-run-an-external-clean-repository-consumer-smoke-test.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-082 — Run an external clean-repository consumer smoke test" \
  --body-file "$TMP_BODY" \
  --milestone "M8.6 — Distribution and beta readiness" \
  --label "priority:p0,size:m,area:release,type:test,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 14

```bash
# BR-056
BODY_FILE="issues/m8-3-agent-tooling/br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-056 — Refactor examples away from manual cookie and Response reconstruction" \
  --body-file "$TMP_BODY" \
  --milestone "M8.3 — Agent tooling and API dogfooding" \
  --label "priority:p1,size:s,area:examples,type:refactor,status:proposed"
rm -f "$TMP_BODY"

# BR-083
BODY_FILE="issues/m8-6-beta-release/br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-083 — Build and verify an alpha-to-beta migration fixture" \
  --body-file "$TMP_BODY" \
  --milestone "M8.6 — Distribution and beta readiness" \
  --label "priority:p1,size:m,area:compatibility,type:test,status:proposed"
rm -f "$TMP_BODY"

# BR-084
BODY_FILE="issues/m8-6-beta-release/br-084-run-an-independent-greenfield-human-and-agent-usability-study.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-084 — Run an independent greenfield human-and-agent usability study" \
  --body-file "$TMP_BODY" \
  --milestone "M8.6 — Distribution and beta readiness" \
  --label "priority:p1,size:m,area:agents,type:validation,status:proposed"
rm -f "$TMP_BODY"

```

### Wave 15

```bash
# BR-085
BODY_FILE="issues/m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md"
TMP_BODY="$(mktemp)"
strip_frontmatter "$BODY_FILE" > "$TMP_BODY"
gh issue create --repo ther12k/bundar \
  --title "BR-085 — Run the beta release gate and issue an evidence-backed go/no-go" \
  --body-file "$TMP_BODY" \
  --milestone "M8.6 — Distribution and beta readiness" \
  --label "priority:p0,size:m,area:release,type:gate,status:proposed"
rm -f "$TMP_BODY"

```

## 6. Post-creation verification

```bash
gh issue list --repo ther12k/bundar --limit 200   --search '"BR-" in:title'   --json number,title,url,state,milestone,labels
```

Verify:

- exactly 85 stable IDs exist;
- titles are unique;
- milestone and priority match the manifest;
- no blocked issue is placed in Ready/In progress;
- human-gated BR-079/BR-081/BR-085 retain maintainer review;
- dependency links in bodies resolve after repository paths are committed.

## Do not

- Do not close a task merely because a similar old issue exists; map evidence first.
- Do not create duplicate implementation work when current `main` already fixed the premise.
- Do not automatically assign all issues to one agent.
- Do not let a bot publish packages or claim htmx 4 GA.
