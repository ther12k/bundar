---
type: Application Guide
title: Apply the Baseline README Candidate
description: How to use the previously prepared implementation README against the
  audited Bundar revision.
tags:
- bundar
- readme
- docs
- patch
status: final
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Apply guide

The candidate file [`README_IMPLEMENTATION_CANDIDATE.md`](README_IMPLEMENTATION_CANDIDATE.md) was prepared against:

```text
f8bdd8641865be3563746e892ab86fba702ee3e8
```

## Use

From a clone of the audited revision:

```bash
cp path/to/README_IMPLEMENTATION_CANDIDATE.md README.md

bun run docs:validate
bun run docs:links
bun run docs:check
git diff --check
git diff -- README.md
```

## Rebase to newer `main`

When the repository moved beyond the baseline:

1. inspect current release/package/dialect facts;
2. compare current root README with the candidate;
3. preserve newer valid content;
4. update the `updated` date and status only when source-of-truth evidence supports it;
5. verify every relative link and code sample;
6. do not advertise `bun add`/`bunx` until registry packages actually exist;
7. keep htmx 4 marked experimental until official GA and the M7 chain.

## Preferred commit

```text
BR-008: replace stale design-bundle README
```

BR-009 and BR-010 then add drift prevention and corpus reconciliation.
