---
type: GitHub Issue Specification
title: BR-027 — Extract the minimal starter validation schema
description: The minimal starter's input contract lives in a dedicated schema file
  and can be read without UI or route code.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-027
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: XS
  labels:
  - priority:p1
  - size:xs
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-026
  - BR-021
  blocks:
  - BR-029
  - BR-030
  agent_ready: true
---

# BR-027 — Extract the minimal starter validation schema

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `XS`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

The minimal starter's input contract lives in a dedicated schema file and can be read without UI or route code.

## Why this task exists

The current starter defines validation inline with route/UI code.

## Deliverables

- Move the subscription/greeting schema and typed input/result definitions to one file.
- Export only the schema and stable input types needed by the action layer.
- Add focused valid/invalid/async validation tests.

## Out of scope

- Changing validation messages without reason

## Acceptance criteria

- [ ] The schema file imports neither JSX nor HTMX.
- [ ] Route/view files do not redefine validation rules.
- [ ] Sensitive retained-value behavior is covered if applicable.
- [ ] Focused schema tests run without starting an app.

## Agent context contract

### Read set

- `templates/minimal/src/features/subscribe/subscribe.schema.ts`
- `templates/minimal/src/features/subscribe/subscribe.schema.test.ts`

### Write set

- `templates/minimal/src/features/subscribe/subscribe.schema.ts`
- `templates/minimal/src/features/subscribe/subscribe.schema.test.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `templates/minimal/src/features/subscribe/subscribe.schema.ts`
- `templates/minimal/src/features/subscribe/subscribe.schema.test.ts`

## Verification

```bash
bun test templates/minimal/src/subscribe.schema.test.ts
bun run app:architecture:check templates/minimal
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-026 — Convert the canonical minimal starter UI to actual TSX](br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md)
- [BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps](br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md)

## Blocks

- [BR-029 — Extract the minimal starter action and service boundary](br-029-extract-the-minimal-starter-action-and-service-boundary.md)
- [BR-030 — Reduce the minimal route module to HTTP and hypermedia orchestration](br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-027
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
