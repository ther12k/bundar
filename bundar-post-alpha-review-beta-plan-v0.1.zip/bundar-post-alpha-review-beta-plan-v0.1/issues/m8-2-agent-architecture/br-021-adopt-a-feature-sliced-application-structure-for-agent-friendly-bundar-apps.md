---
type: GitHub Issue Specification
title: BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar
  apps
description: Bundar recommends one predictable full-stack repository structure that
  separates UI, route orchestration, application actions, domain types, and persistence
  without splitting them into separate repositories.
tags:
- github-issue
- bundar
- architecture
- adr
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-021
  milestone: M8.2 — Agent-friendly application architecture
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:architecture
  - type:adr
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-022
  - BR-024
  - BR-027
  - BR-028
  - BR-029
  - BR-032
  - BR-038
  agent_ready: true
---

# BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `architecture`  
**Type:** `adr`

## Outcome

Bundar recommends one predictable full-stack repository structure that separates UI, route orchestration, application actions, domain types, and persistence without splitting them into separate repositories.

## Why this task exists

The minimal starter has some separation (`main.ts`, `layout.tsx`, `dialect.ts`) but still mixes UI, schema, and route behavior in `app.ts`; the Todo reference concentrates many concerns in a 329-line `app.ts`.

## Deliverables

- Specify the canonical feature slice and naming convention for route, action, schema, repository, type, view, component, and test files.
- Define when a tiny application may use the compact structure and when it should graduate to feature slices.
- Explain why Bundar keeps UI and backend in one full-stack codebase while separating files and dependency direction.
- Record how the convention minimizes context for humans and coding agents.

## Out of scope

- Creating separate frontend/backend repositories
- Forcing domain-driven-design terminology

## Acceptance criteria

- [ ] The ADR includes a concrete canonical tree and at least one compact-tree alternative.
- [ ] The structure works for both full-page and fragment responses without a separate frontend build.
- [ ] The ADR assigns ownership for every concern currently mixed in the Todo app.
- [ ] The convention is recommended/scaffolded, not imposed by the runtime.

## Agent context contract

### Read set

- `decisions/0018-agent-friendly-feature-slices.md`
- `engineering/application-structure.md`
- `docs/guides/project-structure.md`

### Write set

- `decisions/0018-agent-friendly-feature-slices.md`
- `engineering/application-structure.md`
- `docs/guides/project-structure.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `decisions/0018-agent-friendly-feature-slices.md`
- `engineering/application-structure.md`
- `docs/guides/project-structure.md`

## Verification

```bash
bun run docs:validate
bun run docs:links
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](../m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-022 — Define application import direction and agent read/write zones](br-022-define-application-import-direction-and-agent-read-write-zones.md)
- [BR-024 — Create the canonical feature-slice scaffold tree](br-024-create-the-canonical-feature-slice-scaffold-tree.md)
- [BR-027 — Extract the minimal starter validation schema](br-027-extract-the-minimal-starter-validation-schema.md)
- [BR-028 — Extract the minimal starter views and components](br-028-extract-the-minimal-starter-views-and-components.md)
- [BR-029 — Extract the minimal starter action and service boundary](br-029-extract-the-minimal-starter-action-and-service-boundary.md)
- [BR-032 — Create the Todo feature-slice skeleton and migration map](br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md)
- [BR-038 — Inventory and scaffold Admin reference features](br-038-inventory-and-scaffold-admin-reference-features.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-021
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
