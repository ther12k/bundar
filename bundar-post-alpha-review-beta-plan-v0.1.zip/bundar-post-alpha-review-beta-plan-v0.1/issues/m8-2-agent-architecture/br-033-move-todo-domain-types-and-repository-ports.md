---
type: GitHub Issue Specification
title: BR-033 — Move Todo domain types and repository ports
description: Todo domain records, commands/read models, repository interface, and
  adapters are isolated from HTTP, JSX, sessions, and HTMX.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-033
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-032
  blocks:
  - BR-034
  - BR-035
  agent_ready: true
---

# BR-033 — Move Todo domain types and repository ports

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Todo domain records, commands/read models, repository interface, and adapters are isolated from HTTP, JSX, sessions, and HTMX.

## Why this task exists

A clean domain/persistence boundary is the base for smaller action and UI tasks.

## Deliverables

- Separate domain types/read models from repository interfaces and in-memory/SQLite implementations.
- Expose only feature-public types through one feature entrypoint.
- Keep deterministic clock/id seams and storage parity tests.

## Out of scope

- Changing Todo behavior
- Choosing a production database

## Acceptance criteria

- [ ] Domain and repository-port files import no Bundar package.
- [ ] In-memory and SQLite adapters satisfy the same contract suite.
- [ ] No handler accesses adapter-specific methods.
- [ ] Existing persistence and deterministic tests remain green.

## Agent context contract

### Read set

- `examples/todo/src/features/todos/domain/**`
- `examples/todo/src/features/todos/data/**`
- `examples/todo/src/domain.ts`

### Write set

- `examples/todo/src/features/todos/domain/**`
- `examples/todo/src/features/todos/data/**`
- `examples/todo/src/domain.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/todo/src/features/todos/domain/**`
- `examples/todo/src/features/todos/data/**`
- `examples/todo/src/domain.ts`

## Verification

```bash
bun test examples/todo/src/features/todos/domain/**
bun run app:architecture:check examples/todo
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-032 — Create the Todo feature-slice skeleton and migration map](br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md)

## Blocks

- [BR-034 — Extract Todo schemas and application actions](br-034-extract-todo-schemas-and-application-actions.md)
- [BR-035 — Extract Todo pages, fragments, forms, and components](br-035-extract-todo-pages-fragments-forms-and-components.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-033
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
