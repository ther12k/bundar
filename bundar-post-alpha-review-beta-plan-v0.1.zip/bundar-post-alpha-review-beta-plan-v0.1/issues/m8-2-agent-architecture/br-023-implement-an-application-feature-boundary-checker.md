---
type: GitHub Issue Specification
title: BR-023 — Implement an application feature-boundary checker
description: Scaffolded and reference applications fail CI when domain/application
  layers import transport or UI concerns or when features bypass declared public entrypoints.
tags:
- github-issue
- bundar
- tooling
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-023
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:tooling
  - type:test
  - status:proposed
  depends_on:
  - BR-022
  blocks:
  - BR-031
  - BR-032
  - BR-037
  - BR-038
  - BR-043
  - BR-045
  - BR-047
  agent_ready: true
---

# BR-023 — Implement an application feature-boundary checker

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `tooling`  
**Type:** `test`

## Outcome

Scaffolded and reference applications fail CI when domain/application layers import transport or UI concerns or when features bypass declared public entrypoints.

## Why this task exists

The package architecture checker does not protect application-level feature slices.

## Deliverables

- Parse TypeScript imports for canonical feature structures.
- Enforce layer direction, cross-feature entrypoints, platform/shared exceptions, and configurable compact-mode rules.
- Emit deterministic JSON and human-readable diagnostics.
- Provide fixture tests for valid, invalid, aliased, type-only, dynamic, and relative imports.

## Out of scope

- General TypeScript linting
- Runtime dependency injection

## Acceptance criteria

- [ ] A domain file importing `@bundar/jsx` fails.
- [ ] An action importing `Request`, `Response`, or raw HTMX protocol helpers fails unless explicitly allowed by a documented adapter layer.
- [ ] A route importing another feature's private repository file fails.
- [ ] The checker supports `--json`, returns nonzero on violations, and is stable across repeated runs.

## Agent context contract

### Read set

- `tools/app-architecture/**`
- `packages/cli/src/**`
- `tests/fixtures/app-architecture/**`

### Write set

- `tools/app-architecture/**`
- `packages/cli/src/**`
- `tests/fixtures/app-architecture/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tools/app-architecture/**`
- `packages/cli/src/**`
- `tests/fixtures/app-architecture/**`

## Verification

```bash
bun run app:architecture:check
bun test tools/app-architecture/**
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-022 — Define application import direction and agent read/write zones](br-022-define-application-import-direction-and-agent-read-write-zones.md)

## Blocks

- [BR-031 — Document and gate the minimal starter architecture](br-031-document-and-gate-the-minimal-starter-architecture.md)
- [BR-032 — Create the Todo feature-slice skeleton and migration map](br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md)
- [BR-037 — Close Todo feature-slice regression and source-diff evidence](br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md)
- [BR-038 — Inventory and scaffold Admin reference features](br-038-inventory-and-scaffold-admin-reference-features.md)
- [BR-043 — Close Admin feature-slice regression and architecture evidence](br-043-close-admin-feature-slice-regression-and-architecture-evidence.md)
- [BR-045 — Introduce file-size and responsibility budgets with explicit exceptions](br-045-introduce-file-size-and-responsibility-budgets-with-explicit-exceptions.md)
- [BR-047 — Add `bundar inspect --json` for routes, packages, and feature boundaries](../m8-3-agent-tooling/br-047-add-bundar-inspect-json-for-routes-packages-and-feature-boundaries.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-023
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
