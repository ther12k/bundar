---
type: GitHub Issue Specification
title: BR-036 — Extract Todo route registration and bootstrap composition
description: Todo route modules contain only HTTP/session/CSRF/form/HTMX orchestration
  and `main.ts` contains only runtime bootstrap.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-036
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-034
  - BR-035
  blocks:
  - BR-037
  agent_ready: true
---

# BR-036 — Extract Todo route registration and bootstrap composition

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Todo route modules contain only HTTP/session/CSRF/form/HTMX orchestration and `main.ts` contains only runtime bootstrap.

## Why this task exists

This turns the reference app into the canonical example of the dependency direction rather than a monolithic demonstration.

## Deliverables

- Group list/read routes and mutation routes into bounded registration functions.
- Inject actions, views, session/CSRF helpers, dialect, and repository adapter through explicit composition.
- Move `Bun.serve`, environment, port, error boundary, and shutdown wiring to bootstrap.

## Out of scope

- Adding auto route discovery
- Changing dialect defaults

## Acceptance criteria

- [ ] No Todo route file implements persistence or contains large inline JSX.
- [ ] Only bootstrap calls `Bun.serve()`.
- [ ] Dialect selection remains isolated to the documented single file.
- [ ] All route names, URLs, statuses, cookies, headers, PRG, fragments, and OOB behavior remain compatible.

## Agent context contract

### Read set

- `examples/todo/src/features/todos/todo.routes.ts`
- `examples/todo/src/app.ts`
- `examples/todo/src/main.ts`
- `examples/todo/src/dialect.ts`

### Write set

- `examples/todo/src/features/todos/todo.routes.ts`
- `examples/todo/src/app.ts`
- `examples/todo/src/main.ts`
- `examples/todo/src/dialect.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/todo/src/features/todos/todo.routes.ts`
- `examples/todo/src/app.ts`
- `examples/todo/src/main.ts`
- `examples/todo/src/dialect.ts`

## Verification

```bash
bun test examples/todo
bun run test:example -- todo:htmx2
bun run test:example -- todo:htmx4
bun run test:example -- todo:no-js
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-034 — Extract Todo schemas and application actions](br-034-extract-todo-schemas-and-application-actions.md)
- [BR-035 — Extract Todo pages, fragments, forms, and components](br-035-extract-todo-pages-fragments-forms-and-components.md)

## Blocks

- [BR-037 — Close Todo feature-slice regression and source-diff evidence](br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-036
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
