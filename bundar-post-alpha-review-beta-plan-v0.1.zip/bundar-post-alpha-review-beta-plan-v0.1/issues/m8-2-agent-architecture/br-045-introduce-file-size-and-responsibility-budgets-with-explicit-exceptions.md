---
type: GitHub Issue Specification
title: BR-045 — Introduce file-size and responsibility budgets with explicit exceptions
description: Oversized mixed-responsibility application files trigger an actionable
  review signal before they become difficult for humans or low-context agents.
tags:
- github-issue
- bundar
- quality
- tooling
- p2
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-045
  milestone: M8.2 — Agent-friendly application architecture
  priority: P2
  size: S
  labels:
  - priority:p2
  - size:s
  - area:quality
  - type:tooling
  - status:proposed
  depends_on:
  - BR-023
  - BR-044
  blocks:
  - BR-085
  agent_ready: true
---

# BR-045 — Introduce file-size and responsibility budgets with explicit exceptions

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P2`  
**Size:** `S`  
**Area:** `quality`  
**Type:** `tooling`

## Outcome

Oversized mixed-responsibility application files trigger an actionable review signal before they become difficult for humans or low-context agents.

## Why this task exists

Line count is imperfect, but large route/UI/action composites are a useful smell when combined with import and responsibility rules.

## Deliverables

- Set separate soft/hard thresholds for route, action, view, component, schema, and agent-map files.
- Measure logical lines and report top-level declarations/import categories.
- Allow documented exceptions with owner, reason, and review date.

## Out of scope

- General cyclomatic-complexity platform
- Mandatory tiny files

## Acceptance criteria

- [ ] The old 329-line mixed Todo `app.ts` fixture would trigger the checker.
- [ ] Generated files, snapshots, and intentional data tables can be excluded explicitly.
- [ ] The checker warns at soft limits and fails only at approved hard limits.
- [ ] Diagnostics recommend structural remedies rather than merely saying 'file too long'.

## Agent context contract

### Read set

- `tools/app-complexity/**`
- `engineering/application-structure.md`
- `app-complexity.config.ts`

### Write set

- `tools/app-complexity/**`
- `engineering/application-structure.md`
- `app-complexity.config.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tools/app-complexity/**`
- `engineering/application-structure.md`
- `app-complexity.config.ts`

## Verification

```bash
bun run app:complexity:check
bun test tools/app-complexity/**
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-023 — Implement an application feature-boundary checker](br-023-implement-an-application-feature-boundary-checker.md)
- [BR-044 — Add concise local `AGENTS.md` and feature-map templates](br-044-add-concise-local-agents-md-and-feature-map-templates.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-045
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
