---
type: GitHub Issue Specification
title: BR-026 — Convert the canonical minimal starter UI to actual TSX
description: The first Bundar example demonstrates the product's promised TSX authoring
  experience instead of manually calling `jsx()` throughout `.tsx` files.
tags:
- github-issue
- bundar
- examples
- refactor
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-026
  milestone: M8.2 — Agent-friendly application architecture
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-017
  blocks:
  - BR-027
  - BR-028
  - BR-085
  agent_ready: true
---

# BR-026 — Convert the canonical minimal starter UI to actual TSX

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

The first Bundar example demonstrates the product's promised TSX authoring experience instead of manually calling `jsx()` throughout `.tsx` files.

## Why this task exists

The inspected minimal starter uses manual `jsx()` calls in `app.ts` and `layout.tsx`, which is harder to read and weakens Bundar's JSX/TSX positioning.

## Deliverables

- Rewrite UI construction in the minimal starter with JSX syntax.
- Keep `jsxImportSource: @bundar/jsx` and preserve byte-level HTML behavior.
- Retain escaping, document rendering, form, HTMX attributes, local asset, and no-JS behavior.

## Out of scope

- Changing visual design
- Adding client-side JSX

## Acceptance criteria

- [ ] The starter's application UI contains no manual `jsx()` calls unless documenting the lower-level API.
- [ ] String/stream snapshots remain semantically equivalent.
- [ ] A packed external consumer compiles the TSX.
- [ ] Ordinary and enhanced browser journeys remain green.

## Agent context contract

### Read set

- `templates/minimal/src/app.ts`
- `templates/minimal/src/layout.tsx`
- `templates/minimal/tsconfig.json`
- `templates/minimal/src/app.test.ts`

### Write set

- `templates/minimal/src/app.ts`
- `templates/minimal/src/layout.tsx`
- `templates/minimal/tsconfig.json`
- `templates/minimal/src/app.test.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `templates/minimal/src/app.ts`
- `templates/minimal/src/layout.tsx`
- `templates/minimal/tsconfig.json`
- `templates/minimal/src/app.test.ts`

## Verification

```bash
bun test templates/minimal
bun run test:template
bun run test:consumer:jsx
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-027 — Extract the minimal starter validation schema](br-027-extract-the-minimal-starter-validation-schema.md)
- [BR-028 — Extract the minimal starter views and components](br-028-extract-the-minimal-starter-views-and-components.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-026
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
