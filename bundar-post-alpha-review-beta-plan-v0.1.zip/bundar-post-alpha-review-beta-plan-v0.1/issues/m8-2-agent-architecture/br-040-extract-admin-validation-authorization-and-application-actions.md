---
type: GitHub Issue Specification
title: BR-040 — Extract Admin validation, authorization, and application actions
description: Admin use cases express validation, role policy, optimistic concurrency,
  mutations, and audit outcomes without transport or UI imports.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-040
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-039
  - BR-015
  blocks:
  - BR-042
  agent_ready: true
---

# BR-040 — Extract Admin validation, authorization, and application actions

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Admin use cases express validation, role policy, optimistic concurrency, mutations, and audit outcomes without transport or UI imports.

## Why this task exists

Role and concurrency logic are especially valuable to isolate from route handlers for agent-safe modification.

## Deliverables

- Create schemas and actions for list/search, create, edit, delete, conflict resolution, and audit reads.
- Extract authorization policy functions with explicit actor/resource inputs.
- Return typed outcomes for forbidden, not found, stale version, validation, and success.

## Out of scope

- Changing role semantics
- Adding a general policy engine

## Acceptance criteria

- [ ] Actions and policies run in unit tests without HTTP or JSX.
- [ ] No action reads cookies, headers, or HTMX metadata directly.
- [ ] Protected delete and optimistic-conflict behavior remain equivalent.
- [ ] Audit events are emitted from the application layer through an explicit port.

## Agent context contract

### Read set

- `examples/admin/src/features/**/application/**`
- `examples/admin/src/features/**/schema.ts`

### Write set

- `examples/admin/src/features/**/application/**`
- `examples/admin/src/features/**/schema.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/admin/src/features/**/application/**`
- `examples/admin/src/features/**/schema.ts`

## Verification

```bash
bun test examples/admin/src/features/**/application/**
bun run app:architecture:check examples/admin
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-039 — Split Admin domain models and repository ports](br-039-split-admin-domain-models-and-repository-ports.md)
- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)

## Blocks

- [BR-042 — Extract Admin route modules and runtime bootstrap](br-042-extract-admin-route-modules-and-runtime-bootstrap.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-040
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
