---
type: Milestone Issue Index
title: M8.2 — Agent-friendly application architecture
description: Make Bundar applications readable and safely changeable by humans and
  low-context agents.
tags:
- bundar
- issues
- milestone
- m8-2-agent-architecture
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# M8.2 — Agent-friendly application architecture

## Goal

Make Bundar applications readable and safely changeable by humans and low-context agents.

## Exit conditions

- [ ] Canonical feature structure documented/checked
- [ ] Minimal uses real TSX
- [ ] Todo/Admin feature-sliced with behavior parity
- [ ] Local agent maps and complexity budgets active

| ID | Priority | Size | Area | Task | Depends on |
| --- | --- | --- | --- | --- | --- |
| [BR-021](br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md) | P0 | S | architecture | Adopt a feature-sliced application structure for agent-friendly Bundar apps | BR-001 |
| [BR-022](br-022-define-application-import-direction-and-agent-read-write-zones.md) | P0 | S | architecture | Define application import direction and agent read/write zones | BR-021 |
| [BR-023](br-023-implement-an-application-feature-boundary-checker.md) | P1 | M | tooling | Implement an application feature-boundary checker | BR-022 |
| [BR-024](br-024-create-the-canonical-feature-slice-scaffold-tree.md) | P1 | S | scaffold | Create the canonical feature-slice scaffold tree | BR-021, BR-017 |
| [BR-025](br-025-expose-create-bundar-structure-feature.md) | P1 | M | scaffold | Expose `create-bundar --structure feature` | BR-024 |
| [BR-026](br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md) | P0 | S | examples | Convert the canonical minimal starter UI to actual TSX | BR-017 |
| [BR-027](br-027-extract-the-minimal-starter-validation-schema.md) | P1 | XS | examples | Extract the minimal starter validation schema | BR-026, BR-021 |
| [BR-028](br-028-extract-the-minimal-starter-views-and-components.md) | P1 | S | examples | Extract the minimal starter views and components | BR-026, BR-021 |
| [BR-029](br-029-extract-the-minimal-starter-action-and-service-boundary.md) | P1 | S | examples | Extract the minimal starter action and service boundary | BR-027, BR-021, BR-015 |
| [BR-030](br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md) | P1 | S | examples | Reduce the minimal route module to HTTP and hypermedia orchestration | BR-027, BR-028, BR-029 |
| [BR-031](br-031-document-and-gate-the-minimal-starter-architecture.md) | P1 | XS | examples | Document and gate the minimal starter architecture | BR-030, BR-023 |
| [BR-032](br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md) | P1 | S | examples | Create the Todo feature-slice skeleton and migration map | BR-021, BR-023, BR-017 |
| [BR-033](br-033-move-todo-domain-types-and-repository-ports.md) | P1 | S | examples | Move Todo domain types and repository ports | BR-032 |
| [BR-034](br-034-extract-todo-schemas-and-application-actions.md) | P1 | M | examples | Extract Todo schemas and application actions | BR-033, BR-015 |
| [BR-035](br-035-extract-todo-pages-fragments-forms-and-components.md) | P1 | M | examples | Extract Todo pages, fragments, forms, and components | BR-033 |
| [BR-036](br-036-extract-todo-route-registration-and-bootstrap-composition.md) | P1 | M | examples | Extract Todo route registration and bootstrap composition | BR-034, BR-035 |
| [BR-037](br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md) | P1 | S | examples | Close Todo feature-slice regression and source-diff evidence | BR-036, BR-023 |
| [BR-038](br-038-inventory-and-scaffold-admin-reference-features.md) | P1 | S | examples | Inventory and scaffold Admin reference features | BR-021, BR-023, BR-017 |
| [BR-039](br-039-split-admin-domain-models-and-repository-ports.md) | P1 | M | examples | Split Admin domain models and repository ports | BR-038 |
| [BR-040](br-040-extract-admin-validation-authorization-and-application-actions.md) | P1 | M | examples | Extract Admin validation, authorization, and application actions | BR-039, BR-015 |
| [BR-041](br-041-extract-admin-pages-tables-forms-dialogs-and-update-regions.md) | P1 | M | examples | Extract Admin pages, tables, forms, dialogs, and update regions | BR-039 |
| [BR-042](br-042-extract-admin-route-modules-and-runtime-bootstrap.md) | P1 | M | examples | Extract Admin route modules and runtime bootstrap | BR-040, BR-041 |
| [BR-043](br-043-close-admin-feature-slice-regression-and-architecture-evidence.md) | P1 | S | examples | Close Admin feature-slice regression and architecture evidence | BR-042, BR-023 |
| [BR-044](br-044-add-concise-local-agents-md-and-feature-map-templates.md) | P1 | S | agents | Add concise local `AGENTS.md` and feature-map templates | BR-022 |
| [BR-045](br-045-introduce-file-size-and-responsibility-budgets-with-explicit-exceptions.md) | P2 | S | quality | Introduce file-size and responsibility budgets with explicit exceptions | BR-023, BR-044 |

## Gate

All issues must satisfy [`../../delivery/DEFINITION_OF_DONE.md`](../../delivery/DEFINITION_OF_DONE.md). The milestone is not closed solely because all code issues were merged; run and record its integrated gate.
