---
type: GitHub Issue Specification
title: BR-024 — Create the canonical feature-slice scaffold tree
description: A source template demonstrates the recommended feature structure without
  placeholder bloat or hidden framework magic.
tags:
- github-issue
- bundar
- scaffold
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-024
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:scaffold
  - type:feature
  - status:proposed
  depends_on:
  - BR-021
  - BR-017
  blocks:
  - BR-025
  agent_ready: true
---

# BR-024 — Create the canonical feature-slice scaffold tree

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `scaffold`  
**Type:** `feature`

## Outcome

A source template demonstrates the recommended feature structure without placeholder bloat or hidden framework magic.

## Why this task exists

The structure must be proven as real code before exposing it through `create-bundar`.

## Deliverables

- Create bootstrap, app composition, platform/dialect, one example feature, route module, action, schema, repository port/in-memory adapter, types, view, component, tests, and local map.
- Use actual TSX syntax and current post-boundary package imports.
- Keep generated files small and give every file one declared responsibility.

## Out of scope

- Authentication product
- Database-specific adapter
- CSS framework

## Acceptance criteria

- [ ] The template starts, typechecks, tests, and works with and without HTMX headers.
- [ ] No domain/action file imports JSX, HTMX, Request, or Response.
- [ ] A route file contains orchestration but no persistence implementation.
- [ ] A generated local map identifies the feature's public entrypoints and verification commands.

## Agent context contract

### Read set

- `templates/feature/**`

### Write set

- `templates/feature/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `templates/feature/**`

## Verification

```bash
bun test templates/feature/**
bun run app:architecture:check templates/feature
bun run test:template
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps](br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-025 — Expose `create-bundar --structure feature`](br-025-expose-create-bundar-structure-feature.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-024
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
