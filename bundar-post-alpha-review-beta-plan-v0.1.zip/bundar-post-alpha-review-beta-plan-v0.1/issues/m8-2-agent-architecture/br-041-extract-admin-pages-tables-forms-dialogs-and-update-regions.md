---
type: GitHub Issue Specification
title: BR-041 — Extract Admin pages, tables, forms, dialogs, and update regions
description: Admin UI is organized by feature and region in actual TSX over explicit
  view models.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-041
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-039
  blocks:
  - BR-042
  agent_ready: true
---

# BR-041 — Extract Admin pages, tables, forms, dialogs, and update regions

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Admin UI is organized by feature and region in actual TSX over explicit view models.

## Why this task exists

The reference app should make table/filter/form/fragment changes easy for agents without loading authorization or storage code.

## Deliverables

- Extract shell/navigation, list table, filters, pagination, inline editor, conflict view, delete confirmation, flash, and audit feed components.
- Centralize stable DOM region identifiers and update-target metadata.
- Add rendering snapshots, escaping tests, and basic accessibility semantics.

## Out of scope

- Visual redesign
- Client state store

## Acceptance criteria

- [ ] UI files import no repository adapter, session store, or raw request object.
- [ ] Large tables render through documented string/stream paths without client hydration.
- [ ] Region IDs used by update intents are typed or centrally defined.
- [ ] The same components support full-page and fragment responses.

## Agent context contract

### Read set

- `examples/admin/src/features/**/ui/**`
- `examples/admin/src/shared/ui/**`

### Write set

- `examples/admin/src/features/**/ui/**`
- `examples/admin/src/shared/ui/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/admin/src/features/**/ui/**`
- `examples/admin/src/shared/ui/**`

## Verification

```bash
bun test examples/admin/src/features/**/ui/**
bun run app:architecture:check examples/admin
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-039 — Split Admin domain models and repository ports](br-039-split-admin-domain-models-and-repository-ports.md)

## Blocks

- [BR-042 — Extract Admin route modules and runtime bootstrap](br-042-extract-admin-route-modules-and-runtime-bootstrap.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-041
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
