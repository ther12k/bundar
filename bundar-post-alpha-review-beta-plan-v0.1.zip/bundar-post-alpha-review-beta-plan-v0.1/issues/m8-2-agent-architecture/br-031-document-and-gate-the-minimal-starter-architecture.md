---
type: GitHub Issue Specification
title: BR-031 — Document and gate the minimal starter architecture
description: The starter explains where an agent should make each kind of change and
  CI proves the explanation matches the tree.
tags:
- github-issue
- bundar
- examples
- docs
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-031
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: XS
  labels:
  - priority:p1
  - size:xs
  - area:examples
  - type:docs
  - status:proposed
  depends_on:
  - BR-030
  - BR-023
  blocks:
  - BR-075
  - BR-085
  agent_ready: true
---

# BR-031 — Document and gate the minimal starter architecture

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `XS`  
**Area:** `examples`  
**Type:** `docs`

## Outcome

The starter explains where an agent should make each kind of change and CI proves the explanation matches the tree.

## Why this task exists

A good file split is not agent-friendly if ownership and commands remain implicit.

## Deliverables

- Add a concise local architecture map and change recipes for UI, validation, business rule, route, persistence, and dialect tasks.
- List public feature entrypoints, forbidden imports, and focused commands.
- Add a drift check between the documented tree and actual source.

## Out of scope

- Duplicating the full root contribution guide

## Acceptance criteria

- [ ] A new contributor can identify the correct file for six common change types without reading all source files.
- [ ] The local map stays below a defined context budget.
- [ ] The tree/entrypoint drift check fails on a renamed or missing mapped file.
- [ ] The starter passes docs and architecture checks.

## Agent context contract

### Read set

- `templates/minimal/README.md`
- `templates/minimal/AGENTS.md`
- `tools/agent-map/**`

### Write set

- `templates/minimal/README.md`
- `templates/minimal/AGENTS.md`
- `tools/agent-map/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `templates/minimal/README.md`
- `templates/minimal/AGENTS.md`
- `tools/agent-map/**`

## Verification

```bash
bun run docs:check
bun run app:architecture:check templates/minimal
bun run agent-map:check templates/minimal
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-030 — Reduce the minimal route module to HTTP and hypermedia orchestration](br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md)
- [BR-023 — Implement an application feature-boundary checker](br-023-implement-an-application-feature-boundary-checker.md)

## Blocks

- [BR-075 — Add no-JavaScript and accessibility baseline gates](../m8-5-conformance-performance/br-075-add-no-javascript-and-accessibility-baseline-gates.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-031
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
