---
type: GitHub Issue Specification
title: BR-044 — Add concise local `AGENTS.md` and feature-map templates
description: Every scaffolded/reference feature can provide a small, local map of
  purpose, public APIs, invariants, dependencies, common change recipes, and focused
  checks.
tags:
- github-issue
- bundar
- agents
- docs
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-044
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:agents
  - type:docs
  - status:proposed
  depends_on:
  - BR-022
  blocks:
  - BR-045
  - BR-048
  agent_ready: true
---

# BR-044 — Add concise local `AGENTS.md` and feature-map templates

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `agents`  
**Type:** `docs`

## Outcome

Every scaffolded/reference feature can provide a small, local map of purpose, public APIs, invariants, dependencies, common change recipes, and focused checks.

## Why this task exists

AI agents perform better with local context than with one enormous root instruction file.

## Deliverables

- Define a maximum-size template for repository, application, and feature-level agent maps.
- Include purpose, allowed imports, public entrypoint, stable DOM/route contracts, read/write zones, checks, and escalation conditions.
- Add precedence and anti-duplication rules so local files refine rather than copy root instructions.

## Out of scope

- Vendor-specific hidden prompts
- Embedding secrets or environment data

## Acceptance criteria

- [ ] The template fits within a documented token/line budget.
- [ ] Todo, Admin, minimal, and feature scaffold each contain a valid local map.
- [ ] Maps link to source-of-truth architecture rather than restating long policies.
- [ ] A drift check validates listed paths and commands.

## Agent context contract

### Read set

- `engineering/agent-maps.md`
- `templates/**/AGENTS.md`
- `examples/**/AGENTS.md`
- `tools/agent-map/**`

### Write set

- `engineering/agent-maps.md`
- `templates/**/AGENTS.md`
- `examples/**/AGENTS.md`
- `tools/agent-map/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `engineering/agent-maps.md`
- `templates/**/AGENTS.md`
- `examples/**/AGENTS.md`
- `tools/agent-map/**`

## Verification

```bash
bun run agent-map:check
bun run docs:check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-022 — Define application import direction and agent read/write zones](br-022-define-application-import-direction-and-agent-read-write-zones.md)

## Blocks

- [BR-045 — Introduce file-size and responsibility budgets with explicit exceptions](br-045-introduce-file-size-and-responsibility-budgets-with-explicit-exceptions.md)
- [BR-048 — Add `bundar agent-context <feature>` bounded context packs](../m8-3-agent-tooling/br-048-add-bundar-agent-context-feature-bounded-context-packs.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-044
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
