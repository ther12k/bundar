---
type: GitHub Issue Specification
title: BR-038 — Inventory and scaffold Admin reference features
description: The Admin app is decomposed through an explicit feature inventory and
  staged target tree rather than a broad rewrite.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-038
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-021
  - BR-023
  - BR-017
  blocks:
  - BR-039
  agent_ready: true
---

# BR-038 — Inventory and scaffold Admin reference features

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

The Admin app is decomposed through an explicit feature inventory and staged target tree rather than a broad rewrite.

## Why this task exists

Admin CRUD covers roles, search/filter/pagination, inline forms, concurrency, protected deletes, audit feeds, and multi-region updates; these concerns should not remain in oversized transport files.

## Deliverables

- Inventory bounded features such as authentication/identity seam, users/records, audit feed, shared admin shell, and platform services.
- Map symbols, routes, tests, region IDs, and dependencies to target files.
- Create feature skeletons and temporary compatibility entrypoints.

## Out of scope

- Moving implementation in the inventory task

## Acceptance criteria

- [ ] Every route and current test maps to one target feature owner.
- [ ] Cross-feature dependencies are explicit and go through public feature entrypoints.
- [ ] The app remains runnable during staged migration.
- [ ] No behavior is changed in this inventory task.

## Agent context contract

### Read set

- `examples/admin/src/features/**`
- `examples/admin/AGENTS.md`
- `docs/examples/admin.md`

### Write set

- `examples/admin/src/features/**`
- `examples/admin/AGENTS.md`
- `docs/examples/admin.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/admin/src/features/**`
- `examples/admin/AGENTS.md`
- `docs/examples/admin.md`

## Verification

```bash
bun test examples/admin
bun run app:architecture:check examples/admin --allow-migration
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps](br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md)
- [BR-023 — Implement an application feature-boundary checker](br-023-implement-an-application-feature-boundary-checker.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-039 — Split Admin domain models and repository ports](br-039-split-admin-domain-models-and-repository-ports.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-038
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
