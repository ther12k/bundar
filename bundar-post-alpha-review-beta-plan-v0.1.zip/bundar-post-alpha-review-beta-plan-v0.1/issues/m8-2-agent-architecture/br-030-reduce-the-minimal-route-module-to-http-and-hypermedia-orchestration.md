---
type: GitHub Issue Specification
title: BR-030 — Reduce the minimal route module to HTTP and hypermedia orchestration
description: The route module parses/validates, invokes the action, chooses page/fragment/action
  responses, and nothing more.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-030
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-027
  - BR-028
  - BR-029
  blocks:
  - BR-031
  - BR-050
  agent_ready: true
---

# BR-030 — Reduce the minimal route module to HTTP and hypermedia orchestration

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

The route module parses/validates, invokes the action, chooses page/fragment/action responses, and nothing more.

## Why this task exists

This completes the separation proof in the smallest canonical application.

## Deliverables

- Create a route registration function that receives dependencies explicitly.
- Compose form actions through the post-refactor APIs.
- Keep server startup, port/env handling, and process concerns in `main.ts`.

## Out of scope

- Changing endpoint URLs
- Adding framework auto-discovery

## Acceptance criteria

- [ ] The route module contains no repository implementation and no large inline JSX tree.
- [ ] `app.ts` only composes feature routes and shared middleware.
- [ ] `main.ts` is the only file calling `Bun.serve()`.
- [ ] Ordinary PRG, enhanced response, invalid form, asset, and health routes remain green.

## Agent context contract

### Read set

- `templates/minimal/src/app.ts`
- `templates/minimal/src/main.ts`
- `templates/minimal/src/features/subscribe/subscribe.routes.ts`

### Write set

- `templates/minimal/src/app.ts`
- `templates/minimal/src/main.ts`
- `templates/minimal/src/features/subscribe/subscribe.routes.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `templates/minimal/src/app.ts`
- `templates/minimal/src/main.ts`
- `templates/minimal/src/features/subscribe/subscribe.routes.ts`

## Verification

```bash
bun test templates/minimal
bun run test:template
bun run app:architecture:check templates/minimal
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-027 — Extract the minimal starter validation schema](br-027-extract-the-minimal-starter-validation-schema.md)
- [BR-028 — Extract the minimal starter views and components](br-028-extract-the-minimal-starter-views-and-components.md)
- [BR-029 — Extract the minimal starter action and service boundary](br-029-extract-the-minimal-starter-action-and-service-boundary.md)

## Blocks

- [BR-031 — Document and gate the minimal starter architecture](br-031-document-and-gate-the-minimal-starter-architecture.md)
- [BR-050 — Dogfood generated typed URLs in the minimal starter](../m8-3-agent-tooling/br-050-dogfood-generated-typed-urls-in-the-minimal-starter.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-030
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
