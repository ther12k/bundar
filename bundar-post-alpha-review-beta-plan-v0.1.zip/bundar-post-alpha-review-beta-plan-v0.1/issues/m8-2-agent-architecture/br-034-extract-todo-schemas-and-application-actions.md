---
type: GitHub Issue Specification
title: BR-034 — Extract Todo schemas and application actions
description: Create/edit/toggle/delete/filter use cases are transport-neutral, independently
  tested application actions.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-034
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-033
  - BR-015
  blocks:
  - BR-036
  agent_ready: true
---

# BR-034 — Extract Todo schemas and application actions

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Create/edit/toggle/delete/filter use cases are transport-neutral, independently tested application actions.

## Why this task exists

The current Todo app interleaves schema definitions, repository calls, CSRF/form workflow, and response rendering.

## Deliverables

- Move validation schemas and typed commands into dedicated files.
- Create action functions for create, edit, toggle, delete, and list/filter/count read models.
- Return typed success, not-found, conflict, and validation/business outcomes.
- Keep request parsing, sessions, CSRF, and response construction outside actions.

## Out of scope

- Changing copy/markup
- Adding CQRS infrastructure

## Acceptance criteria

- [ ] Action tests run without Bun routing, JSX, or HTMX.
- [ ] Actions import repository ports but not concrete adapters.
- [ ] Existing validation and optimistic behavior remain equivalent.
- [ ] No action branches on HTMX headers or representation type.

## Agent context contract

### Read set

- `examples/todo/src/features/todos/application/**`
- `examples/todo/src/features/todos/todo.schema.ts`

### Write set

- `examples/todo/src/features/todos/application/**`
- `examples/todo/src/features/todos/todo.schema.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/todo/src/features/todos/application/**`
- `examples/todo/src/features/todos/todo.schema.ts`

## Verification

```bash
bun test examples/todo/src/features/todos/application/**
bun run app:architecture:check examples/todo
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-033 — Move Todo domain types and repository ports](br-033-move-todo-domain-types-and-repository-ports.md)
- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)

## Blocks

- [BR-036 — Extract Todo route registration and bootstrap composition](br-036-extract-todo-route-registration-and-bootstrap-composition.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-034
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
