---
type: GitHub Issue Specification
title: BR-042 — Extract Admin route modules and runtime bootstrap
description: Admin routes are thin orchestration modules and process/server concerns
  are isolated in bootstrap.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-042
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-040
  - BR-041
  blocks:
  - BR-043
  agent_ready: true
---

# BR-042 — Extract Admin route modules and runtime bootstrap

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Admin routes are thin orchestration modules and process/server concerns are isolated in bootstrap.

## Why this task exists

This completes the larger-scale proof of Bundar's recommended application architecture.

## Deliverables

- Create route modules per feature with explicit dependencies.
- Compose sessions, CSRF, role middleware, forms, views, and update responses at the transport boundary.
- Move server startup, environment, dialect, error boundary, and graceful hooks into platform/bootstrap files.

## Out of scope

- Changing business workflows
- Auto-discovery

## Acceptance criteria

- [ ] Route files contain no concrete persistence code and no large inline UI tree.
- [ ] Only bootstrap starts/stops Bun's server.
- [ ] Role checks are delegated to tested policy/action functions while enforcement remains server-side.
- [ ] All URLs, names, statuses, headers, cookies, conflicts, and update regions remain compatible.

## Agent context contract

### Read set

- `examples/admin/src/app.ts`
- `examples/admin/src/main.ts`
- `examples/admin/src/features/**/routes.ts`
- `examples/admin/src/platform/**`

### Write set

- `examples/admin/src/app.ts`
- `examples/admin/src/main.ts`
- `examples/admin/src/features/**/routes.ts`
- `examples/admin/src/platform/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/admin/src/app.ts`
- `examples/admin/src/main.ts`
- `examples/admin/src/features/**/routes.ts`
- `examples/admin/src/platform/**`

## Verification

```bash
bun test examples/admin
bun run test:example -- admin:htmx2
bun run test:example -- admin:htmx4
bun run test:example -- admin:no-js
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-040 — Extract Admin validation, authorization, and application actions](br-040-extract-admin-validation-authorization-and-application-actions.md)
- [BR-041 — Extract Admin pages, tables, forms, dialogs, and update regions](br-041-extract-admin-pages-tables-forms-dialogs-and-update-regions.md)

## Blocks

- [BR-043 — Close Admin feature-slice regression and architecture evidence](br-043-close-admin-feature-slice-regression-and-architecture-evidence.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-042
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
