---
type: GitHub Issue Specification
title: BR-032 — Create the Todo feature-slice skeleton and migration map
description: The Todo refactor begins with an explicit file map and compatibility-preserving
  move plan rather than one large rewrite.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-032
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-021
  - BR-023
  - BR-017
  blocks:
  - BR-033
  agent_ready: true
---

# BR-032 — Create the Todo feature-slice skeleton and migration map

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

The Todo refactor begins with an explicit file map and compatibility-preserving move plan rather than one large rewrite.

## Why this task exists

The current Todo walkthrough documents six files, while `app.ts` owns routes, forms, CSRF/session composition, update intents, and startup-level concerns.

## Deliverables

- Inventory symbols and responsibilities in current Todo files.
- Create target directories/files with temporary re-exports where needed.
- Map every existing test and behavior to the target owning layer.
- Define a no-behavior-change migration sequence.

## Out of scope

- Moving logic and UI in the same commit

## Acceptance criteria

- [ ] Every exported symbol and route has exactly one target owner.
- [ ] The app builds after the skeleton commit with temporary adapters.
- [ ] No route URL, status, header, HTML contract, or dialect behavior changes.
- [ ] The migration map fits in the feature's local agent documentation.

## Agent context contract

### Read set

- `examples/todo/src/features/todos/**`
- `examples/todo/AGENTS.md`
- `docs/examples/todo.md`

### Write set

- `examples/todo/src/features/todos/**`
- `examples/todo/AGENTS.md`
- `docs/examples/todo.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/todo/src/features/todos/**`
- `examples/todo/AGENTS.md`
- `docs/examples/todo.md`

## Verification

```bash
bun test examples/todo
bun run app:architecture:check examples/todo --allow-migration
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps](br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md)
- [BR-023 — Implement an application feature-boundary checker](br-023-implement-an-application-feature-boundary-checker.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-033 — Move Todo domain types and repository ports](br-033-move-todo-domain-types-and-repository-ports.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-032
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
