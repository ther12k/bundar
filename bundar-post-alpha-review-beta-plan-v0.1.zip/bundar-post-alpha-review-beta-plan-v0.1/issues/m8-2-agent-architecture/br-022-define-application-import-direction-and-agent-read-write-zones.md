---
type: GitHub Issue Specification
title: BR-022 — Define application import direction and agent read/write zones
description: Application code has a small, enforceable dependency direction and each
  task can declare a bounded read set, write set, and verification set.
tags:
- github-issue
- bundar
- architecture
- policy
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-022
  milestone: M8.2 — Agent-friendly application architecture
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:architecture
  - type:policy
  - status:proposed
  depends_on:
  - BR-021
  blocks:
  - BR-023
  - BR-044
  - BR-049
  agent_ready: true
---

# BR-022 — Define application import direction and agent read/write zones

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `architecture`  
**Type:** `policy`

## Outcome

Application code has a small, enforceable dependency direction and each task can declare a bounded read set, write set, and verification set.

## Why this task exists

File separation only helps if UI, transport, domain, and persistence do not import each other arbitrarily.

## Deliverables

- Freeze the direction: routes may import actions and views; actions may import domain/repository ports; views may import read models; domain/actions must not import JSX, HTMX, Request, or Response.
- Define shared/platform exceptions for environment, dialect, sessions, and middleware.
- Define task metadata fields for `read_set`, `write_set`, `checks`, and `forbidden_changes`.

## Out of scope

- Framework package boundaries; handled by BR-012

## Acceptance criteria

- [ ] The policy includes allowed and forbidden import examples.
- [ ] A UI-only task can be completed without reading repository implementations.
- [ ] A business-rule task can be completed without loading JSX/HTMX internals.
- [ ] Exceptions require a local architecture note or explicit configuration entry.

## Agent context contract

### Read set

- `engineering/application-import-policy.md`
- `engineering/agent-task-contract.md`
- `docs/guides/project-structure.md`

### Write set

- `engineering/application-import-policy.md`
- `engineering/agent-task-contract.md`
- `docs/guides/project-structure.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `engineering/application-import-policy.md`
- `engineering/agent-task-contract.md`
- `docs/guides/project-structure.md`

## Verification

```bash
bun run docs:validate
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps](br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md)

## Blocks

- [BR-023 — Implement an application feature-boundary checker](br-023-implement-an-application-feature-boundary-checker.md)
- [BR-044 — Add concise local `AGENTS.md` and feature-map templates](br-044-add-concise-local-agents-md-and-feature-map-templates.md)
- [BR-049 — Adopt agent-ready GitHub issue read/write/check contracts](../m8-3-agent-tooling/br-049-adopt-agent-ready-github-issue-read-write-check-contracts.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-022
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
