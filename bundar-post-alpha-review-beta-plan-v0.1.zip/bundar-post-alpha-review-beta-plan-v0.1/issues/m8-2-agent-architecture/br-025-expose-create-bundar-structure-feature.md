---
type: GitHub Issue Specification
title: BR-025 — Expose `create-bundar --structure feature`
description: Developers and agents can select a compact or feature-sliced starter
  through a deterministic, documented scaffold option.
tags:
- github-issue
- bundar
- scaffold
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-025
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:scaffold
  - type:feature
  - status:proposed
  depends_on:
  - BR-024
  blocks:
  - BR-082
  - BR-084
  agent_ready: true
---

# BR-025 — Expose `create-bundar --structure feature`

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `scaffold`  
**Type:** `feature`

## Outcome

Developers and agents can select a compact or feature-sliced starter through a deterministic, documented scaffold option.

## Why this task exists

The framework should not force one layout, but the agent-friendly structure must be one command away.

## Deliverables

- Add `--structure compact|feature` with a documented default.
- Generate dialect selection, TSX config, package imports, tests, and local architecture metadata consistently.
- Support noninteractive flags, dry run, JSON manifest output, and safe destination checks.

## Out of scope

- Interactive wizard redesign
- Framework-owned deployment hosting

## Acceptance criteria

- [ ] Both structures scaffold and pass clean-room install/build/test journeys.
- [ ] Repeated generation with identical arguments produces byte-identical source except explicitly variable metadata.
- [ ] Unknown structure values fail with a clear nonzero error.
- [ ] The feature preset passes BR-023's architecture checker.

## Agent context contract

### Read set

- `create-bundar/src/**`
- `create-bundar/templates/**`
- `create-bundar/test/**`
- `create-bundar/README.md`

### Write set

- `create-bundar/src/**`
- `create-bundar/templates/**`
- `create-bundar/test/**`
- `create-bundar/README.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `create-bundar/src/**`
- `create-bundar/templates/**`
- `create-bundar/test/**`
- `create-bundar/README.md`

## Verification

```bash
bun test create-bundar/**
bun run test:scaffold -- --structure compact
bun run test:scaffold -- --structure feature
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-024 — Create the canonical feature-slice scaffold tree](br-024-create-the-canonical-feature-slice-scaffold-tree.md)

## Blocks

- [BR-082 — Run an external clean-repository consumer smoke test](../m8-6-beta-release/br-082-run-an-external-clean-repository-consumer-smoke-test.md)
- [BR-084 — Run an independent greenfield human-and-agent usability study](../m8-6-beta-release/br-084-run-an-independent-greenfield-human-and-agent-usability-study.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-025
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
