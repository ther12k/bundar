---
type: GitHub Issue Specification
title: BR-039 — Split Admin domain models and repository ports
description: Admin domain/read models, authorization inputs, repository contracts,
  and storage adapters are separated from HTTP and JSX.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-039
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-038
  blocks:
  - BR-040
  - BR-041
  agent_ready: true
---

# BR-039 — Split Admin domain models and repository ports

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Admin domain/read models, authorization inputs, repository contracts, and storage adapters are separated from HTTP and JSX.

## Why this task exists

The Admin reference should demonstrate how larger business applications isolate data and policy seams.

## Deliverables

- Extract domain records, pagination/filter query models, version/concurrency tokens, audit events, and repository interfaces.
- Separate in-memory fixture adapters from ports.
- Add contract tests for filtering, pagination, conflicts, protected deletes, and audit ordering.

## Out of scope

- Production identity provider
- Production database

## Acceptance criteria

- [ ] Domain/port files import no Bundar package.
- [ ] Authorization inputs are plain domain/application data, not request objects.
- [ ] Storage adapters pass one shared contract suite.
- [ ] Existing fixture data and deterministic behavior remain stable.

## Agent context contract

### Read set

- `examples/admin/src/features/**/domain/**`
- `examples/admin/src/features/**/data/**`

### Write set

- `examples/admin/src/features/**/domain/**`
- `examples/admin/src/features/**/data/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/admin/src/features/**/domain/**`
- `examples/admin/src/features/**/data/**`

## Verification

```bash
bun test examples/admin/src/features/**/domain/**
bun run app:architecture:check examples/admin
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-038 — Inventory and scaffold Admin reference features](br-038-inventory-and-scaffold-admin-reference-features.md)

## Blocks

- [BR-040 — Extract Admin validation, authorization, and application actions](br-040-extract-admin-validation-authorization-and-application-actions.md)
- [BR-041 — Extract Admin pages, tables, forms, dialogs, and update regions](br-041-extract-admin-pages-tables-forms-dialogs-and-update-regions.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-039
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
