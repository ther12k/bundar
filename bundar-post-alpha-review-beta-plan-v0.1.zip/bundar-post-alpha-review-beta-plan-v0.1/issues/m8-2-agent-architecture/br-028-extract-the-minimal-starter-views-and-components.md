---
type: GitHub Issue Specification
title: BR-028 — Extract the minimal starter views and components
description: Page, fragment, form, success, and error UI live in TSX files that consume
  typed view models and contain no mutation or persistence logic.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-028
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-026
  - BR-021
  blocks:
  - BR-030
  agent_ready: true
---

# BR-028 — Extract the minimal starter views and components

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Page, fragment, form, success, and error UI live in TSX files that consume typed view models and contain no mutation or persistence logic.

## Why this task exists

The current starter mixes UI creation into `app.ts`.

## Deliverables

- Create page/fragment view functions and small reusable components.
- Define explicit view-model types rather than passing service/repository objects into UI.
- Keep standard `hx-*` attributes visible and typed.

## Out of scope

- Adding a component framework
- Hiding HTMX attributes behind custom button abstractions

## Acceptance criteria

- [ ] View files import no repository implementation or form parser.
- [ ] All untrusted text remains escaped by default.
- [ ] Page and fragment snapshots cover valid, invalid, and success states.
- [ ] The route layer can render the views using only typed view models.

## Agent context contract

### Read set

- `templates/minimal/src/features/subscribe/subscribe.view.tsx`
- `templates/minimal/src/features/subscribe/subscribe.components.tsx`
- `templates/minimal/src/features/subscribe/*.view.test.tsx`

### Write set

- `templates/minimal/src/features/subscribe/subscribe.view.tsx`
- `templates/minimal/src/features/subscribe/subscribe.components.tsx`
- `templates/minimal/src/features/subscribe/*.view.test.tsx`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `templates/minimal/src/features/subscribe/subscribe.view.tsx`
- `templates/minimal/src/features/subscribe/subscribe.components.tsx`
- `templates/minimal/src/features/subscribe/*.view.test.tsx`

## Verification

```bash
bun test templates/minimal/src/features/subscribe/*.view.test.tsx
bun run app:architecture:check templates/minimal
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-026 — Convert the canonical minimal starter UI to actual TSX](br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md)
- [BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps](br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md)

## Blocks

- [BR-030 — Reduce the minimal route module to HTTP and hypermedia orchestration](br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-028
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
