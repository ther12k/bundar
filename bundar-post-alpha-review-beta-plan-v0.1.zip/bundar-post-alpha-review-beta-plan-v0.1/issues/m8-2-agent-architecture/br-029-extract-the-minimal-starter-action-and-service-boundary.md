---
type: GitHub Issue Specification
title: BR-029 — Extract the minimal starter action and service boundary
description: The mutation use case accepts validated input and returns a domain/application
  result without importing transport or JSX concepts.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-029
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-027
  - BR-021
  - BR-015
  blocks:
  - BR-030
  agent_ready: true
---

# BR-029 — Extract the minimal starter action and service boundary

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

The mutation use case accepts validated input and returns a domain/application result without importing transport or JSX concepts.

## Why this task exists

A route should coordinate HTTP and rendering; the application action should own business behavior.

## Deliverables

- Create a small action/use-case function and explicit service/repository port.
- Move mutation/business logic out of the route file.
- Provide a deterministic in-memory implementation for tests.

## Out of scope

- Production database integration

## Acceptance criteria

- [ ] The action imports neither `Request`/`Response` nor JSX/HTMX.
- [ ] Action tests run without the framework router.
- [ ] Failures are typed as application outcomes rather than prebuilt HTTP responses.
- [ ] The route remains the only layer mapping outcomes to status/representation.

## Agent context contract

### Read set

- `templates/minimal/src/features/subscribe/subscribe.action.ts`
- `templates/minimal/src/features/subscribe/subscribe.repository.ts`
- `templates/minimal/src/features/subscribe/subscribe.action.test.ts`

### Write set

- `templates/minimal/src/features/subscribe/subscribe.action.ts`
- `templates/minimal/src/features/subscribe/subscribe.repository.ts`
- `templates/minimal/src/features/subscribe/subscribe.action.test.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `templates/minimal/src/features/subscribe/subscribe.action.ts`
- `templates/minimal/src/features/subscribe/subscribe.repository.ts`
- `templates/minimal/src/features/subscribe/subscribe.action.test.ts`

## Verification

```bash
bun test templates/minimal/src/features/subscribe/subscribe.action.test.ts
bun run app:architecture:check templates/minimal
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-027 — Extract the minimal starter validation schema](br-027-extract-the-minimal-starter-validation-schema.md)
- [BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps](br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md)
- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)

## Blocks

- [BR-030 — Reduce the minimal route module to HTTP and hypermedia orchestration](br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-029
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
