---
type: GitHub Issue Specification
title: BR-035 — Extract Todo pages, fragments, forms, and components
description: Todo UI is expressed in actual TSX files over explicit view models, with
  page and fragment regions easy to locate and edit.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-035
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-033
  blocks:
  - BR-036
  agent_ready: true
---

# BR-035 — Extract Todo pages, fragments, forms, and components

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Todo UI is expressed in actual TSX files over explicit view models, with page and fragment regions easy to locate and edit.

## Why this task exists

The current UI is partly separated in `layout.tsx`, but rendering concerns and response serialization remain spread through `app.ts`.

## Deliverables

- Split document layout, list page, item row, form, filters, counts, flash, and conflict/error regions.
- Define stable region IDs and view models in one place.
- Keep typed `hx-*` attributes visible and version-neutral.
- Add focused rendering snapshots and escaping tests.

## Out of scope

- Redesigning the Todo UI
- Client hydration

## Acceptance criteria

- [ ] UI files import no repository implementation, session store, or request parser.
- [ ] All existing region IDs and OOB targets remain stable or have an explicit migration note.
- [ ] The source uses TSX rather than manual JSX factory calls for application markup.
- [ ] Page and fragment renders are testable without starting an HTTP server.

## Agent context contract

### Read set

- `examples/todo/src/features/todos/ui/**`
- `examples/todo/src/layout.tsx`

### Write set

- `examples/todo/src/features/todos/ui/**`
- `examples/todo/src/layout.tsx`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/todo/src/features/todos/ui/**`
- `examples/todo/src/layout.tsx`

## Verification

```bash
bun test examples/todo/src/features/todos/ui/**
bun run app:architecture:check examples/todo
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-033 — Move Todo domain types and repository ports](br-033-move-todo-domain-types-and-repository-ports.md)

## Blocks

- [BR-036 — Extract Todo route registration and bootstrap composition](br-036-extract-todo-route-registration-and-bootstrap-composition.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-035
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
