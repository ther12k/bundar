---
type: GitHub Issue Specification
title: BR-043 — Close Admin feature-slice regression and architecture evidence
description: The refactored Admin app proves behavior parity, source-level dialect
  isolation, and bounded feature dependencies.
tags:
- github-issue
- bundar
- examples
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-043
  milestone: M8.2 — Agent-friendly application architecture
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:test
  - status:proposed
  depends_on:
  - BR-042
  - BR-023
  blocks:
  - BR-051
  - BR-053
  - BR-074
  - BR-075
  - BR-085
  agent_ready: true
---

# BR-043 — Close Admin feature-slice regression and architecture evidence

**Milestone:** M8.2 — Agent-friendly application architecture  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `test`

## Outcome

The refactored Admin app proves behavior parity, source-level dialect isolation, and bounded feature dependencies.

## Why this task exists

A reference app is only useful if the structure and behavior are executable evidence.

## Deliverables

- Run unit, integration, real-HTTP, browser, no-JS, role, concurrency, architecture, and source-diff suites.
- Add fixtures for forbidden cross-feature imports and private-entrypoint bypasses.
- Update Admin walkthrough and per-feature maps.

## Out of scope

- New Admin features

## Acceptance criteria

- [ ] All prior Admin acceptance journeys remain green.
- [ ] No-JS workflows preserve complete-page PRG behavior.
- [ ] Both dialect lanes use unchanged application feature source.
- [ ] Architecture checker output has no unexplained suppression.

## Agent context contract

### Read set

- `examples/admin/**`
- `docs/examples/admin.md`
- `evidence/br-043/**`

### Write set

- `examples/admin/**`
- `docs/examples/admin.md`
- `evidence/br-043/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/admin/**`
- `docs/examples/admin.md`
- `evidence/br-043/**`

## Verification

```bash
bun test examples/admin
bun run test:example -- admin:htmx2
bun run test:example -- admin:htmx4
bun run test:example -- admin:no-js
bun run htmx:source-diff examples/admin
bun run app:architecture:check examples/admin
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-042 — Extract Admin route modules and runtime bootstrap](br-042-extract-admin-route-modules-and-runtime-bootstrap.md)
- [BR-023 — Implement an application feature-boundary checker](br-023-implement-an-application-feature-boundary-checker.md)

## Blocks

- [BR-051 — Dogfood generated typed URLs in Todo and Admin](../m8-3-agent-tooling/br-051-dogfood-generated-typed-urls-in-todo-and-admin.md)
- [BR-053 — Remove manual HTML concatenation from reference applications](../m8-3-agent-tooling/br-053-remove-manual-html-concatenation-from-reference-applications.md)
- [BR-074 — Add Firefox and WebKit browser conformance lanes](../m8-5-conformance-performance/br-074-add-firefox-and-webkit-browser-conformance-lanes.md)
- [BR-075 — Add no-JavaScript and accessibility baseline gates](../m8-5-conformance-performance/br-075-add-no-javascript-and-accessibility-baseline-gates.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-043
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
