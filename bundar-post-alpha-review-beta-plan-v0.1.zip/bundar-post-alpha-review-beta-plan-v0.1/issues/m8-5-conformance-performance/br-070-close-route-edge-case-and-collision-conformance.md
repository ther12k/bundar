---
type: GitHub Issue Specification
title: BR-070 — Close route edge-case and collision conformance
description: Route normalization and compilation behave predictably for trailing slashes,
  encoded segments, wildcard precedence, duplicate names, conflicting methods, invalid
  patterns, and mounted prefixes.
tags:
- github-issue
- bundar
- core
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-070
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:core
  - type:test
  - status:proposed
  depends_on:
  - BR-003
  - BR-067
  blocks:
  - BR-085
  agent_ready: true
---

# BR-070 — Close route edge-case and collision conformance

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `core`  
**Type:** `test`

## Outcome

Route normalization and compilation behave predictably for trailing slashes, encoded segments, wildcard precedence, duplicate names, conflicting methods, invalid patterns, and mounted prefixes.

## Why this task exists

Bundar delegates matching to Bun but still owns descriptor normalization, naming, mounting, conflict detection, and typed URL identity.

## Deliverables

- Build a table-driven corpus for literal/param/wildcard precedence, slash policy, percent encoding, Unicode, empty segments, duplicate paths/methods/names, groups/modules, and static Response collisions.
- Compare compiled behavior with explicitly recorded Bun-native expectations.
- Fail invalid/conflicting route graphs at compile time with stable error codes.

## Out of scope

- Implementing a second router

## Acceptance criteria

- [ ] Every documented route shape has success and conflict fixtures.
- [ ] Encoded slash/path traversal ambiguities follow an explicit fail-closed policy.
- [ ] Duplicate route names cannot produce ambiguous typed URLs.
- [ ] The corpus is versioned against the minimum and current Bun lanes.

## Agent context contract

### Read set

- `packages/core/src/routes.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/routing/**`
- `docs/reference/routing.md`

### Write set

- `packages/core/src/routes.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/routing/**`
- `docs/reference/routing.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/routes.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/routing/**`
- `docs/reference/routing.md`

## Verification

```bash
bun test packages/core/test/routing/edge-cases.test.ts
bun run test:integration:routing
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-003 — Move middleware composition fully into the compile phase](../m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md)
- [BR-067 — Define stable framework error codes and redaction policy](../m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-070
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
