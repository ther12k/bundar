---
type: GitHub Issue Specification
title: BR-077 — Profile large-table rendering and form parsing, then set beta budgets
description: 'Beta performance budgets reflect Bundar''s actual target workloads:
  large server-rendered tables, fragments, multi-region updates, and bounded form
  parsing.'
tags:
- github-issue
- bundar
- performance
- benchmark
- p2
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-077
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P2
  size: M
  labels:
  - priority:p2
  - size:m
  - area:performance
  - type:benchmark
  - status:proposed
  depends_on:
  - BR-052
  - BR-066
  - BR-071
  - BR-072
  - BR-076
  blocks:
  - BR-085
  agent_ready: true
---

# BR-077 — Profile large-table rendering and form parsing, then set beta budgets

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P2`  
**Size:** `M`  
**Area:** `performance`  
**Type:** `benchmark`

## Outcome

Beta performance budgets reflect Bundar's actual target workloads: large server-rendered tables, fragments, multi-region updates, and bounded form parsing.

## Why this task exists

Static hello-world throughput does not predict admin/dashboard workloads.

## Deliverables

- Add 100/1,000/10,000-row escaped table string and stream scenarios, fragment-only updates, primary-plus-secondary updates, URL-encoded forms, multipart forms, and validation.
- Profile CPU, allocation/memory, time-to-first-byte, total render, and tail latency.
- Identify optimization opportunities and only create follow-ups when measured impact justifies complexity.

## Out of scope

- Rust/native acceleration without a separate measured proposal

## Acceptance criteria

- [ ] Benchmarks verify HTML/result correctness before timing.
- [ ] Budgets are environment-normalized and tolerate documented variance.
- [ ] Large input limits prevent benchmarks from normalizing unsafe production defaults.
- [ ] The report states whether string or stream rendering is recommended by workload size.

## Agent context contract

### Read set

- `benchmarks/scenarios/**`
- `artifacts/bench/**`
- `docs/performance/beta.md`

### Write set

- `benchmarks/scenarios/**`
- `artifacts/bench/**`
- `docs/performance/beta.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `benchmarks/scenarios/**`
- `artifacts/bench/**`
- `docs/performance/beta.md`

## Verification

```bash
bun run bench -- jsx-large-table
bun run bench -- action-updates
bun run bench -- form-parse
bun run bench:regression
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-052 — Add a typed primary-fragment and update-intent response API](../m8-3-agent-tooling/br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md)
- [BR-066 — Enforce multipart and form request-complexity limits](../m8-4-production-security/br-066-enforce-multipart-and-form-request-complexity-limits.md)
- [BR-071 — Close body single-consumption and content-type conformance](br-071-close-body-single-consumption-and-content-type-conformance.md)
- [BR-072 — Close streaming backpressure, cancellation, and late-error conformance](br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md)
- [BR-076 — Add Carno.js as a fair backend-framework benchmark reference](br-076-add-carno-js-as-a-fair-backend-framework-benchmark-reference.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-077
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
