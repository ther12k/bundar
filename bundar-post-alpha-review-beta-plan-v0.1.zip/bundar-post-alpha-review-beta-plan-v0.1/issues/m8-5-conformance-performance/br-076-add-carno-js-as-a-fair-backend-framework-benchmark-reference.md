---
type: GitHub Issue Specification
title: BR-076 — Add Carno.js as a fair backend-framework benchmark reference
description: Bundar's benchmark suite can compare equivalent Bun-native HTTP scenarios
  with raw Bun, Hono, and Carno.js without conflating Bundar's HTML model with Carno's
  enterprise feature set.
tags:
- github-issue
- bundar
- performance
- benchmark
- p2
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-076
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P2
  size: M
  labels:
  - priority:p2
  - size:m
  - area:performance
  - type:benchmark
  - status:proposed
  depends_on:
  - BR-004
  - BR-017
  blocks:
  - BR-077
  agent_ready: true
---

# BR-076 — Add Carno.js as a fair backend-framework benchmark reference

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P2`  
**Size:** `M`  
**Area:** `performance`  
**Type:** `benchmark`

## Outcome

Bundar's benchmark suite can compare equivalent Bun-native HTTP scenarios with raw Bun, Hono, and Carno.js without conflating Bundar's HTML model with Carno's enterprise feature set.

## Why this task exists

The earlier product comparison identified overlap in routing/middleware/validation but different goals. A measured adapter is more useful than speculative speed claims.

## Deliverables

- Pin a reviewed Carno.js version and implement equivalent static, param, sync/async middleware, validated JSON, and service-access scenarios.
- Document semantic differences such as DI/controller construction and implicit response normalization.
- Exclude JSX/HTMX-only scenarios from direct winner labels or provide clearly separate rendering comparisons.

## Out of scope

- Choosing framework architecture based solely on req/s
- Benchmarking Carno infrastructure packages

## Acceptance criteria

- [ ] All compared responses are semantically equivalent and verified before timing.
- [ ] Versions, setup, warmup, concurrency, hardware, OS, memory, and raw results are recorded.
- [ ] The report does not claim superiority from incomparable feature sets.
- [ ] The adapter is optional and does not become a Bundar runtime dependency.

## Agent context contract

### Read set

- `benchmarks/adapters/carno.ts`
- `benchmarks/scenarios/**`
- `docs/performance/comparison.md`
- `artifacts/bench/**`

### Write set

- `benchmarks/adapters/carno.ts`
- `benchmarks/scenarios/**`
- `docs/performance/comparison.md`
- `artifacts/bench/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `benchmarks/adapters/carno.ts`
- `benchmarks/scenarios/**`
- `docs/performance/comparison.md`
- `artifacts/bench/**`

## Verification

```bash
bun run bench -- matrix
bun run bench:verify-responses
bun run bench:report
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-004 — Guard middleware hot-path allocations with a release budget](../m8-0-correctness/br-004-guard-middleware-hot-path-allocations-with-a-release-budget.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-077 — Profile large-table rendering and form parsing, then set beta budgets](br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-076
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
