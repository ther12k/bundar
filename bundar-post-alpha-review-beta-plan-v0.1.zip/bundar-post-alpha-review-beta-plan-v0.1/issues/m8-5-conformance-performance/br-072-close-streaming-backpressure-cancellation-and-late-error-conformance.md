---
type: GitHub Issue Specification
title: BR-072 — Close streaming backpressure, cancellation, and late-error conformance
description: String and streaming JSX paths have documented parity, bounded buffering,
  correct backpressure, cancellation cleanup, and a defined policy when errors occur
  after headers commit.
tags:
- github-issue
- bundar
- jsx
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-072
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:jsx
  - type:test
  - status:proposed
  depends_on:
  - BR-058
  - BR-067
  blocks:
  - BR-077
  - BR-085
  agent_ready: true
---

# BR-072 — Close streaming backpressure, cancellation, and late-error conformance

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `jsx`  
**Type:** `test`

## Outcome

String and streaming JSX paths have documented parity, bounded buffering, correct backpressure, cancellation cleanup, and a defined policy when errors occur after headers commit.

## Why this task exists

Streaming claims need adversarial evidence for slow consumers, async children, aborts, and partial output.

## Deliverables

- Test slow readers, small chunks, async component delays, nested iterables, large tables, abort before/after first byte, and producer errors before/after commit.
- Define whether late errors terminate the stream, emit a development marker, or only log, and how status can no longer change.
- Verify resource cleanup and no continued work after cancellation.

## Out of scope

- Server-Sent Events framework
- WebSocket abstraction

## Acceptance criteria

- [ ] Producer output respects backpressure rather than buffering the complete document unexpectedly.
- [ ] Abort closes iterators/tasks and prevents further writes.
- [ ] Pre-commit errors use the normal error boundary; post-commit behavior is documented and correlated in logs.
- [ ] String and stream output match for successful deterministic trees.

## Agent context contract

### Read set

- `packages/jsx/src/render-to-stream.ts`
- `packages/jsx/test/streaming/**`
- `docs/guides/streaming.md`

### Write set

- `packages/jsx/src/render-to-stream.ts`
- `packages/jsx/test/streaming/**`
- `docs/guides/streaming.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/jsx/src/render-to-stream.ts`
- `packages/jsx/test/streaming/**`
- `docs/guides/streaming.md`

## Verification

```bash
bun test packages/jsx/test/streaming/**
bun run test:integration:streaming
bun run bench -- jsx-stream
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-058 — Propagate request cancellation through context, forms, and streams](../m8-4-production-security/br-058-propagate-request-cancellation-through-context-forms-and-streams.md)
- [BR-067 — Define stable framework error codes and redaction policy](../m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md)

## Blocks

- [BR-077 — Profile large-table rendering and form parsing, then set beta budgets](br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-072
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
