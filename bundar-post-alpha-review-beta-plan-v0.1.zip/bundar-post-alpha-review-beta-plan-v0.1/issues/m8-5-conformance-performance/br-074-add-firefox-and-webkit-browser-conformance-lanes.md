---
type: GitHub Issue Specification
title: BR-074 — Add Firefox and WebKit browser conformance lanes
description: Bundar's stable browser claims cover Chromium, Firefox, and WebKit for
  the supported htmx 2 workflows, with experimental htmx 4 deviations reported separately.
tags:
- github-issue
- bundar
- browser
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-074
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:browser
  - type:test
  - status:proposed
  depends_on:
  - BR-037
  - BR-043
  - BR-073
  blocks:
  - BR-085
  agent_ready: true
---

# BR-074 — Add Firefox and WebKit browser conformance lanes

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `browser`  
**Type:** `test`

## Outcome

Bundar's stable browser claims cover Chromium, Firefox, and WebKit for the supported htmx 2 workflows, with experimental htmx 4 deviations reported separately.

## Why this task exists

The alpha gate explicitly accepts Chrome-only browser evidence. Beta should broaden confidence or clearly retain a narrower support claim.

## Deliverables

- Run the canonical navigation, forms, validation, redirects/history, OOB/multi-region, errors, CSRF/session, and asset/CSP fixtures in Playwright Firefox and WebKit.
- Separate framework defects, htmx upstream differences, browser-engine differences, and harness flakiness.
- Define retry/quarantine policy that cannot convert consistent failures into warnings.

## Out of scope

- Mobile-device certification
- Supporting Internet Explorer

## Acceptance criteria

- [ ] Stable htmx 2 lanes pass on all claimed engines or the compatibility matrix narrows the claim explicitly.
- [ ] Every skipped/deviating case has owner, upstream link if applicable, and review trigger.
- [ ] Screenshots/traces are retained only on failure and contain no secrets.
- [ ] The release gate consumes machine-readable per-engine results.

## Agent context contract

### Read set

- `tests/browser/**`
- `playwright.config.ts`
- `docs/compatibility/browsers.md`
- `artifacts/conformance/**`

### Write set

- `tests/browser/**`
- `playwright.config.ts`
- `docs/compatibility/browsers.md`
- `artifacts/conformance/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tests/browser/**`
- `playwright.config.ts`
- `docs/compatibility/browsers.md`
- `artifacts/conformance/**`

## Verification

```bash
bun run test:browser:chromium
bun run test:browser:firefox
bun run test:browser:webkit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-037 — Close Todo feature-slice regression and source-diff evidence](../m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md)
- [BR-043 — Close Admin feature-slice regression and architecture evidence](../m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md)
- [BR-073 — Revalidate the neutral HTMX contract against the official v4 upgrade checker](br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-074
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
