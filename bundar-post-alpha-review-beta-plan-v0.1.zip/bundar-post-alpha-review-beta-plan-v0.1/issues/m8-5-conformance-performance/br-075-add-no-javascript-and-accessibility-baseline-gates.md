---
type: GitHub Issue Specification
title: BR-075 — Add no-JavaScript and accessibility baseline gates
description: Canonical workflows remain operable without HTMX and meet a documented
  server-rendered accessibility baseline.
tags:
- github-issue
- bundar
- browser
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-075
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:browser
  - type:test
  - status:proposed
  depends_on:
  - BR-031
  - BR-037
  - BR-043
  - BR-065
  blocks:
  - BR-085
  agent_ready: true
---

# BR-075 — Add no-JavaScript and accessibility baseline gates

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `browser`  
**Type:** `test`

## Outcome

Canonical workflows remain operable without HTMX and meet a documented server-rendered accessibility baseline.

## Why this task exists

Progressive enhancement is a core product claim; accessibility should be tested on the same semantic HTML rather than treated as separate polish.

## Deliverables

- Cover keyboard-only navigation, labels/names, focus after validation/navigation, landmarks/headings, status/alert regions, table semantics, and no-JS create/edit/delete flows.
- Run an automated accessibility scan plus targeted assertions that automation cannot prove.
- Document focus-management responsibilities for full navigation and HTMX swaps across dialects.

## Out of scope

- WCAG certification
- Application-specific design-system audit

## Acceptance criteria

- [ ] Disabling JavaScript still permits all core mutation workflows through PRG.
- [ ] Automated critical/serious accessibility violations are zero in canonical pages or explicitly waived with rationale.
- [ ] Validation errors are associated with fields and announced appropriately.
- [ ] HTMX-enhanced focus/history behavior does not make the no-JS structure less semantic.

## Agent context contract

### Read set

- `tests/browser/no-js/**`
- `tests/browser/accessibility/**`
- `examples/**/src/**/ui/**`
- `docs/guides/accessibility.md`

### Write set

- `tests/browser/no-js/**`
- `tests/browser/accessibility/**`
- `examples/**/src/**/ui/**`
- `docs/guides/accessibility.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tests/browser/no-js/**`
- `tests/browser/accessibility/**`
- `examples/**/src/**/ui/**`
- `docs/guides/accessibility.md`

## Verification

```bash
bun run test:no-js
bun run test:a11y
bun run test:browser:accessibility
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-031 — Document and gate the minimal starter architecture](../m8-2-agent-architecture/br-031-document-and-gate-the-minimal-starter-architecture.md)
- [BR-037 — Close Todo feature-slice regression and source-diff evidence](../m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md)
- [BR-043 — Close Admin feature-slice regression and architecture evidence](../m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md)
- [BR-065 — Integrate CSP nonces with documents and `HtmxScript`](../m8-4-production-security/br-065-integrate-csp-nonces-with-documents-and-htmxscript.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-075
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
