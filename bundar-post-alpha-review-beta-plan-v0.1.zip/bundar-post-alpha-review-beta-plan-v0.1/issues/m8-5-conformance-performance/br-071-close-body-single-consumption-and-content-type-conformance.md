---
type: GitHub Issue Specification
title: BR-071 — Close body single-consumption and content-type conformance
description: Context, validation, and form helpers share one explicit body-consumption
  contract across JSON, URL-encoded, multipart, text, missing, malformed, unsupported,
  and already-consumed bodies.
tags:
- github-issue
- bundar
- core
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-071
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:core
  - type:test
  - status:proposed
  depends_on:
  - BR-015
  - BR-066
  - BR-067
  blocks:
  - BR-077
  - BR-085
  agent_ready: true
---

# BR-071 — Close body single-consumption and content-type conformance

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `core`  
**Type:** `test`

## Outcome

Context, validation, and form helpers share one explicit body-consumption contract across JSON, URL-encoded, multipart, text, missing, malformed, unsupported, and already-consumed bodies.

## Why this task exists

Multiple convenience layers can accidentally read a Request body twice or return inconsistent errors.

## Deliverables

- Define lazy body cache/ownership and conflicts among `json`, `form`, raw stream, text, and validator helpers.
- Specify content-type parameters, charset handling, missing/empty body behavior, and 400 versus 415 classification.
- Cover middleware-read, handler-read, validation-read, clone, abort, and streaming cases.

## Out of scope

- Content negotiation for arbitrary API representations

## Acceptance criteria

- [ ] The same body is never parsed twice unintentionally.
- [ ] Conflicting body access produces a stable actionable error rather than engine-specific failure text.
- [ ] Unsupported or malformed media types map to documented error codes/statuses.
- [ ] Limits and redaction from BR-066/067 apply uniformly.

## Agent context contract

### Read set

- `packages/core/src/body.ts`
- `packages/core/src/context.ts`
- `packages/forms/src/**`
- `packages/schema/src/**`
- `packages/core/test/body/**`

### Write set

- `packages/core/src/body.ts`
- `packages/core/src/context.ts`
- `packages/forms/src/**`
- `packages/schema/src/**`
- `packages/core/test/body/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/body.ts`
- `packages/core/src/context.ts`
- `packages/forms/src/**`
- `packages/schema/src/**`
- `packages/core/test/body/**`

## Verification

```bash
bun test packages/core/test/body/** packages/forms/test/body/** packages/schema/test/body/**
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)
- [BR-066 — Enforce multipart and form request-complexity limits](../m8-4-production-security/br-066-enforce-multipart-and-form-request-complexity-limits.md)
- [BR-067 — Define stable framework error codes and redaction policy](../m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md)

## Blocks

- [BR-077 — Profile large-table rendering and form parsing, then set beta budgets](br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-071
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
