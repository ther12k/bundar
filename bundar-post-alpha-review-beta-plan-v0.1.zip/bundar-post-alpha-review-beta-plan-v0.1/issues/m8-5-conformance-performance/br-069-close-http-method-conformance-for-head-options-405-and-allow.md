---
type: GitHub Issue Specification
title: BR-069 — Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow
description: Bundar has one documented, tested policy for implicit HEAD, automatic
  or explicit OPTIONS, method-not-allowed responses, and the `Allow` header over native
  Bun routes.
tags:
- github-issue
- bundar
- core
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-069
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:core
  - type:test
  - status:proposed
  depends_on:
  - BR-003
  - BR-067
  blocks:
  - BR-085
  agent_ready: true
---

# BR-069 — Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `core`  
**Type:** `test`

## Outcome

Bundar has one documented, tested policy for implicit HEAD, automatic or explicit OPTIONS, method-not-allowed responses, and the `Allow` header over native Bun routes.

## Why this task exists

Frameworks often pass happy-path route tests while method semantics drift between static, dynamic, grouped, and fallback routes.

## Deliverables

- Specify whether GET implies HEAD and whether the handler executes or the body is stripped by a wrapper.
- Specify automatic versus explicit OPTIONS and CORS interaction.
- Differentiate not found from method not allowed and emit deterministic `Allow` values.
- Cover static Response, sync/async handler, wildcard, parameter, group/module, and custom fallback routes.

## Out of scope

- Full CORS middleware

## Acceptance criteria

- [ ] HEAD returns GET-equivalent status/headers with no response body under the chosen policy.
- [ ] OPTIONS and 405 behavior is consistent across route forms.
- [ ] `Allow` is sorted/deduplicated and includes implicit methods correctly.
- [ ] Native Bun behavior changes are captured by a compatibility fixture rather than silently inherited.

## Agent context contract

### Read set

- `packages/core/src/compiler.ts`
- `packages/core/src/methods.ts`
- `packages/core/test/http-methods/**`
- `docs/reference/routing.md`

### Write set

- `packages/core/src/compiler.ts`
- `packages/core/src/methods.ts`
- `packages/core/test/http-methods/**`
- `docs/reference/routing.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/compiler.ts`
- `packages/core/src/methods.ts`
- `packages/core/test/http-methods/**`
- `docs/reference/routing.md`

## Verification

```bash
bun test packages/core/test/http-methods/**
bun run test:integration:core
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-003 — Move middleware composition fully into the compile phase](../m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md)
- [BR-067 — Define stable framework error codes and redaction policy](../m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-069
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
