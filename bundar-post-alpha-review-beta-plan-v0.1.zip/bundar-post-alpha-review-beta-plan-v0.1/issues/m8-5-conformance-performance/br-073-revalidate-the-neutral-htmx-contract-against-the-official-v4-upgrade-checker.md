---
type: GitHub Issue Specification
title: BR-073 — Revalidate the neutral HTMX contract against the official v4 upgrade
  checker
description: Bundar's audit and dialect model identify every currently documented
  htmx 2-to-4 beta incompatibility and agree with the official upgrade checker on
  shared cases.
tags:
- github-issue
- bundar
- htmx
- compatibility
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-073
  milestone: M8.5 — Conformance, browsers, and performance
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:htmx
  - type:compatibility
  - status:proposed
  depends_on:
  - BR-017
  - BR-020
  - BR-064
  blocks:
  - BR-074
  - BR-085
  agent_ready: true
---

# BR-073 — Revalidate the neutral HTMX contract against the official v4 upgrade checker

**Milestone:** M8.5 — Conformance, browsers, and performance  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `htmx`  
**Type:** `compatibility`

## Outcome

Bundar's audit and dialect model identify every currently documented htmx 2-to-4 beta incompatibility and agree with the official upgrade checker on shared cases.

## Why this task exists

HTMX 4 remains beta, but Bundar can reduce migration risk now by testing its normalized contract and avoiding blind spots.

## Deliverables

- Run the official upgrade checker over starter/reference source fixtures and capture machine-readable results where possible.
- Map each upstream finding to Bundar stable subset, adapter-normalized behavior, intentional escape hatch, unsupported case, or false positive.
- Add parity fixtures for explicit inheritance, error swapping, renamed headers/events, request type, history, extensions, and partials.
- Keep the official checker as advisory evidence; Bundar's own deterministic audit remains required.

## Out of scope

- Reopening the upstream-gated GA milestone
- Depending on a remote checker in every CI run

## Acceptance criteria

- [ ] No official-checker finding is silently ignored.
- [ ] Bundar's audit catches all source-level version-specific patterns in the shared fixture corpus.
- [ ] Application source that stays within the stable subset remains unchanged between dialect files.
- [ ] Documentation still labels htmx 4 beta support experimental and makes no GA claim.

## Agent context contract

### Read set

- `packages/cli/src/commands/htmx-audit.ts`
- `packages/htmx/test/compatibility/**`
- `docs/compatibility/matrix.md`
- `artifacts/compatibility/**`

### Write set

- `packages/cli/src/commands/htmx-audit.ts`
- `packages/htmx/test/compatibility/**`
- `docs/compatibility/matrix.md`
- `artifacts/compatibility/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/cli/src/commands/htmx-audit.ts`
- `packages/htmx/test/compatibility/**`
- `docs/compatibility/matrix.md`
- `artifacts/compatibility/**`

## Verification

```bash
bun packages/cli/src/bin.ts htmx-audit examples templates --json
bun run test:dual-app
bun run test:browser:htmx2
bun run test:browser:htmx4
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)
- [BR-020 — Regenerate package API docs, diagrams, and migration guidance](../m8-1-package-boundaries/br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md)
- [BR-064 — Validate redirect targets and all HTMX response header values](../m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md)

## Blocks

- [BR-074 — Add Firefox and WebKit browser conformance lanes](br-074-add-firefox-and-webkit-browser-conformance-lanes.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-073
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
