---
type: Milestone Issue Index
title: M8.5 — Conformance, browsers, and performance
description: Broaden protocol/browser evidence and measure target workloads fairly.
tags:
- bundar
- issues
- milestone
- m8-5-conformance-performance
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# M8.5 — Conformance, browsers, and performance

## Goal

Broaden protocol/browser evidence and measure target workloads fairly.

## Exit conditions

- [ ] HTTP edge and stream conformance pass
- [ ] HTMX upgrade parity recorded
- [ ] Claimed browsers/no-JS/a11y pass
- [ ] Target-workload budgets pass

| ID | Priority | Size | Area | Task | Depends on |
| --- | --- | --- | --- | --- | --- |
| [BR-069](br-069-close-http-method-conformance-for-head-options-405-and-allow.md) | P1 | M | core | Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow | BR-003, BR-067 |
| [BR-070](br-070-close-route-edge-case-and-collision-conformance.md) | P1 | M | core | Close route edge-case and collision conformance | BR-003, BR-067 |
| [BR-071](br-071-close-body-single-consumption-and-content-type-conformance.md) | P1 | M | core | Close body single-consumption and content-type conformance | BR-015, BR-066, BR-067 |
| [BR-072](br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md) | P1 | M | jsx | Close streaming backpressure, cancellation, and late-error conformance | BR-058, BR-067 |
| [BR-073](br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md) | P1 | M | htmx | Revalidate the neutral HTMX contract against the official v4 upgrade checker | BR-017, BR-020, BR-064 |
| [BR-074](br-074-add-firefox-and-webkit-browser-conformance-lanes.md) | P1 | M | browser | Add Firefox and WebKit browser conformance lanes | BR-037, BR-043, BR-073 |
| [BR-075](br-075-add-no-javascript-and-accessibility-baseline-gates.md) | P1 | M | browser | Add no-JavaScript and accessibility baseline gates | BR-031, BR-037, BR-043, BR-065 |
| [BR-076](br-076-add-carno-js-as-a-fair-backend-framework-benchmark-reference.md) | P2 | M | performance | Add Carno.js as a fair backend-framework benchmark reference | BR-004, BR-017 |
| [BR-077](br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md) | P2 | M | performance | Profile large-table rendering and form parsing, then set beta budgets | BR-052, BR-066, BR-071, BR-072, BR-076 |

## Gate

All issues must satisfy [`../../delivery/DEFINITION_OF_DONE.md`](../../delivery/DEFINITION_OF_DONE.md). The milestone is not closed solely because all code issues were merged; run and record its integrated gate.
