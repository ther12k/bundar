---
type: GitHub Issue Specification
title: BR-084 — Run an independent greenfield human-and-agent usability study
description: A participant with no implementation history builds a bounded Bundar
  feature using only published packages, public docs, local agent maps, and the agent-context
  command.
tags:
- github-issue
- bundar
- agents
- validation
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-084
  milestone: M8.6 — Distribution and beta readiness
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:agents
  - type:validation
  - status:proposed
  depends_on:
  - BR-025
  - BR-048
  - BR-082
  blocks:
  - BR-085
  agent_ready: true
---

# BR-084 — Run an independent greenfield human-and-agent usability study

**Milestone:** M8.6 — Distribution and beta readiness  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `agents`  
**Type:** `validation`

## Outcome

A participant with no implementation history builds a bounded Bundar feature using only published packages, public docs, local agent maps, and the agent-context command.

## Why this task exists

The team that designed the framework can miss confusing APIs and hidden repository knowledge, especially for AI-agent-friendly claims.

## Deliverables

- Define two equivalent tasks: a human-first path and an AI-agent-assisted path.
- Measure setup success, files read, context bytes/tokens, edits, test iterations, elapsed effort, architecture violations, and unresolved questions.
- Prohibit access to private chat history and unpublished design rationale.
- Convert observed blockers into scoped issues rather than changing acceptance criteria mid-study.

## Out of scope

- Marketing claims from a single successful run
- Collecting personal/sensitive participant data

## Acceptance criteria

- [ ] At least one participant or independent agent not used to implement Bundar completes or clearly fails the task.
- [ ] The study records raw prompts/instructions and outputs after removing secrets.
- [ ] Agent context stays within the declared budget and does not omit required contracts.
- [ ] Results distinguish framework problems, documentation problems, model/tool limitations, and task ambiguity.

## Agent context contract

### Read set

- `studies/greenfield/**`
- `artifacts/usability/**`
- `docs/research/agent-friendliness.md`

### Write set

- `studies/greenfield/**`
- `artifacts/usability/**`
- `docs/research/agent-friendliness.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `studies/greenfield/**`
- `artifacts/usability/**`
- `docs/research/agent-friendliness.md`

## Verification

```bash
bun run study:greenfield -- --fixture feature
bun run app:architecture:check artifacts/usability/generated-app
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-025 — Expose `create-bundar --structure feature`](../m8-2-agent-architecture/br-025-expose-create-bundar-structure-feature.md)
- [BR-048 — Add `bundar agent-context <feature>` bounded context packs](../m8-3-agent-tooling/br-048-add-bundar-agent-context-feature-bounded-context-packs.md)
- [BR-082 — Run an external clean-repository consumer smoke test](br-082-run-an-external-clean-repository-consumer-smoke-test.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-084
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
