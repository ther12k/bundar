---
type: GitHub Issue Specification
title: BR-078 — Freeze alpha-to-beta versioning and publication policy
description: Bundar has one explicit policy for package versions, private flags, dist-tags,
  dependency ranges, release branches/tags, and compatibility promises after the package
  topology changes.
tags:
- github-issue
- bundar
- release
- adr
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-078
  milestone: M8.6 — Distribution and beta readiness
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:release
  - type:adr
  - status:proposed
  depends_on:
  - BR-017
  - BR-019
  blocks:
  - BR-079
  - BR-080
  agent_ready: true
---

# BR-078 — Freeze alpha-to-beta versioning and publication policy

**Milestone:** M8.6 — Distribution and beta readiness  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `release`  
**Type:** `adr`

## Outcome

Bundar has one explicit policy for package versions, private flags, dist-tags, dependency ranges, release branches/tags, and compatibility promises after the package topology changes.

## Why this task exists

The workspace remains private at `0.0.0` while a GitHub alpha exists. Publication must not improvise version semantics package by package.

## Deliverables

- Choose synchronized versus independent package versions for the pre-1.0 line.
- Define `alpha`, `beta`, `next`, and `latest` dist-tag rules and whether `latest` remains empty until stable.
- Define exact internal dependency ranges, peer/optional dependencies, deprecation windows, and rollback/yank policy.
- Record how GitHub source releases relate to registry packages.

## Out of scope

- Publishing packages
- Promising semantic stability beyond the chosen pre-1.0 contract

## Acceptance criteria

- [ ] Every public package has an intended first published version and tag.
- [ ] The policy prevents an experimental htmx 4 adapter from implying GA support.
- [ ] Internal package dependency ranges install from a clean registry without workspace aliases.
- [ ] Human approval boundaries and noninteractive automation behavior are explicit.

## Agent context contract

### Read set

- `decisions/0020-package-versioning-and-publication.md`
- `engineering/versioning.md`
- `engineering/release-gates.md`
- `packages/*/package.json`

### Write set

- `decisions/0020-package-versioning-and-publication.md`
- `engineering/versioning.md`
- `engineering/release-gates.md`
- `packages/*/package.json`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `decisions/0020-package-versioning-and-publication.md`
- `engineering/versioning.md`
- `engineering/release-gates.md`
- `packages/*/package.json`

## Verification

```bash
bun run release:plan --json
bun run package:audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)
- [BR-019 — Add packed external type consumers for every public export map](../m8-1-package-boundaries/br-019-add-packed-external-type-consumers-for-every-public-export-map.md)

## Blocks

- [BR-079 — Resolve npm namespace, credentials, provenance, and human approval gate](br-079-resolve-npm-namespace-credentials-provenance-and-human-approval-gate.md)
- [BR-080 — Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors](br-080-re-audit-tarballs-exports-licenses-sbom-and-provenance-after-refactors.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-078
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
