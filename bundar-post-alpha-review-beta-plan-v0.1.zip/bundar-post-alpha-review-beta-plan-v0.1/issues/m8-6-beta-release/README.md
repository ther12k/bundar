---
type: Milestone Issue Index
title: M8.6 — Distribution and beta readiness
description: Prove real external distribution and issue the beta decision.
tags:
- bundar
- issues
- milestone
- m8-6-beta-release
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# M8.6 — Distribution and beta readiness

## Goal

Prove real external distribution and issue the beta decision.

## Exit conditions

- [ ] Registry human gate complete
- [ ] Canary packages externally install
- [ ] Migration and independent usability evidence pass
- [ ] One-commit beta GO/NO-GO recorded

| ID | Priority | Size | Area | Task | Depends on |
| --- | --- | --- | --- | --- | --- |
| [BR-078](br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md) | P0 | S | release | Freeze alpha-to-beta versioning and publication policy | BR-017, BR-019 |
| [BR-079](br-079-resolve-npm-namespace-credentials-provenance-and-human-approval-gate.md) | P0 | XS | release | Resolve npm namespace, credentials, provenance, and human approval gate | BR-078 |
| [BR-080](br-080-re-audit-tarballs-exports-licenses-sbom-and-provenance-after-refactors.md) | P0 | M | release | Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors | BR-020, BR-078 |
| [BR-081](br-081-publish-a-guarded-canary-and-verify-registry-metadata.md) | P0 | S | release | Publish a guarded canary and verify registry metadata | BR-079, BR-080 |
| [BR-082](br-082-run-an-external-clean-repository-consumer-smoke-test.md) | P0 | M | release | Run an external clean-repository consumer smoke test | BR-081, BR-025 |
| [BR-083](br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md) | P1 | M | compatibility | Build and verify an alpha-to-beta migration fixture | BR-018, BR-051, BR-082 |
| [BR-084](br-084-run-an-independent-greenfield-human-and-agent-usability-study.md) | P1 | M | agents | Run an independent greenfield human-and-agent usability study | BR-025, BR-048, BR-082 |
| [BR-085](br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md) | P0 | M | release | Run the beta release gate and issue an evidence-backed go/no-go | BR-004, BR-006, BR-009, BR-010, BR-017, BR-019, BR-020, BR-026, BR-031, BR-037, BR-043, BR-045, BR-048, BR-051, BR-053, BR-056, BR-062, BR-063, BR-064, BR-065, BR-066, BR-067, BR-068, BR-069, BR-070, BR-071, BR-072, BR-073, BR-074, BR-075, BR-077, BR-082, BR-083, BR-084 |

## Gate

All issues must satisfy [`../../delivery/DEFINITION_OF_DONE.md`](../../delivery/DEFINITION_OF_DONE.md). The milestone is not closed solely because all code issues were merged; run and record its integrated gate.
