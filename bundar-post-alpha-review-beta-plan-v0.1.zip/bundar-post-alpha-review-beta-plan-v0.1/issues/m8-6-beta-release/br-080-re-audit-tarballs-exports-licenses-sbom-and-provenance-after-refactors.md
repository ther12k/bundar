---
type: GitHub Issue Specification
title: BR-080 — Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors
description: The final beta candidate artifacts contain only intended files, resolve
  every export, declare every dependency, reproduce byte-for-byte where promised,
  and carry updated legal/security metadata.
tags:
- github-issue
- bundar
- release
- audit
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-080
  milestone: M8.6 — Distribution and beta readiness
  priority: P0
  size: M
  labels:
  - priority:p0
  - size:m
  - area:release
  - type:audit
  - status:proposed
  depends_on:
  - BR-020
  - BR-078
  blocks:
  - BR-081
  agent_ready: true
---

# BR-080 — Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors

**Milestone:** M8.6 — Distribution and beta readiness  
**Priority:** `P0`  
**Size:** `M`  
**Area:** `release`  
**Type:** `audit`

## Outcome

The final beta candidate artifacts contain only intended files, resolve every export, declare every dependency, reproduce byte-for-byte where promised, and carry updated legal/security metadata.

## Why this task exists

Package-boundary and example refactors invalidate the alpha artifact audit even if runtime behavior is unchanged.

## Deliverables

- Pack all packages in dependency order and inspect file lists, sizes, exports, source maps, type declarations, licenses, readmes, and dependency metadata.
- Regenerate checksums, SBOM, provenance, and reproducibility records from the candidate commit.
- Scan for workspace paths, private files, credentials, test fixtures, unsupported binaries, and stale versions.

## Out of scope

- Publishing to a registry

## Acceptance criteria

- [ ] Clean-room install/build/run succeeds solely from candidate tarballs.
- [ ] Every export map target exists and every shipped import resolves from declared dependencies.
- [ ] SBOM/provenance/checksums bind to the exact candidate commit and tarballs.
- [ ] Repacking under the documented environment reproduces the expected artifacts or records justified nondeterminism.

## Agent context contract

### Read set

- `artifacts/packages/**`
- `artifacts/sbom/**`
- `artifacts/provenance/**`
- `tools/packages/**`
- `packages/*/package.json`

### Write set

- `artifacts/packages/**`
- `artifacts/sbom/**`
- `artifacts/provenance/**`
- `tools/packages/**`
- `packages/*/package.json`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `artifacts/packages/**`
- `artifacts/sbom/**`
- `artifacts/provenance/**`
- `tools/packages/**`
- `packages/*/package.json`

## Verification

```bash
bun run pack:all
bun run package:audit
bun run test:consumer:packed
bun run sbom:generate
bun run provenance:verify
bun run reproducibility:check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-020 — Regenerate package API docs, diagrams, and migration guidance](../m8-1-package-boundaries/br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md)
- [BR-078 — Freeze alpha-to-beta versioning and publication policy](br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md)

## Blocks

- [BR-081 — Publish a guarded canary and verify registry metadata](br-081-publish-a-guarded-canary-and-verify-registry-metadata.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-080
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
