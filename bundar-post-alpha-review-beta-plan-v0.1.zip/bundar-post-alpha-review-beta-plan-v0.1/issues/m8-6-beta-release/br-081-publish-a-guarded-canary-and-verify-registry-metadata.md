---
type: GitHub Issue Specification
title: BR-081 — Publish a guarded canary and verify registry metadata
description: A non-default canary/pre-release is published in dependency order and
  its registry metadata, provenance, and installability are verified before beta.
tags:
- github-issue
- bundar
- release
- release
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-081
  milestone: M8.6 — Distribution and beta readiness
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:release
  - type:release
  - status:proposed
  depends_on:
  - BR-079
  - BR-080
  blocks:
  - BR-082
  agent_ready: true
---

# BR-081 — Publish a guarded canary and verify registry metadata

**Milestone:** M8.6 — Distribution and beta readiness  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `release`  
**Type:** `release`

## Outcome

A non-default canary/pre-release is published in dependency order and its registry metadata, provenance, and installability are verified before beta.

## Why this task exists

A GitHub release and clean tarball fixture do not prove real registry behavior.

## Deliverables

- Publish the exact audited tarballs under the approved non-default tag.
- Verify versions, dist-tags, integrity, provenance, dependency graph, README rendering, and deprecation metadata from registry responses.
- Record rollback/deprecation steps if any package is incorrect.

## Out of scope

- Declaring beta readiness
- Publishing htmx 4 GA support

## Acceptance criteria

- [ ] No package is tagged `latest` unless the policy explicitly permits it.
- [ ] Published integrity hashes match the audited tarballs.
- [ ] A clean environment installs using only the registry and lockfile.
- [ ] The release transcript redacts credentials and records human approval.

## Agent context contract

### Read set

- `artifacts/release/canary/**`
- `delivery/gates/registry.md`
- `docs/maintainers/publishing.md`

### Write set

- `artifacts/release/canary/**`
- `delivery/gates/registry.md`
- `docs/maintainers/publishing.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `artifacts/release/canary/**`
- `delivery/gates/registry.md`
- `docs/maintainers/publishing.md`

## Verification

```bash
bun run publish:approved -- --tag canary
npm view @bundar/core --json
bun run registry:verify
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-079 — Resolve npm namespace, credentials, provenance, and human approval gate](br-079-resolve-npm-namespace-credentials-provenance-and-human-approval-gate.md)
- [BR-080 — Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors](br-080-re-audit-tarballs-exports-licenses-sbom-and-provenance-after-refactors.md)

## Blocks

- [BR-082 — Run an external clean-repository consumer smoke test](br-082-run-an-external-clean-repository-consumer-smoke-test.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-081
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
