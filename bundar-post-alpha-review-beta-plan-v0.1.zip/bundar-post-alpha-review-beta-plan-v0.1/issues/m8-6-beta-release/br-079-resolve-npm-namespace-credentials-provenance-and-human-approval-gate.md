---
type: GitHub Issue Specification
title: BR-079 — Resolve npm namespace, credentials, provenance, and human approval
  gate
description: The maintainer-owned registry prerequisites are verified without placing
  credentials in code, logs, issues, or agent context.
tags:
- github-issue
- bundar
- release
- human-gate
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-079
  milestone: M8.6 — Distribution and beta readiness
  priority: P0
  size: XS
  labels:
  - priority:p0
  - size:xs
  - area:release
  - type:human-gate
  - status:proposed
  depends_on:
  - BR-078
  blocks:
  - BR-081
  agent_ready: true
---

# BR-079 — Resolve npm namespace, credentials, provenance, and human approval gate

**Milestone:** M8.6 — Distribution and beta readiness  
**Priority:** `P0`  
**Size:** `XS`  
**Area:** `release`  
**Type:** `human-gate`

## Outcome

The maintainer-owned registry prerequisites are verified without placing credentials in code, logs, issues, or agent context.

## Why this task exists

The alpha gate explicitly records npm publication as pending maintainer credentials.

## Deliverables

- Verify ownership/access for every intended package name and scope.
- Configure least-privilege trusted publishing or token strategy, 2FA policy, provenance, and emergency revocation.
- Record the human approval identity and exact guarded publish command.

## Out of scope

- Actually publishing
- Sharing credentials with coding agents

## Acceptance criteria

- [ ] No credential value is committed, printed, uploaded, or included in an artifact.
- [ ] A read-only identity check confirms access to all package names.
- [ ] The guarded publish command refuses to run without explicit release approval.
- [ ] The task records who must act and cannot be falsely closed by an autonomous agent.

## Agent context contract

### Read set

- `delivery/gates/registry.md`
- `docs/maintainers/publishing.md`
- `.github/workflows/release.yml`

### Write set

- `delivery/gates/registry.md`
- `docs/maintainers/publishing.md`
- `.github/workflows/release.yml`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `delivery/gates/registry.md`
- `docs/maintainers/publishing.md`
- `.github/workflows/release.yml`

## Verification

```bash
npm whoami
npm access list packages
bun run publish:approved -- --dry-run
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-078 — Freeze alpha-to-beta versioning and publication policy](br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md)

## Blocks

- [BR-081 — Publish a guarded canary and verify registry metadata](br-081-publish-a-guarded-canary-and-verify-registry-metadata.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-079
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
