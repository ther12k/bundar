---
type: GitHub Issue Specification
title: BR-083 — Build and verify an alpha-to-beta migration fixture
description: A frozen alpha-style application upgrades to the beta candidate through
  documented changes and proves that package moves, typed URLs, and app structure
  guidance are practical.
tags:
- github-issue
- bundar
- compatibility
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-083
  milestone: M8.6 — Distribution and beta readiness
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:compatibility
  - type:test
  - status:proposed
  depends_on:
  - BR-018
  - BR-051
  - BR-082
  blocks:
  - BR-085
  agent_ready: true
---

# BR-083 — Build and verify an alpha-to-beta migration fixture

**Milestone:** M8.6 — Distribution and beta readiness  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `compatibility`  
**Type:** `test`

## Outcome

A frozen alpha-style application upgrades to the beta candidate through documented changes and proves that package moves, typed URLs, and app structure guidance are practical.

## Why this task exists

Compatibility re-exports and migration prose should be tested against a real source fixture.

## Deliverables

- Freeze an application using alpha-era import paths and representative HTTP/JSX/HTMX/forms/security APIs.
- Apply the documented migration manually or through an optional codemod.
- Record compile/runtime behavior before, during, and after migration.
- Cover removal/deprecation errors and rollback.

## Out of scope

- Guaranteeing compatibility with unpublished private snapshots

## Acceptance criteria

- [ ] The migration guide accounts for every source change in the fixture.
- [ ] Unchanged business actions and UI behavior remain equivalent.
- [ ] Deprecated compatibility paths produce the documented diagnostics.
- [ ] The migrated fixture passes ordinary, htmx 2, and experimental htmx 4 source-switch checks where supported.

## Agent context contract

### Read set

- `tests/migrations/alpha-beta/**`
- `docs/guides/alpha-to-beta.md`
- `tools/codemods/**`

### Write set

- `tests/migrations/alpha-beta/**`
- `docs/guides/alpha-to-beta.md`
- `tools/codemods/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tests/migrations/alpha-beta/**`
- `docs/guides/alpha-to-beta.md`
- `tools/codemods/**`

## Verification

```bash
bun run test:migration:alpha-beta
bun run test:dual-app tests/migrations/alpha-beta
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-018 — Provide compatibility re-exports for moved form APIs](../m8-1-package-boundaries/br-018-provide-compatibility-re-exports-for-moved-form-apis.md)
- [BR-051 — Dogfood generated typed URLs in Todo and Admin](../m8-3-agent-tooling/br-051-dogfood-generated-typed-urls-in-todo-and-admin.md)
- [BR-082 — Run an external clean-repository consumer smoke test](br-082-run-an-external-clean-repository-consumer-smoke-test.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-083
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
