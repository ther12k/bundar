---
type: GitHub Issue Specification
title: BR-082 — Run an external clean-repository consumer smoke test
description: A brand-new repository installs published Bundar packages, scaffolds
  or builds an app, and runs ordinary/HTMX/test workflows without monorepo files or
  unpublished assumptions.
tags:
- github-issue
- bundar
- release
- test
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-082
  milestone: M8.6 — Distribution and beta readiness
  priority: P0
  size: M
  labels:
  - priority:p0
  - size:m
  - area:release
  - type:test
  - status:proposed
  depends_on:
  - BR-081
  - BR-025
  blocks:
  - BR-083
  - BR-084
  - BR-085
  agent_ready: true
---

# BR-082 — Run an external clean-repository consumer smoke test

**Milestone:** M8.6 — Distribution and beta readiness  
**Priority:** `P0`  
**Size:** `M`  
**Area:** `release`  
**Type:** `test`

## Outcome

A brand-new repository installs published Bundar packages, scaffolds or builds an app, and runs ordinary/HTMX/test workflows without monorepo files or unpublished assumptions.

## Why this task exists

External consumption is the strongest check against workspace leakage and incomplete onboarding.

## Deliverables

- Create a clean temporary repository outside the Bundar tree.
- Install from the canary tag, scaffold compact and feature structures, and run typecheck/test/build/dev smoke journeys.
- Exercise TSX, local HTMX asset, one full page, one fragment, one valid/invalid form action, typed URL generation, and security defaults.
- Record all network/package inputs and lockfile.

## Out of scope

- Long-running production soak

## Acceptance criteria

- [ ] No workspace protocol, relative monorepo path, unpublished package, or source alias is required.
- [ ] Both scaffold structures work from published artifacts.
- [ ] The default app uses htmx 2 and does not require Rust, Node, React, or a client build.
- [ ] Failure logs are sufficient to reproduce without exposing tokens.

## Agent context contract

### Read set

- `tests/external-consumer/**`
- `artifacts/consumer/**`
- `docs/getting-started.md`

### Write set

- `tests/external-consumer/**`
- `artifacts/consumer/**`
- `docs/getting-started.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tests/external-consumer/**`
- `artifacts/consumer/**`
- `docs/getting-started.md`

## Verification

```bash
bun run test:external-consumer -- --tag canary
bun run registry:verify
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-081 — Publish a guarded canary and verify registry metadata](br-081-publish-a-guarded-canary-and-verify-registry-metadata.md)
- [BR-025 — Expose `create-bundar --structure feature`](../m8-2-agent-architecture/br-025-expose-create-bundar-structure-feature.md)

## Blocks

- [BR-083 — Build and verify an alpha-to-beta migration fixture](br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md)
- [BR-084 — Run an independent greenfield human-and-agent usability study](br-084-run-an-independent-greenfield-human-and-agent-usability-study.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-082
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
