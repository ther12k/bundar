---
type: GitHub Issue Specification
title: BR-085 — Run the beta release gate and issue an evidence-backed go/no-go
description: Bundar is labeled beta only when correctness, package architecture, agent-friendly
  examples, production safeguards, cross-browser evidence, performance budgets, registry
  consumption, migration, and documentation all pass from one candidate commit.
tags:
- github-issue
- bundar
- release
- gate
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-085
  milestone: M8.6 — Distribution and beta readiness
  priority: P0
  size: M
  labels:
  - priority:p0
  - size:m
  - area:release
  - type:gate
  - status:proposed
  depends_on:
  - BR-004
  - BR-006
  - BR-009
  - BR-010
  - BR-017
  - BR-019
  - BR-020
  - BR-026
  - BR-031
  - BR-037
  - BR-043
  - BR-045
  - BR-048
  - BR-051
  - BR-053
  - BR-056
  - BR-062
  - BR-063
  - BR-064
  - BR-065
  - BR-066
  - BR-067
  - BR-068
  - BR-069
  - BR-070
  - BR-071
  - BR-072
  - BR-073
  - BR-074
  - BR-075
  - BR-077
  - BR-082
  - BR-083
  - BR-084
  blocks: []
  agent_ready: true
---

# BR-085 — Run the beta release gate and issue an evidence-backed go/no-go

**Milestone:** M8.6 — Distribution and beta readiness  
**Priority:** `P0`  
**Size:** `M`  
**Area:** `release`  
**Type:** `gate`

## Outcome

Bundar is labeled beta only when correctness, package architecture, agent-friendly examples, production safeguards, cross-browser evidence, performance budgets, registry consumption, migration, and documentation all pass from one candidate commit.

## Why this task exists

The existing alpha gate is strong evidence for its scope. Beta needs a new gate rather than inheriting alpha conclusions after major refactors.

## Deliverables

- Build one fail-closed ordered beta battery and candidate manifest.
- Verify zero unresolved P0 and explicitly adjudicate every P1/residual risk.
- Regenerate docs, compatibility matrices, benchmarks, security reports, package artifacts, SBOM/provenance, browser results, consumer/migration/usability evidence, and release notes.
- Record human approval, exact candidate commit/tag, publish plan, rollback, and deferred htmx 4 GA status.

## Out of scope

- Executing the actual human-approved beta publish in the same automated task
- Closing upstream-blocked htmx 4 GA work

## Acceptance criteria

- [ ] All direct dependencies pass from the exact candidate commit.
- [ ] No skipped/waived mandatory check is hidden or converted to a warning.
- [ ] npm packages are installable externally under the intended beta tag.
- [ ] README and docs state precise browser, Bun, htmx, production, and pre-1.0 limitations.
- [ ] htmx 4 remains experimental unless official GA has separately triggered and passed the M7 chain.
- [ ] The final decision is GO or NO-GO with evidence links and accepted residual risks—not a percentage alone.

## Agent context contract

### Read set

- `delivery/gates/beta.md`
- `docs/release-notes/beta.md`
- `artifacts/release/beta/**`
- `README.md`
- `docs/compatibility/**`

### Write set

- `delivery/gates/beta.md`
- `docs/release-notes/beta.md`
- `artifacts/release/beta/**`
- `README.md`
- `docs/compatibility/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `delivery/gates/beta.md`
- `docs/release-notes/beta.md`
- `artifacts/release/beta/**`
- `README.md`
- `docs/compatibility/**`

## Verification

```bash
bun run ci:beta
bun run release:verify -- --channel beta
bun run publish:approved -- --tag beta --dry-run
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-004 — Guard middleware hot-path allocations with a release budget](../m8-0-correctness/br-004-guard-middleware-hot-path-allocations-with-a-release-budget.md)
- [BR-006 — Make the raw HTML trust marker non-accidentally forgeable](../m8-0-correctness/br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md)
- [BR-009 — Generate README status facts and fail on drift](../m8-0-correctness/br-009-generate-readme-status-facts-and-fail-on-drift.md)
- [BR-010 — Reconcile stale milestone and release claims across the corpus](../m8-0-correctness/br-010-reconcile-stale-milestone-and-release-claims-across-the-corpus.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)
- [BR-019 — Add packed external type consumers for every public export map](../m8-1-package-boundaries/br-019-add-packed-external-type-consumers-for-every-public-export-map.md)
- [BR-020 — Regenerate package API docs, diagrams, and migration guidance](../m8-1-package-boundaries/br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md)
- [BR-026 — Convert the canonical minimal starter UI to actual TSX](../m8-2-agent-architecture/br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md)
- [BR-031 — Document and gate the minimal starter architecture](../m8-2-agent-architecture/br-031-document-and-gate-the-minimal-starter-architecture.md)
- [BR-037 — Close Todo feature-slice regression and source-diff evidence](../m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md)
- [BR-043 — Close Admin feature-slice regression and architecture evidence](../m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md)
- [BR-045 — Introduce file-size and responsibility budgets with explicit exceptions](../m8-2-agent-architecture/br-045-introduce-file-size-and-responsibility-budgets-with-explicit-exceptions.md)
- [BR-048 — Add `bundar agent-context <feature>` bounded context packs](../m8-3-agent-tooling/br-048-add-bundar-agent-context-feature-bounded-context-packs.md)
- [BR-051 — Dogfood generated typed URLs in Todo and Admin](../m8-3-agent-tooling/br-051-dogfood-generated-typed-urls-in-todo-and-admin.md)
- [BR-053 — Remove manual HTML concatenation from reference applications](../m8-3-agent-tooling/br-053-remove-manual-html-concatenation-from-reference-applications.md)
- [BR-056 — Refactor examples away from manual cookie and Response reconstruction](../m8-3-agent-tooling/br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md)
- [BR-062 — Fail closed on memory sessions or insecure cookies in production](../m8-4-production-security/br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md)
- [BR-063 — Close session fixation, rotation, logout, and replay tests](../m8-4-production-security/br-063-close-session-fixation-rotation-logout-and-replay-tests.md)
- [BR-064 — Validate redirect targets and all HTMX response header values](../m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md)
- [BR-065 — Integrate CSP nonces with documents and `HtmxScript`](../m8-4-production-security/br-065-integrate-csp-nonces-with-documents-and-htmxscript.md)
- [BR-066 — Enforce multipart and form request-complexity limits](../m8-4-production-security/br-066-enforce-multipart-and-form-request-complexity-limits.md)
- [BR-067 — Define stable framework error codes and redaction policy](../m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md)
- [BR-068 — Add property and fuzz tests for high-risk parsers and serializers](../m8-4-production-security/br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md)
- [BR-069 — Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow](../m8-5-conformance-performance/br-069-close-http-method-conformance-for-head-options-405-and-allow.md)
- [BR-070 — Close route edge-case and collision conformance](../m8-5-conformance-performance/br-070-close-route-edge-case-and-collision-conformance.md)
- [BR-071 — Close body single-consumption and content-type conformance](../m8-5-conformance-performance/br-071-close-body-single-consumption-and-content-type-conformance.md)
- [BR-072 — Close streaming backpressure, cancellation, and late-error conformance](../m8-5-conformance-performance/br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md)
- [BR-073 — Revalidate the neutral HTMX contract against the official v4 upgrade checker](../m8-5-conformance-performance/br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md)
- [BR-074 — Add Firefox and WebKit browser conformance lanes](../m8-5-conformance-performance/br-074-add-firefox-and-webkit-browser-conformance-lanes.md)
- [BR-075 — Add no-JavaScript and accessibility baseline gates](../m8-5-conformance-performance/br-075-add-no-javascript-and-accessibility-baseline-gates.md)
- [BR-077 — Profile large-table rendering and form parsing, then set beta budgets](../m8-5-conformance-performance/br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md)
- [BR-082 — Run an external clean-repository consumer smoke test](br-082-run-an-external-clean-repository-consumer-smoke-test.md)
- [BR-083 — Build and verify an alpha-to-beta migration fixture](br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md)
- [BR-084 — Run an independent greenfield human-and-agent usability study](br-084-run-an-independent-greenfield-human-and-agent-usability-study.md)

## Blocks

- No direct issue in this plan.

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-085
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
