---
type: GitHub Issue Specification
title: BR-016 — Isolate Standard Schema integration behind a forms adapter
description: Form orchestration can consume Standard Schema results through an optional
  adapter without forcing `@bundar/htmx` or `@bundar/core` to depend on `@bundar/schema`.
tags:
- github-issue
- bundar
- forms
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-016
  milestone: M8.1 — Package-boundary reset
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:forms
  - type:refactor
  - status:proposed
  depends_on:
  - BR-014
  - BR-015
  blocks:
  - BR-017
  agent_ready: true
---

# BR-016 — Isolate Standard Schema integration behind a forms adapter

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `forms`  
**Type:** `refactor`

## Outcome

Form orchestration can consume Standard Schema results through an optional adapter without forcing `@bundar/htmx` or `@bundar/core` to depend on `@bundar/schema`.

## Why this task exists

Schema support is valuable, but package ownership must remain explicit and optional.

## Deliverables

- Define the minimal validation-port interface needed by form actions.
- Implement an adapter in `@bundar/schema` or an approved forms subpath.
- Preserve safe retained values, field-path normalization, issue redaction, and async schema support.

## Out of scope

- Choosing a specific validator
- Changing Standard Schema itself

## Acceptance criteria

- [ ] A custom validator adapter works without importing `@bundar/schema`.
- [ ] Standard Schema behavior matches current fixtures.
- [ ] Sensitive rejected values are not retained or logged by default.
- [ ] Dependency checks prove HTMX and core do not depend on schema because of forms.

## Agent context contract

### Read set

- `packages/forms/src/validation.ts`
- `packages/schema/src/forms-adapter.ts`
- `packages/schema/test/**`
- `packages/forms/test/**`

### Write set

- `packages/forms/src/validation.ts`
- `packages/schema/src/forms-adapter.ts`
- `packages/schema/test/**`
- `packages/forms/test/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/forms/src/validation.ts`
- `packages/schema/src/forms-adapter.ts`
- `packages/schema/test/**`
- `packages/forms/test/**`

## Verification

```bash
bun test packages/schema/** packages/forms/**
bun run architecture:check
bun run test:types
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-014 — Extract framework-neutral form action contracts](br-014-extract-framework-neutral-form-action-contracts.md)
- [BR-015 — Move progressive form orchestration into `@bundar/forms`](br-015-move-progressive-form-orchestration-into-bundar-forms.md)

## Blocks

- [BR-017 — Make `@bundar/htmx` protocol-pure](br-017-make-bundar-htmx-protocol-pure.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-016
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
