---
type: GitHub Issue Specification
title: BR-017 — Make `@bundar/htmx` protocol-pure
description: '`@bundar/htmx` owns normalized request metadata, response directives,
  dialects, assets, views, and update serialization without importing core or schema
  workflow internals.'
tags:
- github-issue
- bundar
- htmx
- refactor
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-017
  milestone: M8.1 — Package-boundary reset
  priority: P0
  size: M
  labels:
  - priority:p0
  - size:m
  - area:htmx
  - type:refactor
  - status:proposed
  depends_on:
  - BR-012
  - BR-015
  - BR-016
  blocks:
  - BR-018
  - BR-019
  - BR-024
  - BR-026
  - BR-032
  - BR-038
  - BR-052
  - BR-064
  - BR-065
  - BR-067
  - BR-073
  - BR-076
  - BR-078
  - BR-085
  agent_ready: true
---

# BR-017 — Make `@bundar/htmx` protocol-pure

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P0`  
**Size:** `M`  
**Area:** `htmx`  
**Type:** `refactor`

## Outcome

`@bundar/htmx` owns normalized request metadata, response directives, dialects, assets, views, and update serialization without importing core or schema workflow internals.

## Why this task exists

The inspected manifest/package documentation disagree about permitted dependencies. This task makes implementation match the chosen graph.

## Deliverables

- Remove forbidden core/schema dependencies and replace them with web-standard `Request`/`Response` or tiny neutral contracts.
- Move form workflow exports to `@bundar/forms` and retain only HTMX-specific response adapters in HTMX.
- Check versioned subpaths `/2` and `/4` for accidental cross-layer imports.
- Update package tests to instantiate protocol behavior without an `App` or `Context`.

## Out of scope

- Removing first-class HTMX support
- Changing dialect pins

## Acceptance criteria

- [ ] `packages/htmx/package.json` matches the BR-011 dependency matrix.
- [ ] Architecture checks show no forbidden source or manifest edge.
- [ ] Protocol tests run with standard Web API objects and no Bundar app kernel.
- [ ] Dual-dialect request/response fixtures remain byte-equivalent where the compatibility matrix says they should.

## Agent context contract

### Read set

- `packages/htmx/**`
- `packages/forms/**`
- `packages/core/**`
- `packages/schema/**`

### Write set

- `packages/htmx/**`
- `packages/forms/**`
- `packages/core/**`
- `packages/schema/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/htmx/**`
- `packages/forms/**`
- `packages/core/**`
- `packages/schema/**`

## Verification

```bash
bun run architecture:check
bun test packages/htmx/**
bun run test:browser:htmx2
bun run test:browser:htmx4
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-012 — Enforce the package dependency graph in CI](br-012-enforce-the-package-dependency-graph-in-ci.md)
- [BR-015 — Move progressive form orchestration into `@bundar/forms`](br-015-move-progressive-form-orchestration-into-bundar-forms.md)
- [BR-016 — Isolate Standard Schema integration behind a forms adapter](br-016-isolate-standard-schema-integration-behind-a-forms-adapter.md)

## Blocks

- [BR-018 — Provide compatibility re-exports for moved form APIs](br-018-provide-compatibility-re-exports-for-moved-form-apis.md)
- [BR-019 — Add packed external type consumers for every public export map](br-019-add-packed-external-type-consumers-for-every-public-export-map.md)
- [BR-024 — Create the canonical feature-slice scaffold tree](../m8-2-agent-architecture/br-024-create-the-canonical-feature-slice-scaffold-tree.md)
- [BR-026 — Convert the canonical minimal starter UI to actual TSX](../m8-2-agent-architecture/br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md)
- [BR-032 — Create the Todo feature-slice skeleton and migration map](../m8-2-agent-architecture/br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md)
- [BR-038 — Inventory and scaffold Admin reference features](../m8-2-agent-architecture/br-038-inventory-and-scaffold-admin-reference-features.md)
- [BR-052 — Add a typed primary-fragment and update-intent response API](../m8-3-agent-tooling/br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md)
- [BR-064 — Validate redirect targets and all HTMX response header values](../m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md)
- [BR-065 — Integrate CSP nonces with documents and `HtmxScript`](../m8-4-production-security/br-065-integrate-csp-nonces-with-documents-and-htmxscript.md)
- [BR-067 — Define stable framework error codes and redaction policy](../m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md)
- [BR-073 — Revalidate the neutral HTMX contract against the official v4 upgrade checker](../m8-5-conformance-performance/br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md)
- [BR-076 — Add Carno.js as a fair backend-framework benchmark reference](../m8-5-conformance-performance/br-076-add-carno-js-as-a-fair-backend-framework-benchmark-reference.md)
- [BR-078 — Freeze alpha-to-beta versioning and publication policy](../m8-6-beta-release/br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-017
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
