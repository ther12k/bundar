---
type: GitHub Issue Specification
title: BR-014 — Extract framework-neutral form action contracts
description: Input, validation, retained-value, field-error, transaction, and action-result
  contracts live in `@bundar/forms` without importing HTMX wire concepts.
tags:
- github-issue
- bundar
- forms
- refactor
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-014
  milestone: M8.1 — Package-boundary reset
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:forms
  - type:refactor
  - status:proposed
  depends_on:
  - BR-013
  blocks:
  - BR-015
  - BR-016
  agent_ready: true
---

# BR-014 — Extract framework-neutral form action contracts

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `forms`  
**Type:** `refactor`

## Outcome

Input, validation, retained-value, field-error, transaction, and action-result contracts live in `@bundar/forms` without importing HTMX wire concepts.

## Why this task exists

The package move should begin with types and pure state transitions so later runtime movement is mechanical and testable.

## Deliverables

- Move or define form action input/result types, validation outcome, retained-value policy, transaction hooks, and render callback contracts.
- Separate ordinary/enhanced intent at a neutral representation level rather than raw `HX-*` headers.
- Add compile-only consumer tests for validator-free and validator-integrated usage.

## Out of scope

- Runtime orchestration
- Changing form semantics

## Acceptance criteria

- [ ] The contracts import neither dialect adapters nor raw HTMX header names.
- [ ] No validator library is a mandatory runtime dependency.
- [ ] Existing application type inference remains equal or improves.
- [ ] Public API names are documented with ownership and stability level.

## Agent context contract

### Read set

- `packages/forms/src/contracts.ts`
- `packages/forms/src/index.ts`
- `packages/forms/test/**`
- `tests/consumers/forms/**`

### Write set

- `packages/forms/src/contracts.ts`
- `packages/forms/src/index.ts`
- `packages/forms/test/**`
- `tests/consumers/forms/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/forms/src/contracts.ts`
- `packages/forms/src/index.ts`
- `packages/forms/test/**`
- `tests/consumers/forms/**`

## Verification

```bash
bun test packages/forms/test/contracts.test.ts
bun run test:types
bun run architecture:check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-013 — Create the `@bundar/forms` package skeleton](br-013-create-the-bundar-forms-package-skeleton.md)

## Blocks

- [BR-015 — Move progressive form orchestration into `@bundar/forms`](br-015-move-progressive-form-orchestration-into-bundar-forms.md)
- [BR-016 — Isolate Standard Schema integration behind a forms adapter](br-016-isolate-standard-schema-integration-behind-a-forms-adapter.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-014
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
