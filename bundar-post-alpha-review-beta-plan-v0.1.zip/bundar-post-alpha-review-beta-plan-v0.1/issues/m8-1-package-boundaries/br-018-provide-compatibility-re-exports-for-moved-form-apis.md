---
type: GitHub Issue Specification
title: BR-018 — Provide compatibility re-exports for moved form APIs
description: Existing alpha source can migrate predictably after form APIs move, with
  deprecation messages and a documented removal window.
tags:
- github-issue
- bundar
- api
- compatibility
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-018
  milestone: M8.1 — Package-boundary reset
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:api
  - type:compatibility
  - status:proposed
  depends_on:
  - BR-017
  blocks:
  - BR-019
  - BR-020
  - BR-083
  agent_ready: true
---

# BR-018 — Provide compatibility re-exports for moved form APIs

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `api`  
**Type:** `compatibility`

## Outcome

Existing alpha source can migrate predictably after form APIs move, with deprecation messages and a documented removal window.

## Why this task exists

Pre-1.0 allows breaking changes, but deliberate compatibility reduces agent churn and makes the alpha-to-beta migration fixture meaningful.

## Deliverables

- Inventory moved public symbols and current import paths.
- Add temporary re-exports where they do not recreate forbidden runtime dependencies; otherwise provide compile-time codemod diagnostics.
- Document old path, new path, introduced version, removal target, and behavior changes.

## Out of scope

- Permanent legacy aliases
- Silent behavior changes

## Acceptance criteria

- [ ] Every moved exported symbol has either a working re-export or an explicit migration error with replacement.
- [ ] Deprecated paths do not restore forbidden package dependency edges.
- [ ] Type declarations mark deprecated APIs clearly.
- [ ] A fixture compiles on the alpha-style imports and the preferred beta-style imports.

## Agent context contract

### Read set

- `packages/*/src/index.ts`
- `tests/migrations/**`
- `docs/guides/alpha-to-beta.md`

### Write set

- `packages/*/src/index.ts`
- `tests/migrations/**`
- `docs/guides/alpha-to-beta.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/*/src/index.ts`
- `tests/migrations/**`
- `docs/guides/alpha-to-beta.md`

## Verification

```bash
bun run test:types
bun test tests/migrations/form-api-compat.test.ts
bun run architecture:check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-017 — Make `@bundar/htmx` protocol-pure](br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-019 — Add packed external type consumers for every public export map](br-019-add-packed-external-type-consumers-for-every-public-export-map.md)
- [BR-020 — Regenerate package API docs, diagrams, and migration guidance](br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md)
- [BR-083 — Build and verify an alpha-to-beta migration fixture](../m8-6-beta-release/br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-018
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
