---
type: GitHub Issue Specification
title: BR-020 — Regenerate package API docs, diagrams, and migration guidance
description: Documentation reflects the actual post-refactor ownership and gives application
  authors one unambiguous import path for each capability.
tags:
- github-issue
- bundar
- docs
- docs
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-020
  milestone: M8.1 — Package-boundary reset
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:docs
  - type:docs
  - status:proposed
  depends_on:
  - BR-018
  - BR-019
  blocks:
  - BR-073
  - BR-080
  - BR-085
  agent_ready: true
---

# BR-020 — Regenerate package API docs, diagrams, and migration guidance

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `docs`  
**Type:** `docs`

## Outcome

Documentation reflects the actual post-refactor ownership and gives application authors one unambiguous import path for each capability.

## Why this task exists

Package moves are incomplete until generated API references and architecture diagrams stop teaching the old coupling.

## Deliverables

- Regenerate API references from export maps.
- Update package dependency diagrams, getting started, validation, HTMX, security, and migration guides.
- Add a one-page ownership table mapping common tasks to packages.

## Out of scope

- New framework features

## Acceptance criteria

- [ ] Generated docs have no drift in CI.
- [ ] No guide imports `runFormAction` from a deprecated path without explicitly labeling it.
- [ ] The dependency graph in docs matches the machine-enforced graph.
- [ ] All snippets compile in the runnable documentation harness.

## Agent context contract

### Read set

- `docs/api/**`
- `docs/guides/**`
- `architecture/package-dependency-graph.md`
- `README.md`

### Write set

- `docs/api/**`
- `docs/guides/**`
- `architecture/package-dependency-graph.md`
- `README.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `docs/api/**`
- `docs/guides/**`
- `architecture/package-dependency-graph.md`
- `README.md`

## Verification

```bash
bun run docs:generate
bun run docs:check
bun run snippets:test
bun run architecture:check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-018 — Provide compatibility re-exports for moved form APIs](br-018-provide-compatibility-re-exports-for-moved-form-apis.md)
- [BR-019 — Add packed external type consumers for every public export map](br-019-add-packed-external-type-consumers-for-every-public-export-map.md)

## Blocks

- [BR-073 — Revalidate the neutral HTMX contract against the official v4 upgrade checker](../m8-5-conformance-performance/br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md)
- [BR-080 — Re-audit tarballs, exports, licenses, SBOM, and provenance after refactors](../m8-6-beta-release/br-080-re-audit-tarballs-exports-licenses-sbom-and-provenance-after-refactors.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-020
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
