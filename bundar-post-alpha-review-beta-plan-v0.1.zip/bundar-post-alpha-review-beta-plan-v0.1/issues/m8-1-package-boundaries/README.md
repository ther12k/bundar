---
type: Milestone Issue Index
title: M8.1 — Package-boundary reset
description: Reset package ownership before public registry consumers depend on it.
tags:
- bundar
- issues
- milestone
- m8-1-package-boundaries
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# M8.1 — Package-boundary reset

## Goal

Reset package ownership before public registry consumers depend on it.

## Exit conditions

- [ ] Dependency ADR enforced
- [ ] Forms ownership clear
- [ ] HTMX protocol-pure
- [ ] Packed consumers and API docs green

| ID | Priority | Size | Area | Task | Depends on |
| --- | --- | --- | --- | --- | --- |
| [BR-011](br-011-decide-and-freeze-the-post-alpha-package-dependency-graph.md) | P0 | S | architecture | Decide and freeze the post-alpha package dependency graph | BR-001 |
| [BR-012](br-012-enforce-the-package-dependency-graph-in-ci.md) | P0 | S | architecture | Enforce the package dependency graph in CI | BR-011 |
| [BR-013](br-013-create-the-bundar-forms-package-skeleton.md) | P0 | S | forms | Create the `@bundar/forms` package skeleton | BR-011 |
| [BR-014](br-014-extract-framework-neutral-form-action-contracts.md) | P0 | S | forms | Extract framework-neutral form action contracts | BR-013 |
| [BR-015](br-015-move-progressive-form-orchestration-into-bundar-forms.md) | P0 | M | forms | Move progressive form orchestration into `@bundar/forms` | BR-014 |
| [BR-016](br-016-isolate-standard-schema-integration-behind-a-forms-adapter.md) | P1 | S | forms | Isolate Standard Schema integration behind a forms adapter | BR-014, BR-015 |
| [BR-017](br-017-make-bundar-htmx-protocol-pure.md) | P0 | M | htmx | Make `@bundar/htmx` protocol-pure | BR-012, BR-015, BR-016 |
| [BR-018](br-018-provide-compatibility-re-exports-for-moved-form-apis.md) | P1 | S | api | Provide compatibility re-exports for moved form APIs | BR-017 |
| [BR-019](br-019-add-packed-external-type-consumers-for-every-public-export-map.md) | P1 | M | api | Add packed external type consumers for every public export map | BR-017, BR-018 |
| [BR-020](br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md) | P1 | S | docs | Regenerate package API docs, diagrams, and migration guidance | BR-018, BR-019 |

## Gate

All issues must satisfy [`../../delivery/DEFINITION_OF_DONE.md`](../../delivery/DEFINITION_OF_DONE.md). The milestone is not closed solely because all code issues were merged; run and record its integrated gate.
