---
type: GitHub Issue Specification
title: BR-019 — Add packed external type consumers for every public export map
description: Every package and subpath is validated from its packed artifact in clean
  TypeScript consumers rather than only from monorepo source aliases.
tags:
- github-issue
- bundar
- api
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-019
  milestone: M8.1 — Package-boundary reset
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:api
  - type:test
  - status:proposed
  depends_on:
  - BR-017
  - BR-018
  blocks:
  - BR-020
  - BR-078
  - BR-085
  agent_ready: true
---

# BR-019 — Add packed external type consumers for every public export map

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `api`  
**Type:** `test`

## Outcome

Every package and subpath is validated from its packed artifact in clean TypeScript consumers rather than only from monorepo source aliases.

## Why this task exists

Workspace resolution can hide missing files, undeclared dependencies, and export-map mistakes.

## Deliverables

- Pack each public package in dependency order.
- Create clean consumer fixtures for ESM imports, TSX runtime configuration, htmx `/2` and `/4`, forms, schema, security, testing, and CLI APIs.
- Test types, runtime import, tree entrypoints, and absence of monorepo path aliases.

## Out of scope

- Publishing to npm
- Supporting CommonJS unless separately decided

## Acceptance criteria

- [ ] All documented imports resolve from packed tarballs only.
- [ ] Undeclared dependency access fails the fixture rather than succeeding through workspace hoisting.
- [ ] The TSX consumer compiles using `jsxImportSource: @bundar/jsx`.
- [ ] The test records package size, file list, export map, and exact tarball checksums.

## Agent context contract

### Read set

- `tests/consumers/packed/**`
- `tools/packages/**`
- `packages/*/package.json`

### Write set

- `tests/consumers/packed/**`
- `tools/packages/**`
- `packages/*/package.json`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tests/consumers/packed/**`
- `tools/packages/**`
- `packages/*/package.json`

## Verification

```bash
bun run pack:all
bun run test:consumer:packed
bun run package:audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-017 — Make `@bundar/htmx` protocol-pure](br-017-make-bundar-htmx-protocol-pure.md)
- [BR-018 — Provide compatibility re-exports for moved form APIs](br-018-provide-compatibility-re-exports-for-moved-form-apis.md)

## Blocks

- [BR-020 — Regenerate package API docs, diagrams, and migration guidance](br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md)
- [BR-078 — Freeze alpha-to-beta versioning and publication policy](../m8-6-beta-release/br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-019
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
