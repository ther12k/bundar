---
type: GitHub Issue Specification
title: BR-011 — Decide and freeze the post-alpha package dependency graph
description: A final pre-beta ADR defines allowed package dependencies, optional peers,
  subpath exports, and the ownership of progressive form orchestration.
tags:
- github-issue
- bundar
- architecture
- adr
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-011
  milestone: M8.1 — Package-boundary reset
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:architecture
  - type:adr
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-012
  - BR-013
  agent_ready: true
---

# BR-011 — Decide and freeze the post-alpha package dependency graph

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `architecture`  
**Type:** `adr`

## Outcome

A final pre-beta ADR defines allowed package dependencies, optional peers, subpath exports, and the ownership of progressive form orchestration.

## Why this task exists

The intended architecture treats HTMX as a protocol adapter, but the inspected `@bundar/htmx` manifest imports core/schema concerns. This creates package-boundary drift before public publication.

## Deliverables

- Compare current manifests and imports with ADR-0013, package READMEs, and generated API docs.
- Decide whether `@bundar/forms` owns form parsing/validation/action orchestration; the recommended answer is yes.
- Define the acyclic allowed graph and compatibility policy for pre-1.0 moves.
- Record rejected alternatives: accept the coupling, move everything into core, or split every tiny helper.

## Out of scope

- Implementing the package moves
- Adding unrelated packages

## Acceptance criteria

- [ ] The ADR has an explicit allowed dependency matrix for every public package.
- [ ] `@bundar/htmx` protocol ownership and permitted dependencies are unambiguous.
- [ ] The ADR states where `runFormAction`, form result types, schema integration, and HTMX response composition live.
- [ ] All downstream tasks can identify their target package without another design decision.

## Agent context contract

### Read set

- `decisions/0017-post-alpha-package-boundaries.md`
- `architecture/package-dependency-graph.md`
- `packages/*/package.json`

### Write set

- `decisions/0017-post-alpha-package-boundaries.md`
- `architecture/package-dependency-graph.md`
- `packages/*/package.json`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `decisions/0017-post-alpha-package-boundaries.md`
- `architecture/package-dependency-graph.md`
- `packages/*/package.json`

## Verification

```bash
bun run architecture:check
bun pm ls --all
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](../m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-012 — Enforce the package dependency graph in CI](br-012-enforce-the-package-dependency-graph-in-ci.md)
- [BR-013 — Create the `@bundar/forms` package skeleton](br-013-create-the-bundar-forms-package-skeleton.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-011
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
