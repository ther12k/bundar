---
type: GitHub Issue Specification
title: BR-015 — Move progressive form orchestration into `@bundar/forms`
description: '`runFormAction` and its neutral workflow execute from `@bundar/forms`,
  while response dialect details remain injected through a small adapter contract.'
tags:
- github-issue
- bundar
- forms
- refactor
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-015
  milestone: M8.1 — Package-boundary reset
  priority: P0
  size: M
  labels:
  - priority:p0
  - size:m
  - area:forms
  - type:refactor
  - status:proposed
  depends_on:
  - BR-014
  blocks:
  - BR-016
  - BR-017
  - BR-029
  - BR-034
  - BR-040
  - BR-052
  - BR-055
  - BR-058
  - BR-066
  - BR-067
  - BR-071
  agent_ready: true
---

# BR-015 — Move progressive form orchestration into `@bundar/forms`

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P0`  
**Size:** `M`  
**Area:** `forms`  
**Type:** `refactor`

## Outcome

`runFormAction` and its neutral workflow execute from `@bundar/forms`, while response dialect details remain injected through a small adapter contract.

## Why this task exists

Current form orchestration couples parsing, Standard Schema, core responses, and HTMX behavior. This is the central package-boundary repair.

## Deliverables

- Move bounded parse/validate/retain/transaction/action sequencing into the forms package.
- Accept small injected ports for request parsing, representation choice, response construction, and optional schema validation.
- Preserve ordinary PRG, enhanced fragment response, 422 rerender, transaction rollback, and CSRF retry behavior.
- Keep application business validation single-path and independent from HTMX headers.

## Out of scope

- Adding application-specific validation messages
- Changing CSRF algorithms

## Acceptance criteria

- [ ] Existing Todo/minimal form-action behavior passes unchanged at the HTTP boundary.
- [ ] `@bundar/forms` has no import of versioned HTMX adapters or raw `HX-*` names.
- [ ] The workflow can be tested with a fake response adapter and without Bun server startup.
- [ ] Error and transaction semantics are covered for parse, validation, mutation, render, and response failures.

## Agent context contract

### Read set

- `packages/forms/src/**`
- `packages/forms/test/**`
- `packages/htmx/src/**`
- `packages/core/src/forms/**`

### Write set

- `packages/forms/src/**`
- `packages/forms/test/**`
- `packages/htmx/src/**`
- `packages/core/src/forms/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/forms/src/**`
- `packages/forms/test/**`
- `packages/htmx/src/**`
- `packages/core/src/forms/**`

## Verification

```bash
bun test packages/forms/**
bun test packages/htmx/**
bun run test:template
bun run test:example -- todo:no-js
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-014 — Extract framework-neutral form action contracts](br-014-extract-framework-neutral-form-action-contracts.md)

## Blocks

- [BR-016 — Isolate Standard Schema integration behind a forms adapter](br-016-isolate-standard-schema-integration-behind-a-forms-adapter.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](br-017-make-bundar-htmx-protocol-pure.md)
- [BR-029 — Extract the minimal starter action and service boundary](../m8-2-agent-architecture/br-029-extract-the-minimal-starter-action-and-service-boundary.md)
- [BR-034 — Extract Todo schemas and application actions](../m8-2-agent-architecture/br-034-extract-todo-schemas-and-application-actions.md)
- [BR-040 — Extract Admin validation, authorization, and application actions](../m8-2-agent-architecture/br-040-extract-admin-validation-authorization-and-application-actions.md)
- [BR-052 — Add a typed primary-fragment and update-intent response API](../m8-3-agent-tooling/br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md)
- [BR-055 — Add CSRF form-field and session-token composition helpers](../m8-3-agent-tooling/br-055-add-csrf-form-field-and-session-token-composition-helpers.md)
- [BR-058 — Propagate request cancellation through context, forms, and streams](../m8-4-production-security/br-058-propagate-request-cancellation-through-context-forms-and-streams.md)
- [BR-066 — Enforce multipart and form request-complexity limits](../m8-4-production-security/br-066-enforce-multipart-and-form-request-complexity-limits.md)
- [BR-067 — Define stable framework error codes and redaction policy](../m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md)
- [BR-071 — Close body single-consumption and content-type conformance](../m8-5-conformance-performance/br-071-close-body-single-consumption-and-content-type-conformance.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-015
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
