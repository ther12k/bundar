---
type: GitHub Issue Specification
title: BR-012 — Enforce the package dependency graph in CI
description: CI rejects both manifest-level and source-level imports that violate
  the package graph chosen in BR-011.
tags:
- github-issue
- bundar
- architecture
- test
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-012
  milestone: M8.1 — Package-boundary reset
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:architecture
  - type:test
  - status:proposed
  depends_on:
  - BR-011
  blocks:
  - BR-017
  agent_ready: true
---

# BR-012 — Enforce the package dependency graph in CI

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `architecture`  
**Type:** `test`

## Outcome

CI rejects both manifest-level and source-level imports that violate the package graph chosen in BR-011.

## Why this task exists

Documentation-only boundaries have already drifted; enforcement must inspect actual package manifests and resolved imports.

## Deliverables

- Extend the architecture checker with allowed direct dependencies and forbidden import edges.
- Inspect source, tests, build config, generated files, and package subpath exports.
- Provide a narrow exception mechanism requiring an ADR reference and expiry/review note.

## Out of scope

- Linting application feature boundaries; that is BR-023

## Acceptance criteria

- [ ] A fixture that imports `@bundar/core` from a protocol-pure HTMX module fails.
- [ ] A manifest dependency without a source import is still reported.
- [ ] A source import hidden behind a relative cross-package path is reported.
- [ ] Diagnostics show source package, target package, file, rule, and remediation.

## Agent context contract

### Read set

- `tools/architecture/**`
- `architecture/package-dependency-graph.md`
- `package.json`

### Write set

- `tools/architecture/**`
- `architecture/package-dependency-graph.md`
- `package.json`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tools/architecture/**`
- `architecture/package-dependency-graph.md`
- `package.json`

## Verification

```bash
bun run architecture:check
bun test tools/architecture/**
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-011 — Decide and freeze the post-alpha package dependency graph](br-011-decide-and-freeze-the-post-alpha-package-dependency-graph.md)

## Blocks

- [BR-017 — Make `@bundar/htmx` protocol-pure](br-017-make-bundar-htmx-protocol-pure.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-012
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
