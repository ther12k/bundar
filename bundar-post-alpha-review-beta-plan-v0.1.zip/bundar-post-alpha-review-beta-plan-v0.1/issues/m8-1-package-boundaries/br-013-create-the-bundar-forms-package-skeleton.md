---
type: GitHub Issue Specification
title: BR-013 — Create the `@bundar/forms` package skeleton
description: A focused package exists for HTML form workflows without introducing
  runtime dependencies into core, JSX, or HTMX.
tags:
- github-issue
- bundar
- forms
- feature
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-013
  milestone: M8.1 — Package-boundary reset
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:forms
  - type:feature
  - status:proposed
  depends_on:
  - BR-011
  blocks:
  - BR-014
  agent_ready: true
---

# BR-013 — Create the `@bundar/forms` package skeleton

**Milestone:** M8.1 — Package-boundary reset  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `forms`  
**Type:** `feature`

## Outcome

A focused package exists for HTML form workflows without introducing runtime dependencies into core, JSX, or HTMX.

## Why this task exists

Progressive form behavior spans body parsing, validation, retained values, application actions, and normal/enhanced responses. Giving it a package boundary prevents protocol and HTTP kernels from absorbing all workflow logic.

## Deliverables

- Create source, test, build, package manifest, export map, README, and API-doc entry.
- Define permitted dependencies according to BR-011, including optional Standard Schema integration.
- Add package-boundary and packed-tarball fixtures.

## Out of scope

- Moving behavior before contracts are frozen
- Bundling a validator

## Acceptance criteria

- [ ] The package builds and typechecks independently.
- [ ] Its initial export map contains only intentional placeholders/contracts, not copied implementation.
- [ ] It can be omitted by an application that uses raw request handling.
- [ ] The package passes the architecture checker and clean consumer fixture.

## Agent context contract

### Read set

- `packages/forms/**`
- `package.json`
- `tsconfig.json`
- `tools/docs/api-reference.ts`

### Write set

- `packages/forms/**`
- `package.json`
- `tsconfig.json`
- `tools/docs/api-reference.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/forms/**`
- `package.json`
- `tsconfig.json`
- `tools/docs/api-reference.ts`

## Verification

```bash
bun run typecheck
bun test packages/forms
bun run build
bun run package:audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-011 — Decide and freeze the post-alpha package dependency graph](br-011-decide-and-freeze-the-post-alpha-package-dependency-graph.md)

## Blocks

- [BR-014 — Extract framework-neutral form action contracts](br-014-extract-framework-neutral-form-action-contracts.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-013
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
