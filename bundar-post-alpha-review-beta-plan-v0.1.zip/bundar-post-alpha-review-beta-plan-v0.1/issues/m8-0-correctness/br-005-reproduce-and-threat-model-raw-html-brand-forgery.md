---
type: GitHub Issue Specification
title: BR-005 — Reproduce and threat-model raw HTML brand forgery
description: Tests precisely establish whether a plain object can impersonate a trusted
  raw-HTML value and which application boundaries could make that security-relevant.
tags:
- github-issue
- bundar
- jsx
- security
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-005
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:jsx
  - type:security
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-006
  agent_ready: true
---

# BR-005 — Reproduce and threat-model raw HTML brand forgery

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `jsx`  
**Type:** `security`

## Outcome

Tests precisely establish whether a plain object can impersonate a trusted raw-HTML value and which application boundaries could make that security-relevant.

## Why this task exists

The original GH-031 acceptance criteria say raw values cannot be forged accidentally through plain object shape. Source inspection found a globally discoverable symbol-based brand; exploitability must be tested rather than assumed.

## Deliverables

- Locate the raw-value brand and document whether it uses `Symbol.for`, an exported symbol, structural fields, or another forgeable marker.
- Add tests for forged objects from same realm, JSON-like data, prototypes, spread/copy operations, and cross-module imports.
- Document realistic and unrealistic attack paths, including whether untrusted objects can reach JSX children.

## Out of scope

- Bundling an HTML sanitizer
- Claiming exploitation without a reachable application path

## Acceptance criteria

- [ ] A test demonstrates the current behavior before the implementation is changed.
- [ ] The threat model separates contract mismatch from proven remote vulnerability.
- [ ] Ordinary strings, objects, arrays, SVG payloads, comments, attributes, and RCDATA remain escaped.
- [ ] The chosen remediation requirements are explicit enough for BR-006.

## Agent context contract

### Read set

- `packages/jsx/src/raw.ts`
- `packages/jsx/test/security/raw-html-forgery.test.ts`
- `docs/security/raw-html.md`

### Write set

- `packages/jsx/src/raw.ts`
- `packages/jsx/test/security/raw-html-forgery.test.ts`
- `docs/security/raw-html.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/jsx/src/raw.ts`
- `packages/jsx/test/security/raw-html-forgery.test.ts`
- `docs/security/raw-html.md`

## Verification

```bash
bun test packages/jsx/test/security/raw-html-forgery.test.ts
bun run security:raw-html-audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-006 — Make the raw HTML trust marker non-accidentally forgeable](br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-005
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
