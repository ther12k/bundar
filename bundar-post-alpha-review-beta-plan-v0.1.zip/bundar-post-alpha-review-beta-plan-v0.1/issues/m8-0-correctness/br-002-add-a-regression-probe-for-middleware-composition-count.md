---
type: GitHub Issue Specification
title: BR-002 — Add a regression probe for middleware composition count
description: A focused test proves whether middleware chains are composed once during
  `app.compile()` or rebuilt for each request.
tags:
- github-issue
- bundar
- core
- test
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-002
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:core
  - type:test
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-003
  agent_ready: true
---

# BR-002 — Add a regression probe for middleware composition count

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `core`  
**Type:** `test`

## Outcome

A focused test proves whether middleware chains are composed once during `app.compile()` or rebuilt for each request.

## Why this task exists

The original GH-018 contract requires startup composition. Source inspection indicates composition may currently occur inside generated request handlers; reproduce the behavior before changing implementation.

## Deliverables

- Instrument the middleware composer with an injectable counter or test seam.
- Compile one route, execute it repeatedly, and assert the composer invocation count independently from middleware execution count.
- Cover global, group, module, and route-local middleware in sync and async forms.

## Out of scope

- Optimizing context allocation
- Changing public middleware ordering

## Acceptance criteria

- [ ] The regression test fails against any implementation that composes a chain once per request.
- [ ] The test distinguishes composition count from normal middleware invocation count.
- [ ] Static-response routes remain outside unnecessary middleware work when no middleware applies.
- [ ] No benchmark threshold is used as a substitute for the semantic assertion.

## Agent context contract

### Read set

- `packages/core/src/middleware.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/middleware/composition-count.test.ts`

### Write set

- `packages/core/src/middleware.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/middleware/composition-count.test.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/middleware.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/middleware/composition-count.test.ts`

## Verification

```bash
bun test packages/core/test/middleware/composition-count.test.ts
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-003 — Move middleware composition fully into the compile phase](br-003-move-middleware-composition-fully-into-the-compile-phase.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-002
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
