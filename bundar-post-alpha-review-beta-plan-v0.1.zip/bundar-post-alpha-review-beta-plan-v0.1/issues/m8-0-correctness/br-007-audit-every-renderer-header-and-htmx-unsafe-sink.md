---
type: GitHub Issue Specification
title: BR-007 — Audit every renderer, header, and HTMX unsafe sink
description: A machine-checked inventory covers every intentional escape hatch and
  every place untrusted data can enter HTML, HTTP headers, redirects, event payloads,
  or HTMX directives.
tags:
- github-issue
- bundar
- security
- audit
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-007
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:security
  - type:audit
  - status:proposed
  depends_on:
  - BR-006
  blocks:
  - BR-054
  - BR-064
  - BR-065
  agent_ready: true
---

# BR-007 — Audit every renderer, header, and HTMX unsafe sink

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `security`  
**Type:** `audit`

## Outcome

A machine-checked inventory covers every intentional escape hatch and every place untrusted data can enter HTML, HTTP headers, redirects, event payloads, or HTMX directives.

## Why this task exists

Fixing one raw brand is insufficient if another path can bypass escaping or inject protocol values.

## Deliverables

- Inventory HTML text, attributes, style/class serialization, RCDATA, comments, raw values, OOB serialization, event JSON, redirects, header helpers, and response cloning.
- Assign a sanitizer/validator/encoder or explicit trusted-input contract to each sink.
- Add source scanning that fails on new unregistered unsafe sinks or direct raw protocol/header writes outside approved packages.

## Out of scope

- Application-specific HTML sanitization policies

## Acceptance criteria

- [ ] The sink inventory includes owner, input type, encoding/validation, tests, and residual risk.
- [ ] The audit command fails on an intentionally introduced direct `HX-*` header write outside the adapter boundary.
- [ ] The audit command fails on an unregistered raw-render bypass.
- [ ] All findings are either fixed or linked to a follow-up issue with severity and owner.

## Agent context contract

### Read set

- `tools/security/**`
- `docs/security/sink-inventory.md`
- `packages/jsx/**`
- `packages/htmx/**`
- `packages/core/**`

### Write set

- `tools/security/**`
- `docs/security/sink-inventory.md`
- `packages/jsx/**`
- `packages/htmx/**`
- `packages/core/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tools/security/**`
- `docs/security/sink-inventory.md`
- `packages/jsx/**`
- `packages/htmx/**`
- `packages/core/**`

## Verification

```bash
bun run security:raw-html-audit
bun run architecture:check
bun test packages/jsx/test/security/** packages/htmx/test/**
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-006 — Make the raw HTML trust marker non-accidentally forgeable](br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md)

## Blocks

- [BR-054 — Add safe response header and cookie mutation helpers](../m8-3-agent-tooling/br-054-add-safe-response-header-and-cookie-mutation-helpers.md)
- [BR-064 — Validate redirect targets and all HTMX response header values](../m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md)
- [BR-065 — Integrate CSP nonces with documents and `HtmxScript`](../m8-4-production-security/br-065-integrate-csp-nonces-with-documents-and-htmxscript.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-007
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
