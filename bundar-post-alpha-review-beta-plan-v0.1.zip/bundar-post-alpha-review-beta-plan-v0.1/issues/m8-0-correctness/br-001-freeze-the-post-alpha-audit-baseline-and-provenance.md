---
type: GitHub Issue Specification
title: BR-001 — Freeze the post-alpha audit baseline and provenance
description: Every finding and follow-on issue is anchored to one immutable Bundar
  revision and clearly distinguishes fresh verification from committed project evidence.
tags:
- github-issue
- bundar
- docs
- audit
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-001
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P0
  size: XS
  labels:
  - priority:p0
  - size:xs
  - area:docs
  - type:audit
  - status:proposed
  depends_on: []
  blocks:
  - BR-002
  - BR-005
  - BR-008
  - BR-010
  - BR-011
  - BR-021
  - BR-046
  - BR-059
  - BR-061
  agent_ready: true
---

# BR-001 — Freeze the post-alpha audit baseline and provenance

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P0`  
**Size:** `XS`  
**Area:** `docs`  
**Type:** `audit`

## Outcome

Every finding and follow-on issue is anchored to one immutable Bundar revision and clearly distinguishes fresh verification from committed project evidence.

## Why this task exists

The review baseline is `f8bdd8641865be3563746e892ab86fba702ee3e8` (`f8bdd86`), the main revision audited on 2026-08-22/23. The alpha gate is committed evidence; this review could not freshly clone and rerun the full Bun battery in its artifact environment.

## Deliverables

- Record repository URL, full commit SHA, review date/timezone, alpha tag, Bun baseline, stable htmx pin, and experimental htmx pin.
- Create a source ledger mapping each review claim to a file path, immutable URL, release artifact, or explicit inference.
- Mark findings as confirmed defect, contract mismatch, probable defect requiring reproduction, enhancement, human gate, or upstream-blocked.

## Out of scope

- Changing framework behavior
- Re-running unrelated historical milestones

## Acceptance criteria

- [ ] The baseline document contains the full commit SHA rather than only a branch name.
- [ ] Every P0/P1 finding in the register links to at least one evidence entry.
- [ ] Freshly executed checks and checks trusted from committed release evidence are visibly separated.
- [ ] The review contains no claim that htmx 4 GA exists.

## Agent context contract

### Read set

- `review/baseline.md`
- `review/source-ledger.md`
- `review/findings-register.md`

### Write set

- `review/baseline.md`
- `review/source-ledger.md`
- `review/findings-register.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `review/baseline.md`
- `review/source-ledger.md`
- `review/findings-register.md`

## Verification

```bash
git rev-parse HEAD
bun --version
bun run preflight
bun run ci:release
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- None. This issue may start after the audit baseline is accepted where applicable.

## Blocks

- [BR-002 — Add a regression probe for middleware composition count](br-002-add-a-regression-probe-for-middleware-composition-count.md)
- [BR-005 — Reproduce and threat-model raw HTML brand forgery](br-005-reproduce-and-threat-model-raw-html-brand-forgery.md)
- [BR-008 — Replace the stale design-bundle root README](br-008-replace-the-stale-design-bundle-root-readme.md)
- [BR-010 — Reconcile stale milestone and release claims across the corpus](br-010-reconcile-stale-milestone-and-release-claims-across-the-corpus.md)
- [BR-011 — Decide and freeze the post-alpha package dependency graph](../m8-1-package-boundaries/br-011-decide-and-freeze-the-post-alpha-package-dependency-graph.md)
- [BR-021 — Adopt a feature-sliced application structure for agent-friendly Bundar apps](../m8-2-agent-architecture/br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md)
- [BR-046 — Standardize deterministic machine-readable CLI behavior](../m8-3-agent-tooling/br-046-standardize-deterministic-machine-readable-cli-behavior.md)
- [BR-059 — Define the trusted proxy, client IP, scheme, host, and origin model](../m8-4-production-security/br-059-define-the-trusted-proxy-client-ip-scheme-host-and-origin-model.md)
- [BR-061 — Define durable session-store capabilities and failure semantics](../m8-4-production-security/br-061-define-durable-session-store-capabilities-and-failure-semantics.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-001
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
