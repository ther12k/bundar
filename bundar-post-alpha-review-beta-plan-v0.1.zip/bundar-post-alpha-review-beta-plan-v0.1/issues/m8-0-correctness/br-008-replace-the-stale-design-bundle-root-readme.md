---
type: GitHub Issue Specification
title: BR-008 — Replace the stale design-bundle root README
description: The repository landing page describes the implemented alpha honestly
  and no longer says Bundar is only a design archive.
tags:
- github-issue
- bundar
- docs
- docs
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-008
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P0
  size: XS
  labels:
  - priority:p0
  - size:xs
  - area:docs
  - type:docs
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-009
  agent_ready: true
---

# BR-008 — Replace the stale design-bundle root README

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P0`  
**Size:** `XS`  
**Area:** `docs`  
**Type:** `docs`

## Outcome

The repository landing page describes the implemented alpha honestly and no longer says Bundar is only a design archive.

## Why this task exists

At baseline `f8bdd86`, the root README still says the archive is not an implementation, while the repository records M0–M6 and a GitHub alpha release. A reviewed replacement and patch already exist.

## Deliverables

- Apply the reviewed implementation README or an equivalent current revision.
- Preserve required OKF frontmatter and valid repository-relative links.
- State the GitHub alpha, npm non-publication, htmx 2 stable pin, htmx 4 beta status, and source-build workflow accurately.

## Out of scope

- Changing framework APIs
- Publishing packages

## Acceptance criteria

- [ ] The README contains no claim that Bundar is merely a design archive.
- [ ] It does not advertise an npm installation command before packages are actually published.
- [ ] All relative links and code fences validate.
- [ ] Release, compatibility, and package status match source-of-truth records.

## Agent context contract

### Read set

- `README.md`

### Write set

- `README.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `README.md`

## Verification

```bash
bun run docs:validate
bun run docs:links
bun run docs:check
git diff --check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-009 — Generate README status facts and fail on drift](br-009-generate-readme-status-facts-and-fail-on-drift.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-008
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
