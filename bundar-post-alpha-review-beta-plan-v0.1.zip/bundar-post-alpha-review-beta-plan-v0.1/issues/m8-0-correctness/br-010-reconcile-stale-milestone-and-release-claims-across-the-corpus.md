---
type: GitHub Issue Specification
title: BR-010 — Reconcile stale milestone and release claims across the corpus
description: Every active document distinguishes planned, implemented, released, deferred,
  and externally blocked work consistently.
tags:
- github-issue
- bundar
- docs
- audit
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-010
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:docs
  - type:audit
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-085
  agent_ready: true
---

# BR-010 — Reconcile stale milestone and release claims across the corpus

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `docs`  
**Type:** `audit`

## Outcome

Every active document distinguishes planned, implemented, released, deferred, and externally blocked work consistently.

## Why this task exists

The root README is the most visible drift, but old design and issue documents can also be mistaken for current operational status.

## Deliverables

- Search for stale phrases such as `not an implementation`, `M1 planned`, `M6 planned`, and htmx 4 GA wording.
- Add an authoritative status pointer to historical design documents without rewriting immutable evidence.
- Mark generated/planned issue specifications as historical where appropriate.

## Out of scope

- Deleting historical issue evidence

## Acceptance criteria

- [ ] No current landing or getting-started document contradicts the alpha gate.
- [ ] Historical records remain intact and clearly labeled as historical/planned evidence.
- [ ] Externally blocked M7 work is never presented as completed.
- [ ] The status audit is repeatable through one repository command.

## Agent context contract

### Read set

- `tools/docs/claims-check.ts`
- `README.md`
- `docs/**`
- `delivery/**`
- `project/**`
- `architecture/**`

### Write set

- `tools/docs/claims-check.ts`
- `README.md`
- `docs/**`
- `delivery/**`
- `project/**`
- `architecture/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tools/docs/claims-check.ts`
- `README.md`
- `docs/**`
- `delivery/**`
- `project/**`
- `architecture/**`

## Verification

```bash
rg -n 'not an implementation|M[0-7].*(planned|active)|htmx 4.*GA' .
bun run docs:claims-check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-010
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
