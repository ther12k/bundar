---
type: GitHub Issue Specification
title: BR-004 — Guard middleware hot-path allocations with a release budget
description: A reproducible benchmark catches regressions that reintroduce per-request
  middleware composition or avoidable framework allocations.
tags:
- github-issue
- bundar
- performance
- benchmark
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-004
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:performance
  - type:benchmark
  - status:proposed
  depends_on:
  - BR-003
  blocks:
  - BR-076
  - BR-085
  agent_ready: true
---

# BR-004 — Guard middleware hot-path allocations with a release budget

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `performance`  
**Type:** `benchmark`

## Outcome

A reproducible benchmark catches regressions that reintroduce per-request middleware composition or avoidable framework allocations.

## Why this task exists

The semantic fix in BR-003 should be protected by measured evidence, but Bundar should make no cross-framework leadership claim.

## Deliverables

- Add raw Bun, no-middleware Bundar, one-sync-middleware, and one-async-middleware scenarios.
- Record throughput, p50/p95/p99 latency, memory, and environment metadata.
- Define ratio-based regression budgets relative to the same-run raw Bun/Bundar baseline.

## Out of scope

- Micro-optimizing application middleware bodies

## Acceptance criteria

- [ ] Benchmark results include warmup, sample count, Bun version, OS, CPU, and command.
- [ ] The budget catches a deliberately reintroduced per-request composer call.
- [ ] Thresholds are ratio-based or variance-aware rather than copied from one machine.
- [ ] Documentation explicitly avoids claiming Bundar is universally faster than another framework.

## Agent context contract

### Read set

- `benchmarks/**`
- `artifacts/bench/**`
- `docs/performance/**`

### Write set

- `benchmarks/**`
- `artifacts/bench/**`
- `docs/performance/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `benchmarks/**`
- `artifacts/bench/**`
- `docs/performance/**`

## Verification

```bash
bun run bench -- middleware-sync
bun run bench -- middleware-async
bun run bench:regression
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-003 — Move middleware composition fully into the compile phase](br-003-move-middleware-composition-fully-into-the-compile-phase.md)

## Blocks

- [BR-076 — Add Carno.js as a fair backend-framework benchmark reference](../m8-5-conformance-performance/br-076-add-carno-js-as-a-fair-backend-framework-benchmark-reference.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-004
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
