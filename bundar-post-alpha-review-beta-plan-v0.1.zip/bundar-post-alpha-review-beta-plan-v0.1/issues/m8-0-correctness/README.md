---
type: Milestone Issue Index
title: M8.0 — Post-alpha correctness and claim closure
description: Close factual/contract drift before expanding beta scope.
tags:
- bundar
- issues
- milestone
- m8-0-correctness
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# M8.0 — Post-alpha correctness and claim closure

## Goal

Close factual/contract drift before expanding beta scope.

## Exit conditions

- [ ] Audit baseline accepted
- [ ] Middleware and raw trust findings resolved or disproven
- [ ] README/status claims current and guarded

| ID | Priority | Size | Area | Task | Depends on |
| --- | --- | --- | --- | --- | --- |
| [BR-001](br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md) | P0 | XS | docs | Freeze the post-alpha audit baseline and provenance | — |
| [BR-002](br-002-add-a-regression-probe-for-middleware-composition-count.md) | P0 | S | core | Add a regression probe for middleware composition count | BR-001 |
| [BR-003](br-003-move-middleware-composition-fully-into-the-compile-phase.md) | P0 | M | core | Move middleware composition fully into the compile phase | BR-002 |
| [BR-004](br-004-guard-middleware-hot-path-allocations-with-a-release-budget.md) | P1 | S | performance | Guard middleware hot-path allocations with a release budget | BR-003 |
| [BR-005](br-005-reproduce-and-threat-model-raw-html-brand-forgery.md) | P0 | S | jsx | Reproduce and threat-model raw HTML brand forgery | BR-001 |
| [BR-006](br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md) | P0 | M | jsx | Make the raw HTML trust marker non-accidentally forgeable | BR-005 |
| [BR-007](br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md) | P1 | M | security | Audit every renderer, header, and HTMX unsafe sink | BR-006 |
| [BR-008](br-008-replace-the-stale-design-bundle-root-readme.md) | P0 | XS | docs | Replace the stale design-bundle root README | BR-001 |
| [BR-009](br-009-generate-readme-status-facts-and-fail-on-drift.md) | P1 | S | docs | Generate README status facts and fail on drift | BR-008 |
| [BR-010](br-010-reconcile-stale-milestone-and-release-claims-across-the-corpus.md) | P1 | S | docs | Reconcile stale milestone and release claims across the corpus | BR-001 |

## Gate

All issues must satisfy [`../../delivery/DEFINITION_OF_DONE.md`](../../delivery/DEFINITION_OF_DONE.md). The milestone is not closed solely because all code issues were merged; run and record its integrated gate.
