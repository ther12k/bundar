---
type: GitHub Issue Specification
title: BR-009 — Generate README status facts and fail on drift
description: Fast-changing release, package, dialect, and milestone facts in the README
  are checked against machine-readable source-of-truth files.
tags:
- github-issue
- bundar
- docs
- tooling
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-009
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:docs
  - type:tooling
  - status:proposed
  depends_on:
  - BR-008
  blocks:
  - BR-085
  agent_ready: true
---

# BR-009 — Generate README status facts and fail on drift

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `docs`  
**Type:** `tooling`

## Outcome

Fast-changing release, package, dialect, and milestone facts in the README are checked against machine-readable source-of-truth files.

## Why this task exists

The README became stale within one implementation cycle. Manually duplicated status data should not be trusted.

## Deliverables

- Choose machine-readable sources for package versions/privacy, release tag, dialect pins/maturity, milestone state, and registry publication.
- Add a docs check that compares rendered README facts with those sources.
- Prefer generated markers or small verified snippets over regenerating the entire narrative README.

## Out of scope

- Generating marketing copy
- Depending on live GitHub or npm network access in normal CI

## Acceptance criteria

- [ ] Changing a dialect pin without updating the README causes a deterministic docs failure.
- [ ] Changing package privacy/publication status without updating install instructions causes a deterministic failure.
- [ ] The check produces actionable field-level diagnostics.
- [ ] Narrative sections remain hand-editable and are not overwritten unexpectedly.

## Agent context contract

### Read set

- `tools/docs/readme-status.ts`
- `README.md`
- `package.json`
- `packages/*/package.json`
- `docs/compatibility/**`
- `delivery/**`

### Write set

- `tools/docs/readme-status.ts`
- `README.md`
- `package.json`
- `packages/*/package.json`
- `docs/compatibility/**`
- `delivery/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tools/docs/readme-status.ts`
- `README.md`
- `package.json`
- `packages/*/package.json`
- `docs/compatibility/**`
- `delivery/**`

## Verification

```bash
bun run docs:status-check
bun run docs:check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-008 — Replace the stale design-bundle root README](br-008-replace-the-stale-design-bundle-root-readme.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-009
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
