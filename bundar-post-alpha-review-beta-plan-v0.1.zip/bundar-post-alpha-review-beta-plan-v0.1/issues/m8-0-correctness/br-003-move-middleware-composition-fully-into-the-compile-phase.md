---
type: GitHub Issue Specification
title: BR-003 — Move middleware composition fully into the compile phase
description: Each route receives a precomposed executable pipeline at compile time
  while preserving onion ordering, short-circuiting, and the synchronous fast path.
tags:
- github-issue
- bundar
- core
- bug
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-003
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P0
  size: M
  labels:
  - priority:p0
  - size:m
  - area:core
  - type:bug
  - status:proposed
  depends_on:
  - BR-002
  blocks:
  - BR-004
  - BR-054
  - BR-057
  - BR-067
  - BR-069
  - BR-070
  agent_ready: true
---

# BR-003 — Move middleware composition fully into the compile phase

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P0`  
**Size:** `M`  
**Area:** `core`  
**Type:** `bug`

## Outcome

Each route receives a precomposed executable pipeline at compile time while preserving onion ordering, short-circuiting, and the synchronous fast path.

## Why this task exists

GH-018 promises compile-once middleware. The reproduction from BR-002 is the acceptance oracle.

## Deliverables

- Compose applicable global, group, module, and route middleware while compiling route descriptors.
- Store the compiled sync/async route executor in the native Bun route table entry.
- Preserve double-next detection, short-circuit responses, error propagation, and route/module scope isolation.
- Avoid forcing a Promise allocation when the entire chain and handler are synchronous.

## Out of scope

- New lifecycle phases
- A general dependency-injection container

## Acceptance criteria

- [ ] BR-002 passes with one composition per compiled route, not per request.
- [ ] Existing middleware ordering and error tests remain green.
- [ ] Sync-only routes return synchronously unless application code returns a Promise.
- [ ] A compile-time route conflict or invalid middleware setup fails before `Bun.serve()` starts.

## Agent context contract

### Read set

- `packages/core/src/middleware.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/middleware/**`

### Write set

- `packages/core/src/middleware.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/middleware/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/middleware.ts`
- `packages/core/src/compiler.ts`
- `packages/core/test/middleware/**`

## Verification

```bash
bun test packages/core/test/middleware/**
bun run bench -- middleware-sync
bun run bench -- middleware-async
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-002 — Add a regression probe for middleware composition count](br-002-add-a-regression-probe-for-middleware-composition-count.md)

## Blocks

- [BR-004 — Guard middleware hot-path allocations with a release budget](br-004-guard-middleware-hot-path-allocations-with-a-release-budget.md)
- [BR-054 — Add safe response header and cookie mutation helpers](../m8-3-agent-tooling/br-054-add-safe-response-header-and-cookie-mutation-helpers.md)
- [BR-057 — Define startup, readiness, shutdown, and graceful-stop lifecycle](../m8-4-production-security/br-057-define-startup-readiness-shutdown-and-graceful-stop-lifecycle.md)
- [BR-067 — Define stable framework error codes and redaction policy](../m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md)
- [BR-069 — Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow](../m8-5-conformance-performance/br-069-close-http-method-conformance-for-head-options-405-and-allow.md)
- [BR-070 — Close route edge-case and collision conformance](../m8-5-conformance-performance/br-070-close-route-edge-case-and-collision-conformance.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-003
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
