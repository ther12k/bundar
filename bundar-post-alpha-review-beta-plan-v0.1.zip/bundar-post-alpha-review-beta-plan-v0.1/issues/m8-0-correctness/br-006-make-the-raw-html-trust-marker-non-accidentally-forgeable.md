---
type: GitHub Issue Specification
title: BR-006 — Make the raw HTML trust marker non-accidentally forgeable
description: Only values constructed by Bundar's explicit unsafe API bypass escaping,
  and the documentation states the exact trust guarantee without overclaiming.
tags:
- github-issue
- bundar
- jsx
- security
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-006
  milestone: M8.0 — Post-alpha correctness and claim closure
  priority: P0
  size: M
  labels:
  - priority:p0
  - size:m
  - area:jsx
  - type:security
  - status:proposed
  depends_on:
  - BR-005
  blocks:
  - BR-007
  - BR-068
  - BR-085
  agent_ready: true
---

# BR-006 — Make the raw HTML trust marker non-accidentally forgeable

**Milestone:** M8.0 — Post-alpha correctness and claim closure  
**Priority:** `P0`  
**Size:** `M`  
**Area:** `jsx`  
**Type:** `security`

## Outcome

Only values constructed by Bundar's explicit unsafe API bypass escaping, and the documentation states the exact trust guarantee without overclaiming.

## Why this task exists

BR-005 supplies the reproduction and threat model. A module-private unique symbol, private class identity, WeakSet membership, or equivalent opaque mechanism may be used after measuring compatibility and cost.

## Deliverables

- Choose and document an opaque brand implementation that cannot be recreated from a public string key or plain object shape.
- Keep `raw()`/`unsafeHtml()` explicit and auditable, with a small public surface.
- Preserve rendering and streaming behavior for legitimate trusted values.
- Update the raw-callsite audit tool and security documentation.

## Out of scope

- Adding a sanitizer
- Supporting React `dangerouslySetInnerHTML` compatibility

## Acceptance criteria

- [ ] All forgery tests from BR-005 fail closed.
- [ ] Legitimate raw values render identically in string and stream renderers.
- [ ] The public type does not expose the runtime marker needed to forge trust.
- [ ] Documentation says Bundar does not sanitize trusted HTML and assigns sanitization responsibility to the caller.

## Agent context contract

### Read set

- `packages/jsx/src/raw.ts`
- `packages/jsx/src/render-to-string.ts`
- `packages/jsx/src/render-to-stream.ts`
- `packages/jsx/test/security/**`
- `docs/security/raw-html.md`

### Write set

- `packages/jsx/src/raw.ts`
- `packages/jsx/src/render-to-string.ts`
- `packages/jsx/src/render-to-stream.ts`
- `packages/jsx/test/security/**`
- `docs/security/raw-html.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/jsx/src/raw.ts`
- `packages/jsx/src/render-to-string.ts`
- `packages/jsx/src/render-to-stream.ts`
- `packages/jsx/test/security/**`
- `docs/security/raw-html.md`

## Verification

```bash
bun test packages/jsx/test/security/**
bun run security:raw-html-audit
bun run ci:m2
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-005 — Reproduce and threat-model raw HTML brand forgery](br-005-reproduce-and-threat-model-raw-html-brand-forgery.md)

## Blocks

- [BR-007 — Audit every renderer, header, and HTMX unsafe sink](br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md)
- [BR-068 — Add property and fuzz tests for high-risk parsers and serializers](../m8-4-production-security/br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-006
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
