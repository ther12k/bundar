---
type: GitHub Issue Specification
title: BR-068 — Add property and fuzz tests for high-risk parsers and serializers
description: Randomized and generative tests exercise escaping, attributes, route
  params, headers, redirects, forms, multipart boundaries, cookies, and update serialization
  beyond hand-picked cases.
tags:
- github-issue
- bundar
- security
- test
- p2
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-068
  milestone: M8.4 — Production and security hardening
  priority: P2
  size: M
  labels:
  - priority:p2
  - size:m
  - area:security
  - type:test
  - status:proposed
  depends_on:
  - BR-006
  - BR-064
  - BR-066
  - BR-067
  blocks:
  - BR-085
  agent_ready: true
---

# BR-068 — Add property and fuzz tests for high-risk parsers and serializers

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P2`  
**Size:** `M`  
**Area:** `security`  
**Type:** `test`

## Outcome

Randomized and generative tests exercise escaping, attributes, route params, headers, redirects, forms, multipart boundaries, cookies, and update serialization beyond hand-picked cases.

## Why this task exists

The highest-risk surfaces process attacker-controlled strings and benefit from invariants that example tests miss.

## Deliverables

- Choose deterministic seeded property testing with replayable failing cases.
- Define invariants for no control-character headers, escape round trips, no raw bypass, parser limits, route normalization, cookie serialization, and dialect output validity.
- Persist minimized regression corpus entries for every discovered failure.

## Out of scope

- Claiming formal verification
- Unbounded CI fuzzing

## Acceptance criteria

- [ ] Tests are deterministic in CI and print the seed/case on failure.
- [ ] Fuzz budgets are bounded for normal CI with a longer scheduled lane.
- [ ] At least one intentionally seeded defect is detected by each major invariant family.
- [ ] No fuzz input or failure output leaks environment secrets.

## Agent context contract

### Read set

- `tests/property/**`
- `tests/fuzz/**`
- `artifacts/fuzz/corpus/**`
- `package.json`

### Write set

- `tests/property/**`
- `tests/fuzz/**`
- `artifacts/fuzz/corpus/**`
- `package.json`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `tests/property/**`
- `tests/fuzz/**`
- `artifacts/fuzz/corpus/**`
- `package.json`

## Verification

```bash
bun run test:property
bun run test:fuzz:smoke
bun run test:fuzz:scheduled
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-006 — Make the raw HTML trust marker non-accidentally forgeable](../m8-0-correctness/br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md)
- [BR-064 — Validate redirect targets and all HTMX response header values](br-064-validate-redirect-targets-and-all-htmx-response-header-values.md)
- [BR-066 — Enforce multipart and form request-complexity limits](br-066-enforce-multipart-and-form-request-complexity-limits.md)
- [BR-067 — Define stable framework error codes and redaction policy](br-067-define-stable-framework-error-codes-and-redaction-policy.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-068
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
