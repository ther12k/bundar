---
type: GitHub Issue Specification
title: BR-058 — Propagate request cancellation through context, forms, and streams
description: Client disconnects, request budgets, and graceful shutdown expose one
  abort signal that application actions and render streams can observe.
tags:
- github-issue
- bundar
- core
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-058
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:core
  - type:feature
  - status:proposed
  depends_on:
  - BR-057
  - BR-015
  blocks:
  - BR-072
  agent_ready: true
---

# BR-058 — Propagate request cancellation through context, forms, and streams

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `core`  
**Type:** `feature`

## Outcome

Client disconnects, request budgets, and graceful shutdown expose one abort signal that application actions and render streams can observe.

## Why this task exists

Abort handling was planned in the original design, but beta readiness requires cross-package proof rather than isolated timeout helpers.

## Deliverables

- Define the authoritative signal on Context and how it composes client disconnect, timeout, and shutdown sources.
- Pass it through body parsing, form orchestration, actions, session/storage adapters where supported, async JSX, and streams.
- Specify cleanup and error classification for aborted operations.

## Out of scope

- Database-driver-specific cancellation implementations

## Acceptance criteria

- [ ] Disconnecting a streaming client cancels pending async rendering and resource work.
- [ ] A request budget abort does not become a generic 500 or leak stack details.
- [ ] Action code can consume the signal without importing Bun internals.
- [ ] No continuation writes to a closed response after abort.

## Agent context contract

### Read set

- `packages/core/src/context.ts`
- `packages/core/src/request-budget.ts`
- `packages/forms/src/**`
- `packages/jsx/src/render-to-stream.ts`
- `packages/core/test/abort/**`

### Write set

- `packages/core/src/context.ts`
- `packages/core/src/request-budget.ts`
- `packages/forms/src/**`
- `packages/jsx/src/render-to-stream.ts`
- `packages/core/test/abort/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/context.ts`
- `packages/core/src/request-budget.ts`
- `packages/forms/src/**`
- `packages/jsx/src/render-to-stream.ts`
- `packages/core/test/abort/**`

## Verification

```bash
bun test packages/core/test/abort/** packages/jsx/test/streaming/** packages/forms/test/abort/**
bun run test:integration:abort
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-057 — Define startup, readiness, shutdown, and graceful-stop lifecycle](br-057-define-startup-readiness-shutdown-and-graceful-stop-lifecycle.md)
- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)

## Blocks

- [BR-072 — Close streaming backpressure, cancellation, and late-error conformance](../m8-5-conformance-performance/br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-058
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
