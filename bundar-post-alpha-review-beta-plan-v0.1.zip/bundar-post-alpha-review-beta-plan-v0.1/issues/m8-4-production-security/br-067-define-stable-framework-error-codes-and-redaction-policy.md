---
type: GitHub Issue Specification
title: BR-067 — Define stable framework error codes and redaction policy
description: Framework failures have stable machine-readable codes, safe public messages,
  traceable internal causes, and page/fragment negotiation without leaking secrets
  or source details.
tags:
- github-issue
- bundar
- core
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-067
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:core
  - type:feature
  - status:proposed
  depends_on:
  - BR-003
  - BR-015
  - BR-017
  blocks:
  - BR-068
  - BR-069
  - BR-070
  - BR-071
  - BR-072
  - BR-085
  agent_ready: true
---

# BR-067 — Define stable framework error codes and redaction policy

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `core`  
**Type:** `feature`

## Outcome

Framework failures have stable machine-readable codes, safe public messages, traceable internal causes, and page/fragment negotiation without leaking secrets or source details.

## Why this task exists

Agents, tests, and operators need durable error identities; ad hoc messages are hard to automate and easy to overexpose.

## Deliverables

- Inventory compile, route, body, validation, security, session, HTMX, rendering, and lifecycle errors.
- Define public code/status/message/details policy and internal cause/log fields.
- Render appropriate full-page, fragment, and non-HTML responses through one error boundary.
- Document production versus development diagnostics.

## Out of scope

- Adopting RFC 9457 for all HTML responses unless separately decided

## Acceptance criteria

- [ ] Every framework-originated 4xx/5xx path maps to a documented code.
- [ ] Production responses omit stack traces, filesystem paths, secrets, rejected sensitive values, and internal causes.
- [ ] Logs correlate to a request/error ID without changing response cache semantics.
- [ ] Error codes are covered by snapshot/compatibility tests and change policy.

## Agent context contract

### Read set

- `packages/core/src/errors.ts`
- `packages/forms/src/errors.ts`
- `packages/htmx/src/errors.ts`
- `docs/reference/error-codes.md`
- `packages/core/test/errors/**`

### Write set

- `packages/core/src/errors.ts`
- `packages/forms/src/errors.ts`
- `packages/htmx/src/errors.ts`
- `docs/reference/error-codes.md`
- `packages/core/test/errors/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/errors.ts`
- `packages/forms/src/errors.ts`
- `packages/htmx/src/errors.ts`
- `docs/reference/error-codes.md`
- `packages/core/test/errors/**`

## Verification

```bash
bun test packages/core/test/errors/** packages/forms/test/errors/** packages/htmx/test/errors/**
bun run security:redaction-audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-003 — Move middleware composition fully into the compile phase](../m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md)
- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-068 — Add property and fuzz tests for high-risk parsers and serializers](br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md)
- [BR-069 — Close HTTP method conformance for HEAD, OPTIONS, 405, and Allow](../m8-5-conformance-performance/br-069-close-http-method-conformance-for-head-options-405-and-allow.md)
- [BR-070 — Close route edge-case and collision conformance](../m8-5-conformance-performance/br-070-close-route-edge-case-and-collision-conformance.md)
- [BR-071 — Close body single-consumption and content-type conformance](../m8-5-conformance-performance/br-071-close-body-single-consumption-and-content-type-conformance.md)
- [BR-072 — Close streaming backpressure, cancellation, and late-error conformance](../m8-5-conformance-performance/br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-067
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
