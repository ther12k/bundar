---
type: GitHub Issue Specification
title: BR-065 — Integrate CSP nonces with documents and `HtmxScript`
description: Bundar can render a per-response CSP nonce consistently into headers
  and approved script/style tags without encouraging `unsafe-inline`.
tags:
- github-issue
- bundar
- security
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-065
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:security
  - type:feature
  - status:proposed
  depends_on:
  - BR-007
  - BR-017
  blocks:
  - BR-075
  - BR-085
  agent_ready: true
---

# BR-065 — Integrate CSP nonces with documents and `HtmxScript`

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `security`  
**Type:** `feature`

## Outcome

Bundar can render a per-response CSP nonce consistently into headers and approved script/style tags without encouraging `unsafe-inline`.

## Why this task exists

HTMX asset loading and optional inline configuration need a coherent CSP path for production applications.

## Deliverables

- Define nonce generation/ownership and request-scoped propagation.
- Integrate security headers, document rendering, `HtmxScript`, and approved inline config/script helpers.
- Prevent nonce exposure through logs, error pages, cache reuse, or shared static markup.

## Out of scope

- A CSP policy generator for every application
- Allowing arbitrary inline scripts

## Acceptance criteria

- [ ] Each eligible response receives a fresh cryptographically strong nonce.
- [ ] Header and rendered nonce match exactly.
- [ ] Cached/shared fragments cannot reuse a nonce incorrectly.
- [ ] An inline script without the approved nonce is blocked in the browser conformance fixture.

## Agent context contract

### Read set

- `packages/security/src/csp.ts`
- `packages/jsx/src/document.ts`
- `packages/htmx/src/script.tsx`
- `packages/security/test/csp/**`

### Write set

- `packages/security/src/csp.ts`
- `packages/jsx/src/document.ts`
- `packages/htmx/src/script.tsx`
- `packages/security/test/csp/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/security/src/csp.ts`
- `packages/jsx/src/document.ts`
- `packages/htmx/src/script.tsx`
- `packages/security/test/csp/**`

## Verification

```bash
bun test packages/security/test/csp/** packages/htmx/test/script-csp.test.ts
bun run test:browser:csp
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-007 — Audit every renderer, header, and HTMX unsafe sink](../m8-0-correctness/br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-075 — Add no-JavaScript and accessibility baseline gates](../m8-5-conformance-performance/br-075-add-no-javascript-and-accessibility-baseline-gates.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-065
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
