---
type: GitHub Issue Specification
title: BR-059 — Define the trusted proxy, client IP, scheme, host, and origin model
description: Applications have a documented fail-closed model for direct deployments
  and explicitly trusted reverse proxies.
tags:
- github-issue
- bundar
- security
- adr
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-059
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:security
  - type:adr
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-060
  agent_ready: true
---

# BR-059 — Define the trusted proxy, client IP, scheme, host, and origin model

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `security`  
**Type:** `adr`

## Outcome

Applications have a documented fail-closed model for direct deployments and explicitly trusted reverse proxies.

## Why this task exists

Cookie security, absolute redirects, origin checks, audit logs, and rate limits are unsafe when forwarded headers are trusted implicitly or ignored unpredictably.

## Deliverables

- Define direct peer versus forwarded metadata, trusted proxy allowlists/hops, canonical scheme/host, and malformed/duplicate header behavior.
- Specify defaults for development and production.
- Document deployment examples for common reverse-proxy patterns without promising automatic platform detection.

## Out of scope

- Automatic cloud-provider discovery
- Rate limiting

## Acceptance criteria

- [ ] Forwarded headers are ignored by default.
- [ ] Trust configuration is explicit, bounded, and testable.
- [ ] Ambiguous multiple-hop values fail closed or follow one documented algorithm.
- [ ] Origin/host/cookie helpers consume one normalized request-origin contract.

## Agent context contract

### Read set

- `decisions/0019-trusted-proxy-model.md`
- `architecture/security.md`
- `docs/guides/deployment.md`
- `packages/security/test/proxy-contract.test.ts`

### Write set

- `decisions/0019-trusted-proxy-model.md`
- `architecture/security.md`
- `docs/guides/deployment.md`
- `packages/security/test/proxy-contract.test.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `decisions/0019-trusted-proxy-model.md`
- `architecture/security.md`
- `docs/guides/deployment.md`
- `packages/security/test/proxy-contract.test.ts`

## Verification

```bash
bun run docs:validate
bun test packages/security/test/proxy-contract.test.ts
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](../m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-060 — Implement secure-cookie behavior behind explicit trusted proxies](br-060-implement-secure-cookie-behavior-behind-explicit-trusted-proxies.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-059
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
