---
type: GitHub Issue Specification
title: BR-060 — Implement secure-cookie behavior behind explicit trusted proxies
description: Session and CSRF cookie helpers determine Secure/host policy from the
  normalized trusted request origin, never raw untrusted forwarded headers.
tags:
- github-issue
- bundar
- security
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-060
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:security
  - type:feature
  - status:proposed
  depends_on:
  - BR-059
  blocks:
  - BR-062
  agent_ready: true
---

# BR-060 — Implement secure-cookie behavior behind explicit trusted proxies

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `security`  
**Type:** `feature`

## Outcome

Session and CSRF cookie helpers determine Secure/host policy from the normalized trusted request origin, never raw untrusted forwarded headers.

## Why this task exists

Reference fixtures use `secure: false`; production deployments behind TLS termination need a correct, explicit policy.

## Deliverables

- Implement normalized scheme/host extraction from BR-059.
- Define secure defaults for `Secure`, `HttpOnly`, `SameSite`, Domain, Path, prefixes, and localhost development.
- Reject dangerous combinations such as `SameSite=None` without Secure or invalid `__Host-` attributes.

## Out of scope

- Certificate management
- Proxy server implementation

## Acceptance criteria

- [ ] A forged `X-Forwarded-Proto` from an untrusted peer cannot disable or enable policy.
- [ ] Trusted TLS termination produces Secure cookies.
- [ ] Production configuration cannot silently emit insecure session cookies.
- [ ] Cookie serialization and tests cover direct HTTP dev, direct HTTPS, trusted proxy, untrusted proxy, and malformed forwarded values.

## Agent context contract

### Read set

- `packages/security/src/cookies.ts`
- `packages/security/src/proxy.ts`
- `packages/security/test/cookies/**`
- `docs/guides/sessions.md`

### Write set

- `packages/security/src/cookies.ts`
- `packages/security/src/proxy.ts`
- `packages/security/test/cookies/**`
- `docs/guides/sessions.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/security/src/cookies.ts`
- `packages/security/src/proxy.ts`
- `packages/security/test/cookies/**`
- `docs/guides/sessions.md`

## Verification

```bash
bun test packages/security/test/cookies/**
bun run security:cookie-audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-059 — Define the trusted proxy, client IP, scheme, host, and origin model](br-059-define-the-trusted-proxy-client-ip-scheme-host-and-origin-model.md)

## Blocks

- [BR-062 — Fail closed on memory sessions or insecure cookies in production](br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-060
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
