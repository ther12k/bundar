---
type: GitHub Issue Specification
title: BR-062 — Fail closed on memory sessions or insecure cookies in production
description: Known fixture-only session and cookie settings cannot accidentally be
  used in production without an explicit, noisy, documented override.
tags:
- github-issue
- bundar
- security
- bug
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-062
  milestone: M8.4 — Production and security hardening
  priority: P0
  size: S
  labels:
  - priority:p0
  - size:s
  - area:security
  - type:bug
  - status:proposed
  depends_on:
  - BR-060
  - BR-061
  blocks:
  - BR-063
  - BR-085
  agent_ready: true
---

# BR-062 — Fail closed on memory sessions or insecure cookies in production

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P0`  
**Size:** `S`  
**Area:** `security`  
**Type:** `bug`

## Outcome

Known fixture-only session and cookie settings cannot accidentally be used in production without an explicit, noisy, documented override.

## Why this task exists

Reference apps correctly describe their stores as replaceable seams, but copied configuration should not silently become production posture.

## Deliverables

- Add environment/posture validation for memory stores, `secure: false`, weak/ephemeral secrets, and missing trusted-origin configuration.
- Choose which conditions are fatal and which require an explicit risk acknowledgement.
- Keep test/development ergonomics straightforward and deterministic.

## Out of scope

- Preventing users from writing custom stores
- Environment library

## Acceptance criteria

- [ ] Starting with `NODE_ENV=production` plus memory session store fails before listening by default.
- [ ] Starting with insecure session cookies in production fails before listening.
- [ ] Overrides name the exact risk, are machine-detectable, and are never enabled by reference templates.
- [ ] Diagnostics do not print secrets.

## Agent context contract

### Read set

- `packages/security/src/posture.ts`
- `packages/security/test/production-posture.test.ts`
- `templates/**`
- `examples/**`

### Write set

- `packages/security/src/posture.ts`
- `packages/security/test/production-posture.test.ts`
- `templates/**`
- `examples/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/security/src/posture.ts`
- `packages/security/test/production-posture.test.ts`
- `templates/**`
- `examples/**`

## Verification

```bash
bun test packages/security/test/production-posture.test.ts
bun run security:posture-audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-060 — Implement secure-cookie behavior behind explicit trusted proxies](br-060-implement-secure-cookie-behavior-behind-explicit-trusted-proxies.md)
- [BR-061 — Define durable session-store capabilities and failure semantics](br-061-define-durable-session-store-capabilities-and-failure-semantics.md)

## Blocks

- [BR-063 — Close session fixation, rotation, logout, and replay tests](br-063-close-session-fixation-rotation-logout-and-replay-tests.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-062
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
