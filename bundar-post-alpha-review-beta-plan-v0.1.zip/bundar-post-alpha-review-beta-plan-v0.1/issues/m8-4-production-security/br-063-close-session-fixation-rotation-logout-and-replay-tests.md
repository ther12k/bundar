---
type: GitHub Issue Specification
title: BR-063 — Close session fixation, rotation, logout, and replay tests
description: Session lifecycle security is proven under login/privilege change, invalidation,
  concurrent requests, flash use, CSRF binding, and stale-cookie replay.
tags:
- github-issue
- bundar
- security
- test
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-063
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:security
  - type:test
  - status:proposed
  depends_on:
  - BR-061
  - BR-062
  blocks:
  - BR-085
  agent_ready: true
---

# BR-063 — Close session fixation, rotation, logout, and replay tests

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `security`  
**Type:** `test`

## Outcome

Session lifecycle security is proven under login/privilege change, invalidation, concurrent requests, flash use, CSRF binding, and stale-cookie replay.

## Why this task exists

A session interface is not beta-ready without adversarial lifecycle tests.

## Deliverables

- Add tests for pre-auth ID rotation, privilege elevation, logout invalidation, stale token replay, concurrent rotation, expired sessions, flash one-time reads, and CSRF/session rebinding.
- Run the contract suite against memory and at least one test durable adapter or transactional fake.
- Define expected client cookie clearing on every invalid state.

## Out of scope

- Building login UI
- OAuth/OIDC

## Acceptance criteria

- [ ] An attacker-supplied pre-auth session ID is not retained after authentication/privilege change.
- [ ] A logged-out or rotated old cookie cannot access protected state.
- [ ] Concurrent rotation cannot leave two active privileged IDs unless explicitly designed and documented.
- [ ] Failure paths clear or retain cookies consistently without leaking session contents.

## Agent context contract

### Read set

- `packages/security/test/sessions/**`
- `packages/security/src/session/**`
- `docs/guides/sessions.md`

### Write set

- `packages/security/test/sessions/**`
- `packages/security/src/session/**`
- `docs/guides/sessions.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/security/test/sessions/**`
- `packages/security/src/session/**`
- `docs/guides/sessions.md`

## Verification

```bash
bun test packages/security/test/sessions/**
bun run security:session-audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-061 — Define durable session-store capabilities and failure semantics](br-061-define-durable-session-store-capabilities-and-failure-semantics.md)
- [BR-062 — Fail closed on memory sessions or insecure cookies in production](br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-063
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
