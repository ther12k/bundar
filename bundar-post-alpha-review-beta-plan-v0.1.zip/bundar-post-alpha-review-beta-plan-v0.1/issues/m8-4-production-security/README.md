---
type: Milestone Issue Index
title: M8.4 — Production and security hardening
description: Close fail-closed production and security contracts.
tags:
- bundar
- issues
- milestone
- m8-4-production-security
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# M8.4 — Production and security hardening

## Goal

Close fail-closed production and security contracts.

## Exit conditions

- [ ] Lifecycle/abort/proxy/session posture defined
- [ ] Header/CSP/body/error security gates pass
- [ ] Property/fuzz smoke evidence recorded

| ID | Priority | Size | Area | Task | Depends on |
| --- | --- | --- | --- | --- | --- |
| [BR-057](br-057-define-startup-readiness-shutdown-and-graceful-stop-lifecycle.md) | P1 | M | core | Define startup, readiness, shutdown, and graceful-stop lifecycle | BR-003 |
| [BR-058](br-058-propagate-request-cancellation-through-context-forms-and-streams.md) | P1 | M | core | Propagate request cancellation through context, forms, and streams | BR-057, BR-015 |
| [BR-059](br-059-define-the-trusted-proxy-client-ip-scheme-host-and-origin-model.md) | P1 | S | security | Define the trusted proxy, client IP, scheme, host, and origin model | BR-001 |
| [BR-060](br-060-implement-secure-cookie-behavior-behind-explicit-trusted-proxies.md) | P1 | M | security | Implement secure-cookie behavior behind explicit trusted proxies | BR-059 |
| [BR-061](br-061-define-durable-session-store-capabilities-and-failure-semantics.md) | P1 | S | security | Define durable session-store capabilities and failure semantics | BR-001 |
| [BR-062](br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md) | P0 | S | security | Fail closed on memory sessions or insecure cookies in production | BR-060, BR-061 |
| [BR-063](br-063-close-session-fixation-rotation-logout-and-replay-tests.md) | P1 | M | security | Close session fixation, rotation, logout, and replay tests | BR-061, BR-062 |
| [BR-064](br-064-validate-redirect-targets-and-all-htmx-response-header-values.md) | P0 | M | security | Validate redirect targets and all HTMX response header values | BR-007, BR-017 |
| [BR-065](br-065-integrate-csp-nonces-with-documents-and-htmxscript.md) | P1 | M | security | Integrate CSP nonces with documents and `HtmxScript` | BR-007, BR-017 |
| [BR-066](br-066-enforce-multipart-and-form-request-complexity-limits.md) | P1 | M | core | Enforce multipart and form request-complexity limits | BR-015 |
| [BR-067](br-067-define-stable-framework-error-codes-and-redaction-policy.md) | P1 | M | core | Define stable framework error codes and redaction policy | BR-003, BR-015, BR-017 |
| [BR-068](br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md) | P2 | M | security | Add property and fuzz tests for high-risk parsers and serializers | BR-006, BR-064, BR-066, BR-067 |

## Gate

All issues must satisfy [`../../delivery/DEFINITION_OF_DONE.md`](../../delivery/DEFINITION_OF_DONE.md). The milestone is not closed solely because all code issues were merged; run and record its integrated gate.
