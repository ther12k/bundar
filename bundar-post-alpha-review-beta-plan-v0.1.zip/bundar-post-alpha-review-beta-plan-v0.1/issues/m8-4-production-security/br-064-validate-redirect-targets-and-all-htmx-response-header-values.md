---
type: GitHub Issue Specification
title: BR-064 — Validate redirect targets and all HTMX response header values
description: Redirects, locations, selectors, event headers, history URLs, and dialect
  directives reject CRLF injection, invalid encodings, unsafe external destinations,
  and ambiguous serialized values.
tags:
- github-issue
- bundar
- security
- security
- p0
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-064
  milestone: M8.4 — Production and security hardening
  priority: P0
  size: M
  labels:
  - priority:p0
  - size:m
  - area:security
  - type:security
  - status:proposed
  depends_on:
  - BR-007
  - BR-017
  blocks:
  - BR-054
  - BR-068
  - BR-073
  - BR-085
  agent_ready: true
---

# BR-064 — Validate redirect targets and all HTMX response header values

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P0`  
**Size:** `M`  
**Area:** `security`  
**Type:** `security`

## Outcome

Redirects, locations, selectors, event headers, history URLs, and dialect directives reject CRLF injection, invalid encodings, unsafe external destinations, and ambiguous serialized values.

## Why this task exists

Bundar centralizes hypermedia response headers; this is a high-leverage trust boundary.

## Deliverables

- Inventory every response directive and classify URL, selector, token, JSON, boolean, and enum value types.
- Add centralized validators/serializers with same-origin defaults for application redirects and explicit opt-in for external navigation.
- Reject control characters, invalid header bytes, duplicate conflicting directives, unsafe schemes, and malformed JSON event payloads.

## Out of scope

- URL allowlists for application business rules

## Acceptance criteria

- [ ] CRLF/header-splitting payloads fail before Response construction.
- [ ] `javascript:`, credential-bearing, scheme-relative, and external redirect cases follow one documented policy.
- [ ] Selectors and event names cannot smuggle new headers.
- [ ] Both dialect adapters pass the same neutral validation corpus.

## Agent context contract

### Read set

- `packages/core/src/response.ts`
- `packages/htmx/src/directives.ts`
- `packages/htmx/test/header-security.test.ts`
- `docs/security/response-headers.md`

### Write set

- `packages/core/src/response.ts`
- `packages/htmx/src/directives.ts`
- `packages/htmx/test/header-security.test.ts`
- `docs/security/response-headers.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/response.ts`
- `packages/htmx/src/directives.ts`
- `packages/htmx/test/header-security.test.ts`
- `docs/security/response-headers.md`

## Verification

```bash
bun test packages/core/test/redirect-security.test.ts packages/htmx/test/header-security.test.ts
bun run security:headers-audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-007 — Audit every renderer, header, and HTMX unsafe sink](../m8-0-correctness/br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md)
- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)

## Blocks

- [BR-054 — Add safe response header and cookie mutation helpers](../m8-3-agent-tooling/br-054-add-safe-response-header-and-cookie-mutation-helpers.md)
- [BR-068 — Add property and fuzz tests for high-risk parsers and serializers](br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md)
- [BR-073 — Revalidate the neutral HTMX contract against the official v4 upgrade checker](../m8-5-conformance-performance/br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-064
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
