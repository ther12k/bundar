---
type: GitHub Issue Specification
title: BR-061 — Define durable session-store capabilities and failure semantics
description: Session adapters declare atomicity, TTL, rotation, deletion, touch, concurrency,
  serialization, and availability behavior required by Bundar security helpers.
tags:
- github-issue
- bundar
- security
- architecture
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-061
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:security
  - type:architecture
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-062
  - BR-063
  agent_ready: true
---

# BR-061 — Define durable session-store capabilities and failure semantics

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `security`  
**Type:** `architecture`

## Outcome

Session adapters declare atomicity, TTL, rotation, deletion, touch, concurrency, serialization, and availability behavior required by Bundar security helpers.

## Why this task exists

An in-memory fixture interface can hide production requirements such as atomic rotation or expiration consistency.

## Deliverables

- Define the minimal store port and optional capability flags.
- Specify session ID generation boundary, absolute/idle expiry, touch behavior, rotate/invalidate atomicity, and failure classification.
- Provide a conformance suite reusable by memory and future durable adapters.

## Out of scope

- Shipping a first-party database adapter in this issue

## Acceptance criteria

- [ ] A store lacking a required security capability is rejected or runs only in an explicitly degraded mode.
- [ ] Conformance tests cover concurrent read/touch/rotate/delete races.
- [ ] Store failures do not silently create anonymous/new sessions after a protected mutation.
- [ ] Serialization excludes functions, secrets not intended for persistence, and prototype-bearing objects.

## Agent context contract

### Read set

- `packages/security/src/session/store.ts`
- `packages/security/test/session-store-contract/**`
- `docs/guides/sessions.md`

### Write set

- `packages/security/src/session/store.ts`
- `packages/security/test/session-store-contract/**`
- `docs/guides/sessions.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/security/src/session/store.ts`
- `packages/security/test/session-store-contract/**`
- `docs/guides/sessions.md`

## Verification

```bash
bun test packages/security/test/session-store-contract/**
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](../m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-062 — Fail closed on memory sessions or insecure cookies in production](br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md)
- [BR-063 — Close session fixation, rotation, logout, and replay tests](br-063-close-session-fixation-rotation-logout-and-replay-tests.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-061
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
