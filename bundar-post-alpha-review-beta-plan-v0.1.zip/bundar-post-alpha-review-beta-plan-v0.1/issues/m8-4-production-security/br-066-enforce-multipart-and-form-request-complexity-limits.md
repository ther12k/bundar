---
type: GitHub Issue Specification
title: BR-066 — Enforce multipart and form request-complexity limits
description: Body parsing bounds bytes, fields, files, parts, header sizes, nesting/path
  complexity, duplicate keys, and temporary-resource usage before application work
  proceeds.
tags:
- github-issue
- bundar
- core
- security
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-066
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:core
  - type:security
  - status:proposed
  depends_on:
  - BR-015
  blocks:
  - BR-068
  - BR-071
  - BR-077
  - BR-085
  agent_ready: true
---

# BR-066 — Enforce multipart and form request-complexity limits

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `core`  
**Type:** `security`

## Outcome

Body parsing bounds bytes, fields, files, parts, header sizes, nesting/path complexity, duplicate keys, and temporary-resource usage before application work proceeds.

## Why this task exists

A byte limit alone does not prevent multipart/form parser abuse or huge validation structures.

## Deliverables

- Define independent limits for total bytes, fields, files, parts, per-field bytes, per-file bytes, multipart header bytes, duplicate count, and normalized field-path depth.
- Abort parsing and clean temporary resources deterministically when any limit is exceeded.
- Expose safe typed error codes without echoing sensitive values.

## Out of scope

- Virus scanning
- Cloud upload storage

## Acceptance criteria

- [ ] Boundary, many-empty-part, huge-header, duplicate-field, malformed-terminator, and slow/aborted body fixtures fail safely.
- [ ] Temporary files/resources are removed after every failure.
- [ ] Limits are configurable within safe global maxima and visible in diagnostics.
- [ ] No partial mutation action runs after a parsing-limit failure.

## Agent context contract

### Read set

- `packages/core/src/body.ts`
- `packages/forms/src/parser.ts`
- `packages/core/test/body-limits/**`
- `packages/forms/test/body-limits/**`

### Write set

- `packages/core/src/body.ts`
- `packages/forms/src/parser.ts`
- `packages/core/test/body-limits/**`
- `packages/forms/test/body-limits/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/body.ts`
- `packages/forms/src/parser.ts`
- `packages/core/test/body-limits/**`
- `packages/forms/test/body-limits/**`

## Verification

```bash
bun test packages/core/test/body-limits/** packages/forms/test/body-limits/**
bun run security:body-parser-audit
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)

## Blocks

- [BR-068 — Add property and fuzz tests for high-risk parsers and serializers](br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md)
- [BR-071 — Close body single-consumption and content-type conformance](../m8-5-conformance-performance/br-071-close-body-single-consumption-and-content-type-conformance.md)
- [BR-077 — Profile large-table rendering and form parsing, then set beta budgets](../m8-5-conformance-performance/br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-066
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
