---
type: GitHub Issue Specification
title: BR-057 — Define startup, readiness, shutdown, and graceful-stop lifecycle
description: Bundar provides a small explicit lifecycle for resource initialization,
  readiness, draining, server stop, and cleanup without introducing a DI container
  or large hook matrix.
tags:
- github-issue
- bundar
- core
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-057
  milestone: M8.4 — Production and security hardening
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:core
  - type:feature
  - status:proposed
  depends_on:
  - BR-003
  blocks:
  - BR-058
  agent_ready: true
---

# BR-057 — Define startup, readiness, shutdown, and graceful-stop lifecycle

**Milestone:** M8.4 — Production and security hardening  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `core`  
**Type:** `feature`

## Outcome

Bundar provides a small explicit lifecycle for resource initialization, readiness, draining, server stop, and cleanup without introducing a DI container or large hook matrix.

## Why this task exists

The alpha focuses on request handling; beta-oriented applications need a deterministic way to open and close databases, queues, session stores, and telemetry around `Bun.serve()`.

## Deliverables

- Define application-owned `start`, `ready`, `drain`, and `stop` responsibilities and ordering.
- Integrate with Bun server startup/stop, process signals, startup failure rollback, and bounded shutdown deadlines.
- Support registered cleanup resources without service-location magic.
- Expose test seams that do not send real process signals.

## Out of scope

- Dependency injection scopes
- Background job framework

## Acceptance criteria

- [ ] A startup failure closes resources initialized earlier in reverse order.
- [ ] Readiness stays false until all mandatory startup work completes.
- [ ] Shutdown stops accepting new work, allows bounded in-flight completion, then aborts and cleans up.
- [ ] Repeated stop calls are idempotent and deterministic.

## Agent context contract

### Read set

- `packages/core/src/lifecycle.ts`
- `packages/core/src/app.ts`
- `packages/core/test/lifecycle/**`
- `docs/guides/deployment.md`

### Write set

- `packages/core/src/lifecycle.ts`
- `packages/core/src/app.ts`
- `packages/core/test/lifecycle/**`
- `docs/guides/deployment.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/lifecycle.ts`
- `packages/core/src/app.ts`
- `packages/core/test/lifecycle/**`
- `docs/guides/deployment.md`

## Verification

```bash
bun test packages/core/test/lifecycle/**
bun run test:integration:lifecycle
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-003 — Move middleware composition fully into the compile phase](../m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md)

## Blocks

- [BR-058 — Propagate request cancellation through context, forms, and streams](br-058-propagate-request-cancellation-through-context-forms-and-streams.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-057
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
