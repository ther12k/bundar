---
type: GitHub Issue Specification
title: BR-053 — Remove manual HTML concatenation from reference applications
description: Todo and Admin use the typed action/update API for all multi-region mutations.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-053
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-052
  - BR-037
  - BR-043
  blocks:
  - BR-056
  - BR-085
  agent_ready: true
---

# BR-053 — Remove manual HTML concatenation from reference applications

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Todo and Admin use the typed action/update API for all multi-region mutations.

## Why this task exists

Reference apps should exercise the safest and clearest framework path, not internal serializer assembly.

## Deliverables

- Replace `renderToString(...) + serializeUpdates(...).html` and equivalent patterns.
- Use stable typed region IDs and normalized update operations.
- Delete obsolete app-local composition helpers and add source guards.

## Out of scope

- Removing low-level APIs from framework packages

## Acceptance criteria

- [ ] No application code manually concatenates rendered primary and update fragments.
- [ ] OOB/partial behavior remains equivalent in both dialect lanes.
- [ ] Remove, replace, and no-content update cases are covered.
- [ ] The source-diff and no-JS suites remain green.

## Agent context contract

### Read set

- `examples/todo/src/**`
- `examples/admin/src/**`
- `tools/architecture/**`

### Write set

- `examples/todo/src/**`
- `examples/admin/src/**`
- `tools/architecture/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/todo/src/**`
- `examples/admin/src/**`
- `tools/architecture/**`

## Verification

```bash
rg -n 'renderToString.*\+|serializeUpdates' examples templates
bun test examples/todo examples/admin
bun run test:dual-app
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-052 — Add a typed primary-fragment and update-intent response API](br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md)
- [BR-037 — Close Todo feature-slice regression and source-diff evidence](../m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md)
- [BR-043 — Close Admin feature-slice regression and architecture evidence](../m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md)

## Blocks

- [BR-056 — Refactor examples away from manual cookie and Response reconstruction](br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-053
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
