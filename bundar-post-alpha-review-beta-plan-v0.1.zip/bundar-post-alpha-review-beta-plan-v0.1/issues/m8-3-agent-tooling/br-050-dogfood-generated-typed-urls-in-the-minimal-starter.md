---
type: GitHub Issue Specification
title: BR-050 — Dogfood generated typed URLs in the minimal starter
description: The minimal starter uses its route manifest/typed URL API for links,
  form actions, assets, redirects, and HTMX attributes instead of duplicating path
  strings.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-050
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-030
  blocks:
  - BR-051
  agent_ready: true
---

# BR-050 — Dogfood generated typed URLs in the minimal starter

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

The minimal starter uses its route manifest/typed URL API for links, form actions, assets, redirects, and HTMX attributes instead of duplicating path strings.

## Why this task exists

A framework feature is not trustworthy if its canonical starter bypasses it.

## Deliverables

- Replace hardcoded internal paths with generated route helpers.
- Keep external URLs and intentionally literal CSS selectors explicit.
- Add route-generation drift checks to the starter journey.

## Out of scope

- Typing arbitrary external URLs

## Acceptance criteria

- [ ] Renaming a registered route or parameter causes a compile/check failure at every dependent callsite.
- [ ] No duplicate string remains for an internal endpoint covered by the route manifest.
- [ ] Generated code is deterministic and never hand-edited.
- [ ] Ordinary and enhanced journeys remain unchanged.

## Agent context contract

### Read set

- `templates/minimal/src/routes.ts`
- `templates/minimal/src/routes.gen.ts`
- `templates/minimal/src/features/**`
- `templates/minimal/src/app.test.ts`

### Write set

- `templates/minimal/src/routes.ts`
- `templates/minimal/src/routes.gen.ts`
- `templates/minimal/src/features/**`
- `templates/minimal/src/app.test.ts`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `templates/minimal/src/routes.ts`
- `templates/minimal/src/routes.gen.ts`
- `templates/minimal/src/features/**`
- `templates/minimal/src/app.test.ts`

## Verification

```bash
bun run routes:generate
bun run routes:check
bun test templates/minimal
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-030 — Reduce the minimal route module to HTTP and hypermedia orchestration](../m8-2-agent-architecture/br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md)

## Blocks

- [BR-051 — Dogfood generated typed URLs in Todo and Admin](br-051-dogfood-generated-typed-urls-in-todo-and-admin.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-050
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
