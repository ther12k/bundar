---
type: GitHub Issue Specification
title: BR-046 — Standardize deterministic machine-readable CLI behavior
description: Agent-facing Bundar CLI commands support stable `--json`, `--no-color`,
  `--quiet`, and `--dry-run` behavior with documented exit codes.
tags:
- github-issue
- bundar
- cli
- tooling
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-046
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:cli
  - type:tooling
  - status:proposed
  depends_on:
  - BR-001
  blocks:
  - BR-047
  - BR-049
  agent_ready: true
---

# BR-046 — Standardize deterministic machine-readable CLI behavior

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `cli`  
**Type:** `tooling`

## Outcome

Agent-facing Bundar CLI commands support stable `--json`, `--no-color`, `--quiet`, and `--dry-run` behavior with documented exit codes.

## Why this task exists

Human-friendly output alone is brittle for coding agents and automation. Machine modes must be contracts rather than incidental formatting.

## Deliverables

- Inventory current CLI commands and classify output, mutations, prompts, network use, and exit codes.
- Define one versioned JSON envelope for success, warnings, failures, artifacts, and suggested next commands.
- Implement common flags and prohibit prompts when stdin is noninteractive or JSON mode is selected.
- Make dry-run output describe planned writes without changing the filesystem.

## Out of scope

- Freezing every human-readable sentence
- Remote agent service

## Acceptance criteria

- [ ] Repeated runs over identical input produce stable JSON ordering and values except explicitly documented timestamps.
- [ ] Every command returns a documented nonzero exit code for validation, environment, and execution failures.
- [ ] `--dry-run` leaves a hash-verified fixture tree unchanged.
- [ ] Color/control characters never appear in JSON output.

## Agent context contract

### Read set

- `packages/cli/src/**`
- `packages/cli/test/**`
- `docs/guides/cli.md`

### Write set

- `packages/cli/src/**`
- `packages/cli/test/**`
- `docs/guides/cli.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/cli/src/**`
- `packages/cli/test/**`
- `docs/guides/cli.md`

## Verification

```bash
bun test packages/cli/test/machine-output/**
bun packages/cli/src/bin.ts --help
bun packages/cli/src/bin.ts doctor --json
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-001 — Freeze the post-alpha audit baseline and provenance](../m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md)

## Blocks

- [BR-047 — Add `bundar inspect --json` for routes, packages, and feature boundaries](br-047-add-bundar-inspect-json-for-routes-packages-and-feature-boundaries.md)
- [BR-049 — Adopt agent-ready GitHub issue read/write/check contracts](br-049-adopt-agent-ready-github-issue-read-write-check-contracts.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-046
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
