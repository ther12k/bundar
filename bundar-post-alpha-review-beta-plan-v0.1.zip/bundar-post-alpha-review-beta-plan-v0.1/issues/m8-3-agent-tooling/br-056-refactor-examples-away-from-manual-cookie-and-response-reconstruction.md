---
type: GitHub Issue Specification
title: BR-056 — Refactor examples away from manual cookie and Response reconstruction
description: Canonical examples use Bundar's typed URL, action/update, response mutation,
  and CSRF helpers consistently.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-056
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-053
  - BR-054
  - BR-055
  blocks:
  - BR-085
  agent_ready: true
---

# BR-056 — Refactor examples away from manual cookie and Response reconstruction

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Canonical examples use Bundar's typed URL, action/update, response mutation, and CSRF helpers consistently.

## Why this task exists

Dogfooding closes the gap between first-party APIs and the patterns users or agents copy.

## Deliverables

- Remove app-local cookie regex helpers, manual Set-Cookie append/rebuild functions, and response reconstruction.
- Use the post-refactor form/HTMX/security APIs.
- Add source scans preventing the removed patterns from returning.

## Out of scope

- Removing native Request/Response escape hatches

## Acceptance criteria

- [ ] No reference app parses its own framework session/CSRF cookie with regex.
- [ ] No reference app manually clones a Response solely to append framework cookies/headers.
- [ ] All ordinary, enhanced, invalid, logout, and conflict journeys remain green.
- [ ] Documentation snippets show only the preferred APIs.

## Agent context contract

### Read set

- `examples/**`
- `templates/**`
- `docs/examples/**`
- `tools/architecture/**`

### Write set

- `examples/**`
- `templates/**`
- `docs/examples/**`
- `tools/architecture/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/**`
- `templates/**`
- `docs/examples/**`
- `tools/architecture/**`

## Verification

```bash
rg -n 'cookie.*match|new Response\(.*response\.body|renderToString.*\+' examples templates
bun test examples/todo examples/admin templates/minimal
bun run docs:check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-053 — Remove manual HTML concatenation from reference applications](br-053-remove-manual-html-concatenation-from-reference-applications.md)
- [BR-054 — Add safe response header and cookie mutation helpers](br-054-add-safe-response-header-and-cookie-mutation-helpers.md)
- [BR-055 — Add CSRF form-field and session-token composition helpers](br-055-add-csrf-form-field-and-session-token-composition-helpers.md)

## Blocks

- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-056
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
