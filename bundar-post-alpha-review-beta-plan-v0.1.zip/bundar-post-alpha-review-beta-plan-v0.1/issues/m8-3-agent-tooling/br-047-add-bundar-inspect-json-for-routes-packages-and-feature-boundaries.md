---
type: GitHub Issue Specification
title: BR-047 — Add `bundar inspect --json` for routes, packages, and feature boundaries
description: One offline command emits a bounded project manifest that agents and
  tools can use without crawling the entire repository.
tags:
- github-issue
- bundar
- cli
- feature
- p2
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-047
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P2
  size: M
  labels:
  - priority:p2
  - size:m
  - area:cli
  - type:feature
  - status:proposed
  depends_on:
  - BR-046
  - BR-023
  blocks:
  - BR-048
  agent_ready: true
---

# BR-047 — Add `bundar inspect --json` for routes, packages, and feature boundaries

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P2`  
**Size:** `M`  
**Area:** `cli`  
**Type:** `feature`

## Outcome

One offline command emits a bounded project manifest that agents and tools can use without crawling the entire repository.

## Why this task exists

Bundar already has route and architecture knowledge; exposing a stable read-only manifest reduces context and accidental cross-boundary edits.

## Deliverables

- Report Bundar/Bun versions, packages, export maps, app entrypoints, routes/names/methods/paths, feature entrypoints, layer edges, dialect selection, generated files, and focused checks.
- Support repository, application, or feature scope.
- Hash source files or configuration inputs so stale manifests can be detected.

## Out of scope

- Static code intelligence for arbitrary frameworks
- Uploading manifests

## Acceptance criteria

- [ ] The command performs no writes and requires no network access.
- [ ] Output is deterministic and validates against a checked-in JSON schema.
- [ ] Secrets, environment values, source bodies, and user data are excluded.
- [ ] A feature-scoped invocation stays within a documented size budget on the reference apps.

## Agent context contract

### Read set

- `packages/cli/src/commands/inspect.ts`
- `packages/cli/src/schemas/inspect.schema.json`
- `packages/cli/test/inspect/**`

### Write set

- `packages/cli/src/commands/inspect.ts`
- `packages/cli/src/schemas/inspect.schema.json`
- `packages/cli/test/inspect/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/cli/src/commands/inspect.ts`
- `packages/cli/src/schemas/inspect.schema.json`
- `packages/cli/test/inspect/**`

## Verification

```bash
bun packages/cli/src/bin.ts inspect --json
bun test packages/cli/test/inspect/**
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-046 — Standardize deterministic machine-readable CLI behavior](br-046-standardize-deterministic-machine-readable-cli-behavior.md)
- [BR-023 — Implement an application feature-boundary checker](../m8-2-agent-architecture/br-023-implement-an-application-feature-boundary-checker.md)

## Blocks

- [BR-048 — Add `bundar agent-context <feature>` bounded context packs](br-048-add-bundar-agent-context-feature-bounded-context-packs.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-047
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
