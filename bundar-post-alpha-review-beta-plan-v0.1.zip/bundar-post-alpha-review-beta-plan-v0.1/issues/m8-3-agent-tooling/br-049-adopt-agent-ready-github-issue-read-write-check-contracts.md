---
type: GitHub Issue Specification
title: BR-049 — Adopt agent-ready GitHub issue read/write/check contracts
description: Every implementation issue tells an agent what it may read, what it may
  change, what it must not change, and the smallest command set required for closure.
tags:
- github-issue
- bundar
- agents
- process
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-049
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: S
  labels:
  - priority:p1
  - size:s
  - area:agents
  - type:process
  - status:proposed
  depends_on:
  - BR-022
  - BR-046
  blocks: []
  agent_ready: true
---

# BR-049 — Adopt agent-ready GitHub issue read/write/check contracts

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `S`  
**Area:** `agents`  
**Type:** `process`

## Outcome

Every implementation issue tells an agent what it may read, what it may change, what it must not change, and the smallest command set required for closure.

## Why this task exists

The original issue format is evidence-rich, but explicit bounded context fields make low-context parallel work safer.

## Deliverables

- Extend issue templates with `read_set`, `write_set`, `forbidden_changes`, `focused_checks`, `full_gate`, `parallel_safety`, and `human_gate`.
- Define how to expand a read/write set when contradictory evidence is found.
- Add validation for missing paths, unknown dependencies, and overlapping parallel write sets.

## Out of scope

- Automatically assigning agents
- Replacing human review

## Acceptance criteria

- [ ] New issues cannot be marked agent-ready without all mandatory fields.
- [ ] Two issues declared parallel-safe are rejected if their write sets overlap incompatibly.
- [ ] The template tells agents to stop rather than weaken acceptance criteria.
- [ ] The closure report includes actual files/commands and deviations from the planned sets.

## Agent context contract

### Read set

- `.github/ISSUE_TEMPLATE/**`
- `github/issue-template.md`
- `tools/issues/**`
- `MASTER_AGENT_PROMPT.md`

### Write set

- `.github/ISSUE_TEMPLATE/**`
- `github/issue-template.md`
- `tools/issues/**`
- `MASTER_AGENT_PROMPT.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `.github/ISSUE_TEMPLATE/**`
- `github/issue-template.md`
- `tools/issues/**`
- `MASTER_AGENT_PROMPT.md`

## Verification

```bash
bun run issues:validate
bun run issues:parallel-check
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-022 — Define application import direction and agent read/write zones](../m8-2-agent-architecture/br-022-define-application-import-direction-and-agent-read-write-zones.md)
- [BR-046 — Standardize deterministic machine-readable CLI behavior](br-046-standardize-deterministic-machine-readable-cli-behavior.md)

## Blocks

- No direct issue in this plan.

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-049
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
