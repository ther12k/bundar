---
type: Milestone Issue Index
title: M8.3 — Agent tooling and API dogfooding
description: Turn agent friendliness and preferred APIs into first-party tooling and
  dogfooded examples.
tags:
- bundar
- issues
- milestone
- m8-3-agent-tooling
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# M8.3 — Agent tooling and API dogfooding

## Goal

Turn agent friendliness and preferred APIs into first-party tooling and dogfooded examples.

## Exit conditions

- [ ] Deterministic CLI machine mode
- [ ] Inspect/context packs available
- [ ] Typed URLs/action/update/security helpers used by examples

| ID | Priority | Size | Area | Task | Depends on |
| --- | --- | --- | --- | --- | --- |
| [BR-046](br-046-standardize-deterministic-machine-readable-cli-behavior.md) | P1 | M | cli | Standardize deterministic machine-readable CLI behavior | BR-001 |
| [BR-047](br-047-add-bundar-inspect-json-for-routes-packages-and-feature-boundaries.md) | P2 | M | cli | Add `bundar inspect --json` for routes, packages, and feature boundaries | BR-046, BR-023 |
| [BR-048](br-048-add-bundar-agent-context-feature-bounded-context-packs.md) | P2 | M | agents | Add `bundar agent-context <feature>` bounded context packs | BR-047, BR-044 |
| [BR-049](br-049-adopt-agent-ready-github-issue-read-write-check-contracts.md) | P1 | S | agents | Adopt agent-ready GitHub issue read/write/check contracts | BR-022, BR-046 |
| [BR-050](br-050-dogfood-generated-typed-urls-in-the-minimal-starter.md) | P1 | S | examples | Dogfood generated typed URLs in the minimal starter | BR-030 |
| [BR-051](br-051-dogfood-generated-typed-urls-in-todo-and-admin.md) | P1 | M | examples | Dogfood generated typed URLs in Todo and Admin | BR-037, BR-043, BR-050 |
| [BR-052](br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md) | P1 | M | htmx | Add a typed primary-fragment and update-intent response API | BR-017, BR-015 |
| [BR-053](br-053-remove-manual-html-concatenation-from-reference-applications.md) | P1 | S | examples | Remove manual HTML concatenation from reference applications | BR-052, BR-037, BR-043 |
| [BR-054](br-054-add-safe-response-header-and-cookie-mutation-helpers.md) | P1 | M | core | Add safe response header and cookie mutation helpers | BR-003, BR-007, BR-064 |
| [BR-055](br-055-add-csrf-form-field-and-session-token-composition-helpers.md) | P1 | M | security | Add CSRF form-field and session-token composition helpers | BR-015, BR-054 |
| [BR-056](br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md) | P1 | S | examples | Refactor examples away from manual cookie and Response reconstruction | BR-053, BR-054, BR-055 |

## Gate

All issues must satisfy [`../../delivery/DEFINITION_OF_DONE.md`](../../delivery/DEFINITION_OF_DONE.md). The milestone is not closed solely because all code issues were merged; run and record its integrated gate.
