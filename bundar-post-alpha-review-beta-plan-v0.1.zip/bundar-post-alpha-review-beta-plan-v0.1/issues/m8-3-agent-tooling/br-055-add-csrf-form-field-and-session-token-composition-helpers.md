---
type: GitHub Issue Specification
title: BR-055 — Add CSRF form-field and session-token composition helpers
description: Applications can render and validate session-bound CSRF tokens without
  hand-parsing cookie headers or duplicating hidden-field/cookie logic.
tags:
- github-issue
- bundar
- security
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-055
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:security
  - type:feature
  - status:proposed
  depends_on:
  - BR-015
  - BR-054
  blocks:
  - BR-056
  agent_ready: true
---

# BR-055 — Add CSRF form-field and session-token composition helpers

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `security`  
**Type:** `feature`

## Outcome

Applications can render and validate session-bound CSRF tokens without hand-parsing cookie headers or duplicating hidden-field/cookie logic.

## Why this task exists

Reference code currently demonstrates manual token extraction and cookie handling, which is easy for users and agents to copy incorrectly.

## Deliverables

- Expose a server-side helper that obtains/rotates a token and returns typed hidden-field props plus required cookie mutations.
- Integrate with session middleware, origin policy, invalid-form retry semantics, and the response mutation helper.
- Keep synchronizer-token and double-submit choices explicit in the API/documentation.

## Out of scope

- A complete authentication product

## Acceptance criteria

- [ ] The helper eliminates manual cookie regex parsing in examples.
- [ ] A 422 rerender preserves or safely rotates the token according to the documented contract.
- [ ] Token/session mismatch, missing token, duplicate field, malformed cookie, and logout cases fail closed.
- [ ] No secret token value appears in logs or validation issue payloads.

## Agent context contract

### Read set

- `packages/security/src/csrf/**`
- `packages/forms/src/**`
- `packages/security/test/csrf-form/**`
- `docs/guides/security.md`

### Write set

- `packages/security/src/csrf/**`
- `packages/forms/src/**`
- `packages/security/test/csrf-form/**`
- `docs/guides/security.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/security/src/csrf/**`
- `packages/forms/src/**`
- `packages/security/test/csrf-form/**`
- `docs/guides/security.md`

## Verification

```bash
bun test packages/security/test/csrf-form/**
bun run security:csrf-audit
bun run test:example -- todo:no-js
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)
- [BR-054 — Add safe response header and cookie mutation helpers](br-054-add-safe-response-header-and-cookie-mutation-helpers.md)

## Blocks

- [BR-056 — Refactor examples away from manual cookie and Response reconstruction](br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-055
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
