---
type: GitHub Issue Specification
title: BR-052 — Add a typed primary-fragment and update-intent response API
description: Applications can return one primary fragment plus normalized secondary
  updates without manually rendering and concatenating HTML strings.
tags:
- github-issue
- bundar
- htmx
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-052
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:htmx
  - type:feature
  - status:proposed
  depends_on:
  - BR-017
  - BR-015
  blocks:
  - BR-053
  - BR-077
  agent_ready: true
---

# BR-052 — Add a typed primary-fragment and update-intent response API

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `htmx`  
**Type:** `feature`

## Outcome

Applications can return one primary fragment plus normalized secondary updates without manually rendering and concatenating HTML strings.

## Why this task exists

The inspected Todo app manually combines `renderToString(primary)` with serialized update HTML, which leaks rendering/protocol mechanics into application routes.

## Deliverables

- Define a version-neutral response spec containing primary content, target/swap intent, secondary updates, status, headers, events, and ordinary fallback.
- Render the response through the selected dialect and JSX renderer.
- Support async/stream-aware nodes where safe, with explicit buffering rules when secondary updates require ordering.

## Out of scope

- A general client-side state protocol
- Hiding standard HTMX attributes in components

## Acceptance criteria

- [ ] Todo create/edit/toggle/delete responses can be expressed without manual HTML concatenation.
- [ ] Applications never construct raw `hx-swap-oob` or htmx 4 partial markers for normalized updates.
- [ ] The same spec works in htmx 2 and the experimental htmx 4 adapter.
- [ ] Status, cache variation, history safety, and content type remain correct.

## Agent context contract

### Read set

- `packages/htmx/src/action.ts`
- `packages/htmx/src/updates.ts`
- `packages/htmx/test/action-updates.test.ts`
- `packages/forms/src/**`

### Write set

- `packages/htmx/src/action.ts`
- `packages/htmx/src/updates.ts`
- `packages/htmx/test/action-updates.test.ts`
- `packages/forms/src/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/htmx/src/action.ts`
- `packages/htmx/src/updates.ts`
- `packages/htmx/test/action-updates.test.ts`
- `packages/forms/src/**`

## Verification

```bash
bun test packages/htmx/test/action-updates.test.ts
bun run test:dual-app
bun run test:browser:htmx2
bun run test:browser:htmx4
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-017 — Make `@bundar/htmx` protocol-pure](../m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md)
- [BR-015 — Move progressive form orchestration into `@bundar/forms`](../m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md)

## Blocks

- [BR-053 — Remove manual HTML concatenation from reference applications](br-053-remove-manual-html-concatenation-from-reference-applications.md)
- [BR-077 — Profile large-table rendering and form parsing, then set beta budgets](../m8-5-conformance-performance/br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-052
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
