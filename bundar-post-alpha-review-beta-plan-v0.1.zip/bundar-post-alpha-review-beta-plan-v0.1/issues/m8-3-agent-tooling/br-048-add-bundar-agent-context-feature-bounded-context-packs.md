---
type: GitHub Issue Specification
title: BR-048 — Add `bundar agent-context <feature>` bounded context packs
description: An agent can request a small, deterministic Markdown/JSON pack containing
  only the selected feature's contracts, dependencies, relevant tests, and local instructions.
tags:
- github-issue
- bundar
- agents
- feature
- p2
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-048
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P2
  size: M
  labels:
  - priority:p2
  - size:m
  - area:agents
  - type:feature
  - status:proposed
  depends_on:
  - BR-047
  - BR-044
  blocks:
  - BR-084
  - BR-085
  agent_ready: true
---

# BR-048 — Add `bundar agent-context <feature>` bounded context packs

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P2`  
**Size:** `M`  
**Area:** `agents`  
**Type:** `feature`

## Outcome

An agent can request a small, deterministic Markdown/JSON pack containing only the selected feature's contracts, dependencies, relevant tests, and local instructions.

## Why this task exists

The project explicitly targets AI-agent-friendly development; bounded context should be a first-party tool, not a convention agents must rediscover.

## Deliverables

- Select files from feature maps, import graph, route manifest, test ownership, and task metadata.
- Emit summary, invariants, public APIs, direct dependencies, direct dependents, read-only evidence, writable paths, commands, and unresolved TODOs.
- Add `--format md|json`, `--max-bytes`, and `--include-diff` options.
- Fail closed when the requested scope would omit a declared dependency or exceed budget without an explicit override.

## Out of scope

- An autonomous cloud agent
- Embedding the whole repository

## Acceptance criteria

- [ ] A Todo UI pack excludes repository implementation source while preserving required view models and contracts.
- [ ] A Todo action pack excludes JSX/HTMX source while preserving domain and repository ports.
- [ ] No secret-like `.env`, credential, build artifact, or dependency directory is included.
- [ ] Output is deterministic and tested against golden fixtures.

## Agent context contract

### Read set

- `packages/cli/src/commands/agent-context.ts`
- `packages/cli/test/agent-context/**`
- `engineering/agent-context.md`

### Write set

- `packages/cli/src/commands/agent-context.ts`
- `packages/cli/test/agent-context/**`
- `engineering/agent-context.md`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/cli/src/commands/agent-context.ts`
- `packages/cli/test/agent-context/**`
- `engineering/agent-context.md`

## Verification

```bash
bun packages/cli/src/bin.ts agent-context todos --format json
bun test packages/cli/test/agent-context/**
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-047 — Add `bundar inspect --json` for routes, packages, and feature boundaries](br-047-add-bundar-inspect-json-for-routes-packages-and-feature-boundaries.md)
- [BR-044 — Add concise local `AGENTS.md` and feature-map templates](../m8-2-agent-architecture/br-044-add-concise-local-agents-md-and-feature-map-templates.md)

## Blocks

- [BR-084 — Run an independent greenfield human-and-agent usability study](../m8-6-beta-release/br-084-run-an-independent-greenfield-human-and-agent-usability-study.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-048
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
