---
type: GitHub Issue Specification
title: BR-054 — Add safe response header and cookie mutation helpers
description: Middleware and route code can add cookies/headers to buffered or streaming
  responses without manually rebuilding responses or losing metadata.
tags:
- github-issue
- bundar
- core
- feature
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-054
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:core
  - type:feature
  - status:proposed
  depends_on:
  - BR-003
  - BR-007
  - BR-064
  blocks:
  - BR-055
  - BR-056
  agent_ready: true
---

# BR-054 — Add safe response header and cookie mutation helpers

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `core`  
**Type:** `feature`

## Outcome

Middleware and route code can add cookies/headers to buffered or streaming responses without manually rebuilding responses or losing metadata.

## Why this task exists

The inspected Todo app reconstructs a `Response` to append a cookie. Repeated manual cloning risks dropping status text, multi-value headers, body semantics, or stream ownership.

## Deliverables

- Define helpers for append/set/delete headers and Set-Cookie values over immutable Response semantics.
- Specify behavior for null bodies, streams, already-used bodies, multiple cookies, and committed streaming responses.
- Preserve status, status text, body, content length rules, and header multiplicity.

## Out of scope

- Mutable response objects
- Automatic global cookie state

## Acceptance criteria

- [ ] Appending one or multiple cookies preserves all existing response properties.
- [ ] The helper fails clearly when mutation is impossible after stream commitment.
- [ ] Header values pass centralized validation from BR-064.
- [ ] Tests cover redirect, error, empty, string, and streaming responses.

## Agent context contract

### Read set

- `packages/core/src/response.ts`
- `packages/core/src/cookies.ts`
- `packages/core/test/response-mutation/**`

### Write set

- `packages/core/src/response.ts`
- `packages/core/src/cookies.ts`
- `packages/core/test/response-mutation/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `packages/core/src/response.ts`
- `packages/core/src/cookies.ts`
- `packages/core/test/response-mutation/**`

## Verification

```bash
bun test packages/core/test/response-mutation/**
bun run test:integration:core
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-003 — Move middleware composition fully into the compile phase](../m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md)
- [BR-007 — Audit every renderer, header, and HTMX unsafe sink](../m8-0-correctness/br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md)
- [BR-064 — Validate redirect targets and all HTMX response header values](../m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md)

## Blocks

- [BR-055 — Add CSRF form-field and session-token composition helpers](br-055-add-csrf-form-field-and-session-token-composition-helpers.md)
- [BR-056 — Refactor examples away from manual cookie and Response reconstruction](br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-054
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
