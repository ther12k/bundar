---
type: GitHub Issue Specification
title: BR-051 — Dogfood generated typed URLs in Todo and Admin
description: Both reference apps use the same typed route helpers that Bundar recommends
  to applications.
tags:
- github-issue
- bundar
- examples
- refactor
- p1
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
issue:
  stable_id: BR-051
  milestone: M8.3 — Agent tooling and API dogfooding
  priority: P1
  size: M
  labels:
  - priority:p1
  - size:m
  - area:examples
  - type:refactor
  - status:proposed
  depends_on:
  - BR-037
  - BR-043
  - BR-050
  blocks:
  - BR-083
  - BR-085
  agent_ready: true
---

# BR-051 — Dogfood generated typed URLs in Todo and Admin

**Milestone:** M8.3 — Agent tooling and API dogfooding  
**Priority:** `P1`  
**Size:** `M`  
**Area:** `examples`  
**Type:** `refactor`

## Outcome

Both reference apps use the same typed route helpers that Bundar recommends to applications.

## Why this task exists

Hardcoded route strings make large examples harder to refactor and give agents no authoritative route identity.

## Deliverables

- Replace internal links, form actions, HTMX requests, redirects, navigation, pagination, filters, and asset routes.
- Provide typed parameter/query construction without hiding standard HTML attributes.
- Add source checks for covered hardcoded internal paths.

## Out of scope

- Changing public example URLs without migration notes

## Acceptance criteria

- [ ] All route parameters are typechecked.
- [ ] A route rename produces a bounded, deterministic set of compile errors or generated diffs.
- [ ] The dialect-only source-diff contract remains intact.
- [ ] No-JS and both HTMX lanes remain green.

## Agent context contract

### Read set

- `examples/todo/src/**`
- `examples/admin/src/**`
- `packages/cli/src/routes/**`

### Write set

- `examples/todo/src/**`
- `examples/admin/src/**`
- `packages/cli/src/routes/**`

### Forbidden changes

- Do not weaken an existing gate, skip a mandatory test, or turn a failure into a warning.
- Do not change package/runtime scope, dialect defaults, route contracts, or security behavior beyond this issue.
- Do not edit generated files manually when a generator is authoritative.
- Stop and open a decision/blocker issue if source evidence contradicts this task.

## Suggested files

- `examples/todo/src/**`
- `examples/admin/src/**`
- `packages/cli/src/routes/**`

## Verification

```bash
bun run routes:generate
bun run routes:check
bun test examples/todo examples/admin
bun run htmx:source-diff examples/todo examples/admin
```

The commands above are the planned focused checks. Record exact commands, versions, exit statuses, and evidence paths. Run the milestone/full gate required by the repository before merge.

## Dependencies

- [BR-037 — Close Todo feature-slice regression and source-diff evidence](../m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md)
- [BR-043 — Close Admin feature-slice regression and architecture evidence](../m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md)
- [BR-050 — Dogfood generated typed URLs in the minimal starter](br-050-dogfood-generated-typed-urls-in-the-minimal-starter.md)

## Blocks

- [BR-083 — Build and verify an alpha-to-beta migration fixture](../m8-6-beta-release/br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md)
- [BR-085 — Run the beta release gate and issue an evidence-backed go/no-go](../m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md)

## Evidence required for closure

- Commit and pull-request link.
- Exact Bun, TypeScript, operating-system, package, browser, and HTMX versions relevant to the change.
- Focused verification transcript plus the required milestone/full-gate result.
- Before/after test, benchmark, security, API, package, browser, or documentation artifacts required by the acceptance criteria.
- Public API and migration notes, security/performance impact, residual risks, and newly unblocked stable IDs.

## Closure report template

```markdown
Stable ID: BR-051
Commit / PR:
Baseline rebased to:
Files changed:
Planned read set deviations:
Planned write set deviations:
Commands executed:
Evidence paths:
Contract / API changes:
Security / performance impact:
Remaining risks:
Documentation updated:
Newly unblocked issues:
```
