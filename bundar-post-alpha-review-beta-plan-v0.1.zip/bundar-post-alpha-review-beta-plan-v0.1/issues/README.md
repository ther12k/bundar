---
type: Issue Index
title: Bundar Post-Alpha GitHub Microtask Index
description: Navigation and execution rules for 85 dependency-aware GitHub-ready issues.
tags:
- bundar
- github
- issues
- microtasks
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# Issue index

## Rules

- Stable IDs `BR-001` through `BR-085` are authoritative even after GitHub assigns numeric IDs.
- Create issues in topological order.
- One issue normally maps to one worktree and one pull request.
- Do not assign a blocked issue.
- Issues in the same wave may still share write sets.
- P0 reproduction tasks must complete before their paired fix.
- Human-gated issues cannot be closed solely by an agent.
- BR-085 is an aggregation gate, not a place to repair code.

## Milestones

| Milestone | Count | Purpose |
| --- | ---: | --- |
| [M8.0 — Post-alpha correctness and claim closure](m8-0-correctness/README.md) | 10 | Close factual/contract drift before expanding beta scope. |
| [M8.1 — Package-boundary reset](m8-1-package-boundaries/README.md) | 10 | Reset package ownership before public registry consumers depend on it. |
| [M8.2 — Agent-friendly application architecture](m8-2-agent-architecture/README.md) | 25 | Make Bundar applications readable and safely changeable by humans and low-context agents. |
| [M8.3 — Agent tooling and API dogfooding](m8-3-agent-tooling/README.md) | 11 | Turn agent friendliness and preferred APIs into first-party tooling and dogfooded examples. |
| [M8.4 — Production and security hardening](m8-4-production-security/README.md) | 12 | Close fail-closed production and security contracts. |
| [M8.5 — Conformance, browsers, and performance](m8-5-conformance-performance/README.md) | 9 | Broaden protocol/browser evidence and measure target workloads fairly. |
| [M8.6 — Distribution and beta readiness](m8-6-beta-release/README.md) | 8 | Prove real external distribution and issue the beta decision. |

## Priority summary

| Priority | Count | Meaning |
| --- | ---: | --- |
| P0 | 23 | Beta blocker or prerequisite decision/reproduction/human gate |
| P1 | 56 | Required for the proposed beta quality bar unless explicitly accepted |
| P2 | 6 | Evidence, usability, or performance enhancement; may be adjudicated at gate |

## Size summary

| Size | Count | Expected scope |
| --- | ---: | --- |
| XS | 5 | One narrow doc/config/test change |
| S | 35 | One bounded behavior or small refactor |
| M | 45 | Several tightly coupled files with one outcome |

No issue is intentionally sized `L`. When implementation evidence shows an M task is too broad, split it while preserving stable dependency edges.

## Machine-readable source

The YAML frontmatter in every issue contains:

```yaml
issue:
  stable_id:
  milestone:
  priority:
  size:
  labels:
  depends_on:
  blocks:
  agent_ready:
```

The GitHub manifest is [`../github/ISSUE_MANIFEST.md`](../github/ISSUE_MANIFEST.md).
