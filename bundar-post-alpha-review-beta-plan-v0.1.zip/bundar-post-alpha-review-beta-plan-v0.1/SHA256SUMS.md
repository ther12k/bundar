---
type: Checksum Manifest
title: Bundar Post-Alpha Review File Checksums
description: SHA-256 checksums for every file inside the review bundle except this
  self-referential manifest.
tags:
- bundar
- checksums
- integrity
- bundle
status: final
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
---

# File checksums

This manifest excludes itself because a file cannot contain its own stable checksum.

| SHA-256 | Bytes | File |
| --- | ---: | --- |
| `e394893c1b1e86890721116a77ac4eb9f14aa5303ed3190fa13336b02b6d0835` | 2194 | `BUNDLE_REPORT.md` |
| `bb01f222cf1cbfb1bb2bd6a134e97f0e6268f531517399535a114656c177d709` | 9931 | `README.md` |
| `1b602cf15f0a6148b12602b5558d0a1262a61c8f31e6f16f04b580ff9b628341` | 2739 | `VALIDATION_REPORT.md` |
| `a4c6af30405e80e1d450f7e41f9cd1e65ca45dea0331dffc90ec366de428086e` | 3304 | `agents/LOW_CONTEXT_TASK_PROTOCOL.md` |
| `2eddd17659a0da39dc01052b63dff775692ec556cfaeceeffe714d043dfd85f5` | 4969 | `agents/MASTER_EXECUTION_PROMPT.md` |
| `fea9362bcb6980a35e13a4758179804dca463c528ee7c00461492037b316fc23` | 11214 | `architecture/AGENT_FRIENDLY_APPLICATION_STRUCTURE.md` |
| `a08204a63bf61940d8c9757395e29bb304032bf094454bac0beac137b55e91c8` | 4888 | `architecture/BETA_EXIT_CRITERIA.md` |
| `6fff64fa5241fce8c099eb20d23c21e5afcec62852ccdc4d03ef429f46ed18aa` | 3555 | `architecture/HTMX4_MIGRATION_REVIEW.md` |
| `cc3768ad50913c0bf9815f54ed3e92d76e241daab01b880202c17bdcf8ebed87` | 5173 | `architecture/PACKAGE_BOUNDARY_RECOMMENDATION.md` |
| `0c1235fcf2ea15e7857a17d962bb8157dbf2e84bd6519dadd04866f7e536b77c` | 2832 | `delivery/DEFINITION_OF_DONE.md` |
| `3a6be8b17b9ea8583e4e2d96e21110866bc3f3ef223980d88403be8ee88f07d7` | 8457 | `delivery/DEPENDENCY_GRAPH.md` |
| `2fc15fbb6920a2b8d8a7727181e80a607777aa2a55009a5c89dcf3a3ecdc5d71` | 18465 | `delivery/EXECUTION_WAVES.md` |
| `eeee6cfe859eaf0b8dd73309468c774237d93e7cf3239e7609dcc9d7ea734728` | 2261 | `delivery/FIRST_12_TASKS.md` |
| `92dea56cea04db0b2e98c2a8c7e0d261414b850a4aa350038cb74684fd739abf` | 4390 | `delivery/RISK_REGISTER.md` |
| `ce2df7424cd0a87423250641d51343f206c5636924d4b595c73e4e401e19b45f` | 20224 | `delivery/ROADMAP.md` |
| `9d5a6da8bf0a83de6a373d0fa2c970c22ff89971f19feb32f5ff60f064b0a13e` | 45073 | `github/BULK_CREATION_RUNBOOK.md` |
| `76e3872a42ba721e20ea04d3703d0894e11318363b909efdf9ce9153cd8c52c1` | 31913 | `github/ISSUE_MANIFEST.md` |
| `6a50142662f433ba58d931441e659cafd16c78272cb2b7cfdff917b17d25e073` | 4917 | `github/LABELS_AND_MILESTONES.md` |
| `c2ee6b67985b83b6a02284a5d96f16fba88dad34bbfb5a7499149e1e2d855eae` | 2912 | `github/PARALLEL_WORK_GUIDE.md` |
| `daa7340377c6dce3689e7b202603fe55504e250775122cd61787660bcb77044d` | 3028 | `issues/README.md` |
| `67f51c580de945b943526edc0596d234bd9715338707e19fb3fdaeec11553449` | 2559 | `issues/m8-0-correctness/README.md` |
| `69a56590bfaac386ae17ed354162bc056f95ee7364ab0088b8f8fd6b6471f116` | 5727 | `issues/m8-0-correctness/br-001-freeze-the-post-alpha-audit-baseline-and-provenance.md` |
| `7f57cc94fda4774d3a4f1b18f91f02b5a9f2c8b2bcc5b263720c9f980fc0be45` | 4340 | `issues/m8-0-correctness/br-002-add-a-regression-probe-for-middleware-composition-count.md` |
| `5cf830a97e575a9625d5bf4f3b15d26c08476b0f42c1dffc71ace0fa58e8d286` | 5226 | `issues/m8-0-correctness/br-003-move-middleware-composition-fully-into-the-compile-phase.md` |
| `c9b691000595e85792e68fba42f457c98a21c2261d3fc07a83401161c080c0b2` | 4337 | `issues/m8-0-correctness/br-004-guard-middleware-hot-path-allocations-with-a-release-budget.md` |
| `b6cf8daeeb0f429ffb50fce46b4abf27942371d7ab719092a0f2843c9b0886d7` | 4506 | `issues/m8-0-correctness/br-005-reproduce-and-threat-model-raw-html-brand-forgery.md` |
| `df2851f182ee706df56e1ed8e269bb7c8ece3361c1f24bfc7a8e2812b86a9fb9` | 4959 | `issues/m8-0-correctness/br-006-make-the-raw-html-trust-marker-non-accidentally-forgeable.md` |
| `96ba001fb85cea60d05003e4b77412e04880dc7a4670f7a6bbd212b0bd1e723f` | 4846 | `issues/m8-0-correctness/br-007-audit-every-renderer-header-and-htmx-unsafe-sink.md` |
| `0b0db00e254af4aed2f3d81e0f29fa264fb3fc20ddfc05bb8a5fdd5950ba3c23` | 3855 | `issues/m8-0-correctness/br-008-replace-the-stale-design-bundle-root-readme.md` |
| `18ef90d5b974929782cd5c2adf55908f08732d1d015bc749c6d6b3af5d404db3` | 4313 | `issues/m8-0-correctness/br-009-generate-readme-status-facts-and-fail-on-drift.md` |
| `8a017a3df439ea719f3dd4c29e2322455e81aaef3c449e699c622e9cea2e4d98` | 4191 | `issues/m8-0-correctness/br-010-reconcile-stale-milestone-and-release-claims-across-the-corpus.md` |
| `20938221c9ca17c91cc46152fe541829d05ade45d230f595af1494334cd3d4cf` | 2549 | `issues/m8-1-package-boundaries/README.md` |
| `7c3e220a4255fa2f3ca8a8e538ccd0b47532699445d9a720b4b3521681336bc9` | 4554 | `issues/m8-1-package-boundaries/br-011-decide-and-freeze-the-post-alpha-package-dependency-graph.md` |
| `102c1eaade5fd5f2dbf29fa7a1d1914d79014517e0cc5333ca450e6621f5780d` | 3935 | `issues/m8-1-package-boundaries/br-012-enforce-the-package-dependency-graph-in-ci.md` |
| `4f914f91853f138863a496ddf975778266291e99bd17d1b98a24c5bf1da57d36` | 4078 | `issues/m8-1-package-boundaries/br-013-create-the-bundar-forms-package-skeleton.md` |
| `2089566f39b0d3a80509423746d391c67f3f66d906e329e3779d6cf1552c6f85` | 4357 | `issues/m8-1-package-boundaries/br-014-extract-framework-neutral-form-action-contracts.md` |
| `eaf185e190c9bb76abf8a4a8cfb9bda6939d62dedc60918ef4e2169a43e4bebf` | 6159 | `issues/m8-1-package-boundaries/br-015-move-progressive-form-orchestration-into-bundar-forms.md` |
| `8377215981def2b6b45c1de9f508793822252bd64d5a4f4867e348b01c8eba79` | 4288 | `issues/m8-1-package-boundaries/br-016-isolate-standard-schema-integration-behind-a-forms-adapter.md` |
| `1bb968a8b945923f9289a8719b5e8fae9f1b75bd2903386d2ee52b3d74a310a2` | 6892 | `issues/m8-1-package-boundaries/br-017-make-bundar-htmx-protocol-pure.md` |
| `9d890b0c909e7ed461e54176469401cfa7ffd1670c9d94704e3b2889d32cbe28` | 4401 | `issues/m8-1-package-boundaries/br-018-provide-compatibility-re-exports-for-moved-form-apis.md` |
| `1ff65b537ae8621b7f902b4523fd006247a4b00708c3636e0b0ae61964f98cbe` | 4509 | `issues/m8-1-package-boundaries/br-019-add-packed-external-type-consumers-for-every-public-export-map.md` |
| `77aca79a4a40b6289b18c8ddb6b1759b7606acd107d29b398097256b68186b24` | 4592 | `issues/m8-1-package-boundaries/br-020-regenerate-package-api-docs-diagrams-and-migration-guidance.md` |
| `353e86f05761501e114b2a5c9c1923710efd6bc514d4310fbf3400f5a5120de1` | 5384 | `issues/m8-2-agent-architecture/README.md` |
| `46b07f9e49f34e8bd895e34fdfd75c8f1190c27c58029b72a1a56400dd7dcb35` | 5582 | `issues/m8-2-agent-architecture/br-021-adopt-a-feature-sliced-application-structure-for-agent-friendly-bundar-apps.md` |
| `95314b7aefcb837ba9ee9857122953ca72250133141e44789d8ed09036d354a4` | 4625 | `issues/m8-2-agent-architecture/br-022-define-application-import-direction-and-agent-read-write-zones.md` |
| `b786a431fdb09c79fd30dc9271ec4cfb96d22d112df4d6218016bce0e714c619` | 5215 | `issues/m8-2-agent-architecture/br-023-implement-an-application-feature-boundary-checker.md` |
| `e399f8924c2564b745521e9894b5cff385a1f2c53fd3aa77af6fd6683dabdf11` | 4090 | `issues/m8-2-agent-architecture/br-024-create-the-canonical-feature-slice-scaffold-tree.md` |
| `004630a6a042a750d13e7c1d390412796681a2f0edfdceb9602a8677bc202191` | 4343 | `issues/m8-2-agent-architecture/br-025-expose-create-bundar-structure-feature.md` |
| `d092a9da4bc680cba44c8c751a48a24927c4fd57b4ab76f8e84afba276a66083` | 4537 | `issues/m8-2-agent-architecture/br-026-convert-the-canonical-minimal-starter-ui-to-actual-tsx.md` |
| `1e7905b58375f9ff5ca6285722103e1ae5f77ce949d1585c3458831d17af452a` | 4375 | `issues/m8-2-agent-architecture/br-027-extract-the-minimal-starter-validation-schema.md` |
| `8808c818b8b793fcd926865890bde99ba7ab7726fe1b1cbf979ea9a7d61b433c` | 4541 | `issues/m8-2-agent-architecture/br-028-extract-the-minimal-starter-views-and-components.md` |
| `4b05225d007cc52448bb17b3a0864d1efddca4140f2f0945dfec2c953b7b1cdc` | 4723 | `issues/m8-2-agent-architecture/br-029-extract-the-minimal-starter-action-and-service-boundary.md` |
| `54910e5812476fe1fe2a5b3505baf16c667629769b851f1911145106b1b71bfb` | 4550 | `issues/m8-2-agent-architecture/br-030-reduce-the-minimal-route-module-to-http-and-hypermedia-orchestration.md` |
| `f2d217a0bc325b0705cf0408183d8f9e5b4fbc694543c2b5213fb25af62bcc33` | 4407 | `issues/m8-2-agent-architecture/br-031-document-and-gate-the-minimal-starter-architecture.md` |
| `9b5b313319d549d171d569a7e607547257db654675cb8df5499441c8fb9bf481` | 4375 | `issues/m8-2-agent-architecture/br-032-create-the-todo-feature-slice-skeleton-and-migration-map.md` |
| `551683dddc58c5c6cafc1ab3441ad07fa22d5b836b78677053f53471d3447418` | 4176 | `issues/m8-2-agent-architecture/br-033-move-todo-domain-types-and-repository-ports.md` |
| `b453b0b9deffedab72ad3fc1a1e0f5c0819cc933037dcff76d196be104f5948e` | 4248 | `issues/m8-2-agent-architecture/br-034-extract-todo-schemas-and-application-actions.md` |
| `1ff06d98bc276ff166d398ba80e00a7db0baa1204cbfe2a053f5c9ef6e3d37e5` | 4081 | `issues/m8-2-agent-architecture/br-035-extract-todo-pages-fragments-forms-and-components.md` |
| `36dd0d5d9f81d91866ba31eb8e0a2e602725024d6ee59b5670761b7b5b304320` | 4434 | `issues/m8-2-agent-architecture/br-036-extract-todo-route-registration-and-bootstrap-composition.md` |
| `461bee7e8f260b7ec10942a6ad34cbf4089bfebd889825c045fe93d024d1d4d7` | 4953 | `issues/m8-2-agent-architecture/br-037-close-todo-feature-slice-regression-and-source-diff-evidence.md` |
| `cb00576e71c107c26806075001da10a50ddda1d8ca0919a22c013f67542f74d8` | 4399 | `issues/m8-2-agent-architecture/br-038-inventory-and-scaffold-admin-reference-features.md` |
| `ec1f357317dd2b72b7fa7619314859d9c16ab5203ccf54b8dc1d2adbf023c79f` | 4177 | `issues/m8-2-agent-architecture/br-039-split-admin-domain-models-and-repository-ports.md` |
| `d68d088ec3d014b5c9a701c03e842a873a009d7195524f7da2d3f22e40729273` | 4294 | `issues/m8-2-agent-architecture/br-040-extract-admin-validation-authorization-and-application-actions.md` |
| `f5c4ac8f582546b42a667f6e5f5abc4b3684873529fb7f5feffaead48f5a7fbf` | 3992 | `issues/m8-2-agent-architecture/br-041-extract-admin-pages-tables-forms-dialogs-and-update-regions.md` |
| `852b31277543baa89b60fe62acf85707a2442cefeea7d8a2ba442707ad49b386` | 4420 | `issues/m8-2-agent-architecture/br-042-extract-admin-route-modules-and-runtime-bootstrap.md` |
| `46cf378ca0c32c67ba18d7b6ba403b4a239c4626b6124b1ac84e5e6d45de1e94` | 4834 | `issues/m8-2-agent-architecture/br-043-close-admin-feature-slice-regression-and-architecture-evidence.md` |
| `7cb7ed27680367fd4d508606990d1cc7109f6792a6e93580ce462954570f5c91` | 4400 | `issues/m8-2-agent-architecture/br-044-add-concise-local-agents-md-and-feature-map-templates.md` |
| `780835220d1aa69bab7dffabb8321539bc2011ff7c71e6ad23408fed0ab2b271` | 4367 | `issues/m8-2-agent-architecture/br-045-introduce-file-size-and-responsibility-budgets-with-explicit-exceptions.md` |
| `7a0ef2a0774a29002b3fa77d14368ca1034f7da1da28081e349428f6e9dffe12` | 2995 | `issues/m8-3-agent-tooling/README.md` |
| `e91c6b2587107dc02722cc1e350fa5876d5ec9fcff14e17360886f10600ba60f` | 4464 | `issues/m8-3-agent-tooling/br-046-standardize-deterministic-machine-readable-cli-behavior.md` |
| `72db4152f89e8e88cb88870995056979cdb65f08bde349920c8b60f02c2d3834` | 4459 | `issues/m8-3-agent-tooling/br-047-add-bundar-inspect-json-for-routes-packages-and-feature-boundaries.md` |
| `d4fe0799f6260343aa0c23a00700c734418b79d7b4221a6495784bb691aa1698` | 4958 | `issues/m8-3-agent-tooling/br-048-add-bundar-agent-context-feature-bounded-context-packs.md` |
| `c3b72b4f55556c5c817437680e0cd6edc7527b37b86e82c341973db509d3ff44` | 4316 | `issues/m8-3-agent-tooling/br-049-adopt-agent-ready-github-issue-read-write-check-contracts.md` |
| `9dfa79f3ded344dfa10ccda11e37a558d85c2122b36beda92c49a71e9e669c8a` | 4217 | `issues/m8-3-agent-tooling/br-050-dogfood-generated-typed-urls-in-the-minimal-starter.md` |
| `906343c0f4f28bf47e86401ea21a40f6fccf33e827f243c5e5aa48121ef87f4d` | 4516 | `issues/m8-3-agent-tooling/br-051-dogfood-generated-typed-urls-in-todo-and-admin.md` |
| `4a86deee1a770cbb41b0041ef8a45eb6dc582354631eeb7906ac509afe7d7a61` | 4850 | `issues/m8-3-agent-tooling/br-052-add-a-typed-primary-fragment-and-update-intent-response-api.md` |
| `8143893e78f373b56cd2047a540ef85d385f6c3076b0b638944b75d23a992e31` | 4490 | `issues/m8-3-agent-tooling/br-053-remove-manual-html-concatenation-from-reference-applications.md` |
| `49706930e2607b7c7300009886e1567225708406a5ee7c6d72b0e673f01e904d` | 4799 | `issues/m8-3-agent-tooling/br-054-add-safe-response-header-and-cookie-mutation-helpers.md` |
| `b19e5293e9f7347894ee7937089d97d860ccbc5e989778a08821ebec1c776b4d` | 4551 | `issues/m8-3-agent-tooling/br-055-add-csrf-form-field-and-session-token-composition-helpers.md` |
| `d09e56c77137f6f89cbee5ebd585b6d39b3e6e332889349b81c8f81dc6b4bf23` | 4402 | `issues/m8-3-agent-tooling/br-056-refactor-examples-away-from-manual-cookie-and-response-reconstruction.md` |
| `408d7be27eeabf7e4989c046ed77ad048deb616dd861578a3afe9b40264b6ac7` | 3154 | `issues/m8-4-production-security/README.md` |
| `1b730fbe05ee7baf07086abd48f134abe4408edf097293f70af5b4df6f7749fb` | 4484 | `issues/m8-4-production-security/br-057-define-startup-readiness-shutdown-and-graceful-stop-lifecycle.md` |
| `95e61de908edfc0ebe0f223304616a69baa33f3523fc376fd581e118ec2113fa` | 4717 | `issues/m8-4-production-security/br-058-propagate-request-cancellation-through-context-forms-and-streams.md` |
| `7795b61d6d2fd2a7d12620a07c5da129468cb99691a10e64657688a908a47885` | 4316 | `issues/m8-4-production-security/br-059-define-the-trusted-proxy-client-ip-scheme-host-and-origin-model.md` |
| `6df72702cf58b403f3cc3b9f028f3c52c813318635d68497947f7db8e816ac78` | 4366 | `issues/m8-4-production-security/br-060-implement-secure-cookie-behavior-behind-explicit-trusted-proxies.md` |
| `7f299f99a9a5242d86e2bc35634ea2913eb01a24921404f7e1fabab278e8e457` | 4519 | `issues/m8-4-production-security/br-061-define-durable-session-store-capabilities-and-failure-semantics.md` |
| `6bd6b35ea2280dbd7e976e57b7af5583fba419ae888bf2e87fe753f597ff5aef` | 4677 | `issues/m8-4-production-security/br-062-fail-closed-on-memory-sessions-or-insecure-cookies-in-production.md` |
| `6be58cf19726c671c5ff706342687d2e5ca018de591d0f2f94b4749d5011466d` | 4466 | `issues/m8-4-production-security/br-063-close-session-fixation-rotation-logout-and-replay-tests.md` |
| `47fbb90a689d3be1d71f890417c7c32feeafbbc1a681cac5d479eb56750181b7` | 5279 | `issues/m8-4-production-security/br-064-validate-redirect-targets-and-all-htmx-response-header-values.md` |
| `0f1180f6ef5cee4c727b79cd5360f2660813b69d5ae07953481b5076950d8286` | 4577 | `issues/m8-4-production-security/br-065-integrate-csp-nonces-with-documents-and-htmxscript.md` |
| `f35258a561ee1d87fd115210f7557016ea78d6d0cce791123e59064e4874d093` | 5017 | `issues/m8-4-production-security/br-066-enforce-multipart-and-form-request-complexity-limits.md` |
| `f71dd97c543b3166cdc88365fe5fc032a3cb3eec6013b3fccbe48a6290259801` | 5861 | `issues/m8-4-production-security/br-067-define-stable-framework-error-codes-and-redaction-policy.md` |
| `18984ce9e0e25bd6ffaa7f5ff3e3e3659f168e2d9b06b72a776531821c625872` | 4757 | `issues/m8-4-production-security/br-068-add-property-and-fuzz-tests-for-high-risk-parsers-and-serializers.md` |
| `8df637c50c55f9d451adb9e1f20f5130cb58732b3c70a27b1df0997b6f03d929` | 2723 | `issues/m8-5-conformance-performance/README.md` |
| `8568593f2cfb72afb3ede27a596874737020238603601fd8dbff6071d1b412ae` | 4651 | `issues/m8-5-conformance-performance/br-069-close-http-method-conformance-for-head-options-405-and-allow.md` |
| `0a08bf87e090335eff91bf412b7f682d31037f73e02a227f29c0b1997800b0e6` | 4626 | `issues/m8-5-conformance-performance/br-070-close-route-edge-case-and-collision-conformance.md` |
| `a1918f793d976549b8143ee994132e4a3d7e9d349aa6274b7e1cdb5bab4b1f88` | 5005 | `issues/m8-5-conformance-performance/br-071-close-body-single-consumption-and-content-type-conformance.md` |
| `177fc5c963af7b3cb1ce1b216b00b71f584d014ac4abe0f31d14d497e307abec` | 4830 | `issues/m8-5-conformance-performance/br-072-close-streaming-backpressure-cancellation-and-late-error-conformance.md` |
| `abf1430d7e0dec7c2a8679ace3b06b7aefe07c89a8e16cd666ab16eb33260532` | 5295 | `issues/m8-5-conformance-performance/br-073-revalidate-the-neutral-htmx-contract-against-the-official-v4-upgrade-checker.md` |
| `91a6dff522c2d5f881efea00531642508c12f7dc630f99de3a10954f454dde0e` | 4815 | `issues/m8-5-conformance-performance/br-074-add-firefox-and-webkit-browser-conformance-lanes.md` |
| `bb14c845df2a9dc1ba7e76426b6766f21088c817484f61bf66485d8ec41e7424` | 4930 | `issues/m8-5-conformance-performance/br-075-add-no-javascript-and-accessibility-baseline-gates.md` |
| `3e41821e4406e2acfc9e72419613378a739e9ce3243fb1e06e2fca8aed836b53` | 4706 | `issues/m8-5-conformance-performance/br-076-add-carno-js-as-a-fair-backend-framework-benchmark-reference.md` |
| `33c06ddcfb22102220e1194ab3a4deaa5d40d186ad5ed2ed50c751f18f05130a` | 5007 | `issues/m8-5-conformance-performance/br-077-profile-large-table-rendering-and-form-parsing-then-set-beta-budgets.md` |
| `197a39afd5a9bfa5f123aced418e23697a18883a442d8bfc3f55286da147b742` | 2724 | `issues/m8-6-beta-release/README.md` |
| `1132c91ff9c0be5602fb0b3e383d6ac4a964e4ee171614b19b1161c075220042` | 4890 | `issues/m8-6-beta-release/br-078-freeze-alpha-to-beta-versioning-and-publication-policy.md` |
| `3fad2893923b8f8ace33637300a61929a9edbb62c9d4730297cf02ba90fca541` | 4117 | `issues/m8-6-beta-release/br-079-resolve-npm-namespace-credentials-provenance-and-human-approval-gate.md` |
| `058d546cef0aa9e9aca6a5d907b3413174d34c1c5481c6dbf8db09c803e31506` | 4726 | `issues/m8-6-beta-release/br-080-re-audit-tarballs-exports-licenses-sbom-and-provenance-after-refactors.md` |
| `3003f41262ea1a6f58de1c8c8d2b4e6ba73020a6f7ca9b99ef72b5e27c317d91` | 4308 | `issues/m8-6-beta-release/br-081-publish-a-guarded-canary-and-verify-registry-metadata.md` |
| `6d92c9fdda2829e3c7adb2e5cf36028919f75d4d2aeb01c35a97761db5715590` | 4671 | `issues/m8-6-beta-release/br-082-run-an-external-clean-repository-consumer-smoke-test.md` |
| `3f8cc17a521d7090a6a69f48485e39d3adbce65d337ef84445ba2520876375f9` | 4545 | `issues/m8-6-beta-release/br-083-build-and-verify-an-alpha-to-beta-migration-fixture.md` |
| `0d6a6f50d0e9119f5475bcbd93db5965df4b5cd48f50511a042c9d29e63841b0` | 4840 | `issues/m8-6-beta-release/br-084-run-an-independent-greenfield-human-and-agent-usability-study.md` |
| `0be6ffdb11dc690a49aab3ba612cf72ac44d76927a1f686551fe574e89a96583` | 10748 | `issues/m8-6-beta-release/br-085-run-the-beta-release-gate-and-issue-an-evidence-backed-go-no-go.md` |
| `c3a73441f78e6a90f97ba1002cadbb613d70f3d929a6b83f90c1cea5b5999959` | 4892 | `review/AUDIT_METHOD_AND_LIMITATIONS.md` |
| `0f212bd58565fce643a7767ab594e5898e3efb041daf62321fc6761bdf0f3b1b` | 8351 | `review/EXECUTIVE_REVIEW.md` |
| `1c4b27c35e1ff557d14cb4d49e20c5c3e459423d90cae0dd4e2a68d1efa709d0` | 7357 | `review/FINDINGS_REGISTER.md` |
| `897fd09cb78a1074299a06792950eff166d66f2f045cffda1218c15a5fbe142c` | 5518 | `review/SCORECARD.md` |
| `330861bed17e6d925fa53e450d85133101f29a30b7851a86ed18364489f3b7a5` | 4802 | `review/SOURCE_LEDGER.md` |
| `97bff263eade4a314697490ae0b4647dc0b19a84a31efa0ca2771856e6673c47` | 3241 | `review/WHAT_IS_WORKING.md` |
| `d08aa521f61807ae49460c75d09213cf16660f03ecbfe8d7f9751e1c83ad097a` | 1418 | `supporting/README_APPLY_GUIDE.md` |
| `56f9420e9acd4773363933bc7fc0b61e65b66dad06404a69d9f4b4e4ea559060` | 17801 | `supporting/README_IMPLEMENTATION_CANDIDATE.md` |
| `7360ed6f867e8b4091ee8ed362170e0189fd5d63095f5bea101c1e5b233befbc` | 1631 | `templates/CLOSURE_REPORT_TEMPLATE.md` |
| `5f36e5246c410bf6cb8bcacf9b3e04d62889128b41d1488f4e6a5f25510a9de1` | 2305 | `templates/ISSUE_TEMPLATE.md` |
