---
type: Review and Delivery Bundle Guide
title: Bundar Post-Alpha Review and Beta Plan
description: Evidence-grounded review of Bundar at commit f8bdd86, with an agent-friendly
  architecture decision and 85 dependency-aware GitHub microtasks.
tags:
- bundar
- review
- beta
- github
- ai-agent
- bun
- htmx
- tsx
status: proposed
updated: '2026-08-23'
audit_baseline:
  repository: https://github.com/ther12k/bundar
  commit: f8bdd8641865be3563746e892ab86fba702ee3e8
bundle:
  version: '0.1'
  issue_count: 85
  execution_waves: 15
---

# Bundar post-alpha review and beta plan

This bundle reviews Bundar as it exists at the audited `main` revision:

```text
repository: https://github.com/ther12k/bundar
commit:     f8bdd8641865be3563746e892ab86fba702ee3e8
tag:        v0.1.0-alpha.1
audit date: 2026-08-23 (Asia/Jakarta)
```

It does **not** propose a rewrite. Bundar already has a strong and distinctive foundation: native Bun routing, server-only JSX, progressive page/fragment/form behavior, an honest htmx 2 versus htmx 4-beta boundary, unusually disciplined evidence, and working reference applications.

The next step is to make that implementation easier to trust, easier to read, easier to publish, and much easier for low-context coding agents to modify safely.

## Main decision: one full-stack app, separately owned files

Bundar should **not** split each application into separate frontend and backend repositories. That would recreate API/client duplication and weaken the HTML-first model.

It should separate concerns inside each feature:

```text
src/
  app.ts                         # composition only
  main.ts                        # Bun.serve bootstrap only
  platform/                      # dialect, environment, session, shared middleware

  features/
    todos/
      todo.routes.ts             # HTTP and HTMX orchestration
      todo.actions.ts            # application use cases
      todo.schema.ts             # input contracts
      todo.repository.ts         # persistence port / adapter boundary
      todo.types.ts              # domain and read-model types
      todo.view.tsx              # pages and fragments
      todo.components.tsx        # reusable server UI
      todo.test.ts
      AGENTS.md                   # bounded local map
```

The dependency direction is:

```text
routes ──→ actions ──→ domain / repository ports
   │
   └────→ views ─────→ read models

domain and actions MUST NOT import:
JSX, HTMX, Request, Response, route context, or concrete storage adapters
```

This keeps UI and backend logic close enough to evolve together while giving both humans and agents a small, predictable work area.

Read [`architecture/AGENT_FRIENDLY_APPLICATION_STRUCTURE.md`](architecture/AGENT_FRIENDLY_APPLICATION_STRUCTURE.md) first for the complete rule.

## Review verdict

**Continue Bundar. Do not restart it and do not merge it into Carno, Hono, or Elysia.**

The product differentiation is real:

```text
Bun runtime
+ native route compilation
+ server-only TSX
+ ordinary HTML forms
+ complete-page / fragment negotiation
+ versioned HTMX dialects
+ no hydration
```

The strongest work so far is the product boundary, progressive-enhancement model, HTMX migration discipline, and release-evidence culture.

The most important corrections before beta are:

1. Reproduce and fix the middleware compile-once contract.
2. Close the raw-HTML trust-brand contract mismatch.
3. repair package-boundary drift by moving form workflow ownership out of `@bundar/htmx`.
4. Replace the stale root README and guard future status drift.
5. Convert canonical examples to actual TSX and feature-sliced files.
6. Dogfood typed URLs and high-level response/security helpers.
7. Add lifecycle, proxy, session, cancellation, and parser production contracts.
8. Broaden HTTP/browser/accessibility conformance.
9. Publish real packages and test from a clean external repository.
10. Prove the AI-agent-friendly claim with bounded context tooling and an independent study.

## Readiness estimate

The evidence-weighted beta-readiness estimate is **about 71% (moderate confidence, roughly ±6 percentage points)**. This is a planning indicator, not a release gate. The existing alpha release can still be a good alpha while Bundar is only around this level for a broader beta promise.

| Dimension | Weight | Review score |
| --- | ---: | ---: |
| Product identity and scope | 10% | 9.0/10 |
| Bun-native HTTP core | 12% | 7.5/10 |
| Server JSX and rendering safety | 12% | 7.4/10 |
| HTMX protocol and progressive enhancement | 12% | 8.2/10 |
| Forms and security primitives | 12% | 7.0/10 |
| Developer experience and application structure | 12% | 6.0/10 |
| AI-agent friendliness | 10% | 5.5/10 |
| Testing, evidence, and release discipline | 10% | 8.5/10 |
| Production operations | 5% | 5.5/10 |
| Distribution and external adoption | 5% | 4.0/10 |

The full method and caveats are in [`review/SCORECARD.md`](review/SCORECARD.md). The final beta decision must be a binary evidence-backed GO/NO-GO under BR-085, not a percentage.

## Findings at a glance

| Finding | Classification | Priority | Primary tasks |
| --- | --- | --- | --- |
| Root README still presents Bundar as a design archive | Confirmed documentation defect | P0 | BR-008–BR-010 |
| Middleware may be composed per request despite a compile-once contract | Probable contract defect; reproduce first | P0 | BR-002–BR-004 |
| Raw HTML brand appears forgeable through a globally discoverable marker | Contract/security mismatch; exploitability requires threat model | P0 | BR-005–BR-007 |
| `@bundar/htmx` package dependencies conflict with protocol-pure ownership | Confirmed architecture drift | P0 | BR-011–BR-020 |
| Canonical starter/reference apps mix route, UI, validation, storage, and security concerns | Confirmed maintainability and agent-context gap | P1 | BR-021–BR-045 |
| Canonical `.tsx` examples still use manual JSX factory calls | Confirmed DX/product-positioning gap | P0 | BR-026 |
| Typed URLs and higher-level action/security helpers are under-dogfooded | Confirmed first-party API adoption gap | P1 | BR-050–BR-056 |
| Lifecycle, trusted proxy, durable session, abort, and parser contracts need beta hardening | Recommended production work | P0/P1 | BR-057–BR-068 |
| Browser evidence is Chrome-centered and HTTP edge semantics need explicit closure | Accepted alpha residual risk / beta gap | P1 | BR-069–BR-075 |
| Registry packages are not yet externally consumable | Confirmed human-gated distribution gap | P0 | BR-078–BR-085 |
| htmx 4 GA does not exist at the audit date | Upstream-blocked; not a Bundar defect | Deferred | Existing M7 plus BR-073 |

See [`review/FINDINGS_REGISTER.md`](review/FINDINGS_REGISTER.md) for evidence, impact, confidence, and disposition.

## Bundle map

```text
README.md
review/
  EXECUTIVE_REVIEW.md
  AUDIT_METHOD_AND_LIMITATIONS.md
  SOURCE_LEDGER.md
  SCORECARD.md
  FINDINGS_REGISTER.md
  WHAT_IS_WORKING.md
architecture/
  AGENT_FRIENDLY_APPLICATION_STRUCTURE.md
  PACKAGE_BOUNDARY_RECOMMENDATION.md
  BETA_EXIT_CRITERIA.md
delivery/
  ROADMAP.md
  EXECUTION_WAVES.md
  DEPENDENCY_GRAPH.md
  RISK_REGISTER.md
  DEFINITION_OF_DONE.md
issues/
  README.md
  m8-0-correctness/             BR-001 through BR-010
  m8-1-package-boundaries/      BR-011 through BR-020
  m8-2-agent-architecture/      BR-021 through BR-045
  m8-3-agent-tooling/           BR-046 through BR-056
  m8-4-production-security/     BR-057 through BR-068
  m8-5-conformance-performance/ BR-069 through BR-077
  m8-6-beta-release/            BR-078 through BR-085
github/
  LABELS_AND_MILESTONES.md
  ISSUE_MANIFEST.md
  BULK_CREATION_RUNBOOK.md
  PARALLEL_WORK_GUIDE.md
agents/
  MASTER_EXECUTION_PROMPT.md
  LOW_CONTEXT_TASK_PROTOCOL.md
templates/
  ISSUE_TEMPLATE.md
  CLOSURE_REPORT_TEMPLATE.md
supporting/
  README_IMPLEMENTATION_CANDIDATE.md
  README_APPLY_GUIDE.md
VALIDATION_REPORT.md
SHA256SUMS.md
```

## Recommended execution order

1. Accept BR-001 and the review classification.
2. Run the P0 correctness probes/fixes: BR-002–BR-008.
3. Freeze and enforce the package graph: BR-011–BR-020.
4. Convert the minimal starter to real TSX and feature slices: BR-021–BR-031.
5. Refactor Todo and Admin incrementally: BR-032–BR-045.
6. Add agent tooling and dogfood framework APIs: BR-046–BR-056.
7. Close production/security and conformance work: BR-057–BR-077.
8. Cross the human registry gate and external-consumer proof: BR-078–BR-084.
9. Run BR-085 from one immutable beta candidate.

The topological plan contains **15 execution waves**. Tasks inside a wave are dependency-unblocked, but they are not automatically write-conflict-free. Use [`github/PARALLEL_WORK_GUIDE.md`](github/PARALLEL_WORK_GUIDE.md).

## Using one task with a coding agent

Give the agent only:

1. [`agents/LOW_CONTEXT_TASK_PROTOCOL.md`](agents/LOW_CONTEXT_TASK_PROTOCOL.md)
2. The selected BR issue
3. Its direct dependencies
4. The local `AGENTS.md` / feature map for affected code
5. The source files in the issue's read set

One issue should normally equal one worktree and one pull request. Do not load all 85 issues into the agent context.

## Trust statement

This is a source-and-evidence review, not a freshly executed certification. The artifact environment could not obtain a complete Git clone, so it did not independently rerun `bun run ci:release`. The review relies on inspected public source, the committed alpha gate, the release record, and previously captured repository files. BR-001 requires the implementation agent to rebase the evidence on the current repository revision and rerun the appropriate checks.

The two highest-risk implementation observations—middleware composition placement and raw-value branding—have reproduction-first tasks so the repository, not this report, decides the final defect verdict.
